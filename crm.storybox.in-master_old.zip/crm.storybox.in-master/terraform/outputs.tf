output "api_gateway_url" {
  value       = aws_api_gateway_stage.stage.invoke_url
  description = "The root URL of the API Gateway stage"
}

output "ui_bucket_name" {
  value       = aws_s3_bucket.ui_bucket.id
  description = "The name of the S3 bucket hosting the React UI code"
}

output "storage_bucket_name" {
  value       = aws_s3_bucket.storage_bucket.id
  description = "The name of the S3 bucket storing photo documents"
}

output "cognito_user_pool_id" {
  value       = aws_cognito_user_pool.user_pool.id
  description = "The ID of the Cognito User Pool"
}

output "cognito_web_client_id" {
  value       = aws_cognito_user_pool_client.web_client.id
  description = "The ID of the Cognito web application client"
}

output "cloudfront_domain_name" {
  value       = aws_cloudfront_distribution.ui_distribution.domain_name
  description = "The default CloudFront distribution domain name"
}
