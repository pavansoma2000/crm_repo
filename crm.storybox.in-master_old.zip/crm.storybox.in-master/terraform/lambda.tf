# Archive Backend Directory
data "archive_file" "backend_zip" {
  type        = "zip"
  source_dir  = "${path.module}/../backend"
  output_path = "${path.module}/backend_temp.zip"
}

# IAM Role for Lambda Functions
resource "aws_iam_role" "lambda_role" {
  name = "${var.project_name}-lambda-execution-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "lambda.amazonaws.com"
        }
      }
    ]
  })
}

# Attach AWS managed policies
resource "aws_iam_role_policy_attachment" "lambda_basic_execution" {
  role       = aws_iam_role.lambda_role.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

# Inline Custom Policy for DynamoDB, S3, SES, Cognito
resource "aws_iam_policy" "lambda_custom_policy" {
  name        = "${var.project_name}-lambda-custom-policy"
  description = "Permissions for CRM Lambda functions to access S3, DynamoDB, SES, and Cognito"

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      # DynamoDB Access
      {
        Effect = "Allow"
        Action = [
          "dynamodb:GetItem",
          "dynamodb:PutItem",
          "dynamodb:UpdateItem",
          "dynamodb:DeleteItem",
          "dynamodb:Query",
          "dynamodb:Scan"
        ]
        Resource = [
          aws_dynamodb_table.crm_table.arn,
          "${aws_dynamodb_table.crm_table.arn}/index/GSI1"
        ]
      },
      # S3 Access
      {
        Effect = "Allow"
        Action = [
          "s3:GetObject",
          "s3:PutObject",
          "s3:DeleteObject"
        ]
        Resource = "${aws_s3_bucket.storage_bucket.arn}/*"
      },
      # SES Email Dispatch
      {
        Effect = "Allow"
        Action = [
          "ses:SendEmail",
          "ses:SendRawEmail"
        ]
        Resource = "*"
      },
      # Cognito Admin Actions (e.g. creating/managing users if needed)
      {
        Effect = "Allow"
        Action = [
          "cognito-idp:AdminGetUser",
          "cognito-idp:AdminCreateUser",
          "cognito-idp:AdminDeleteUser",
          "cognito-idp:AdminUpdateUserAttributes",
          "cognito-idp:AdminSetUserPassword"
        ]
        Resource = "arn:aws:cognito-idp:${var.aws_region}:${data.aws_caller_identity.current.account_id}:userpool/*"
      }
    ]
  })
}

resource "aws_iam_role_policy_attachment" "lambda_custom_attach" {
  role       = aws_iam_role.lambda_role.name
  policy_arn = aws_iam_policy.lambda_custom_policy.arn
}

# Primary Router Lambda
resource "aws_lambda_function" "api_router" {
  filename         = data.archive_file.backend_zip.output_path
  source_code_hash = data.archive_file.backend_zip.output_base64sha256
  function_name    = "${var.project_name}-api-router"
  role             = aws_iam_role.lambda_role.arn
  handler          = "src.main.handler"
  runtime          = "python3.11"
  timeout          = 30
  memory_size      = 256

  environment {
    variables = {
      DYNAMODB_TABLE      = aws_dynamodb_table.crm_table.name
      STORAGE_BUCKET_NAME = aws_s3_bucket.storage_bucket.id
      SENDER_EMAIL        = var.sender_email
      USER_POOL_ID        = aws_cognito_user_pool.user_pool.id
    }
  }

  depends_on = [
    aws_iam_role_policy_attachment.lambda_basic_execution,
    aws_iam_role_policy_attachment.lambda_custom_attach
  ]
}

# Cognito Trigger Lambda (for post-confirmation syncing)
resource "aws_lambda_function" "cognito_trigger" {
  filename         = data.archive_file.backend_zip.output_path
  source_code_hash = data.archive_file.backend_zip.output_base64sha256
  function_name    = "${var.project_name}-cognito-trigger"
  role             = aws_iam_role.lambda_role.arn
  handler          = "src.auth.cognito_trigger.handler"
  runtime          = "python3.11"
  timeout          = 15
  memory_size      = 128

  environment {
    variables = {
      DYNAMODB_TABLE = aws_dynamodb_table.crm_table.name
    }
  }

  depends_on = [
    aws_iam_role_policy_attachment.lambda_basic_execution,
    aws_iam_role_policy_attachment.lambda_custom_attach
  ]
}

# Allow Cognito to invoke the sync Lambda trigger
resource "aws_lambda_permission" "allow_cognito" {
  statement_id  = "AllowExecutionFromCognito"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.cognito_trigger.function_name
  principal     = "cognito-idp.amazonaws.com"
  source_arn    = aws_cognito_user_pool.user_pool.arn
}

# Update Cognito User Pool triggers (Requires connecting the trigger inside user pool definition)
# To avoid circular reference issues, we define the trigger inside aws_cognito_user_pool by modifying cognito.tf
# or since terraform handles resource dependencies, we can inject it directly:
# Note: Since Cognito allows lambda configuration in place, we can link it.
# We'll update the cognito user pool resources in a subsequent step or let Cognito have it as an optional block.
