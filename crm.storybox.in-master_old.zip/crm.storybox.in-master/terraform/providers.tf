terraform {
  required_version = ">= 1.3.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

# Main Provider: ap-south-2 (Asia Pacific - Hyderabad)
provider "aws" {
  region  = var.aws_region
  profile = var.aws_profile

  default_tags {
    tags = {
      Environment = "Production"
      Project     = "StoryboxCRM"
      ManagedBy   = "Terraform"
    }
  }
}

# Secondary Provider: us-east-1 (N. Virginia)
# Used specifically for CloudFront ACM certificate, which MUST reside in us-east-1
provider "aws" {
  alias   = "us_east_1"
  region  = "us-east-1"
  profile = var.aws_profile

  default_tags {
    tags = {
      Environment = "Production"
      Project     = "StoryboxCRM"
      ManagedBy   = "Terraform"
    }
  }
}
