variable "aws_region" {
  type        = string
  description = "The target AWS Region"
  default     = "ap-south-2"
}

variable "aws_profile" {
  type        = string
  description = "The AWS CLI profile to use"
  default     = "svc-kesav-tsb"
}

variable "project_name" {
  type        = string
  description = "Name prefix for all resources"
  default     = "storybox-crm"
}

variable "environment" {
  type        = string
  description = "Deployment environment name"
  default     = "prod"
}

variable "domain_name" {
  type        = string
  description = "The custom domain name for the CRM (optional, e.g. crm.thestorybox.in)"
  default     = "crm.thestorybox.in"
}

variable "sender_email" {
  type        = string
  description = "SES Sender email address for CRM notifications"
  default     = "hello@thestorybox.in"
}
