data "aws_caller_identity" "current" {}

# S3 Bucket for Frontend UI Hosting
resource "aws_s3_bucket" "ui_bucket" {
  bucket        = "${var.project_name}-ui-${data.aws_caller_identity.current.account_id}"
  force_destroy = true
}

# Block all public access to the UI bucket
resource "aws_s3_bucket_public_access_block" "ui_bucket_block" {
  bucket                  = aws_s3_bucket.ui_bucket.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

# S3 Bucket for Media & Document Storage
resource "aws_s3_bucket" "storage_bucket" {
  bucket        = "${var.project_name}-storage-${data.aws_caller_identity.current.account_id}"
  force_destroy = false
}

# Block general public access to photo storage
resource "aws_s3_bucket_public_access_block" "storage_bucket_block" {
  bucket                  = aws_s3_bucket.storage_bucket.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

# S3 CORS configuration for frontend direct-uploads via presigned URL
resource "aws_s3_bucket_cors_configuration" "storage_cors" {
  bucket = aws_s3_bucket.storage_bucket.id

  cors_rule {
    allowed_headers = ["*"]
    allowed_methods = ["GET", "PUT", "POST", "DELETE", "HEAD"]
    allowed_origins = ["*"] # Restrict to CloudFront domain in prod
    expose_headers  = ["ETag"]
    max_age_seconds = 3600
  }
}
