resource "aws_cognito_user_pool" "user_pool" {
  name                     = "${var.project_name}-user-pool"
  username_attributes      = ["email"]
  auto_verified_attributes = ["email"]

  password_policy {
    minimum_length    = 8
    require_lowercase = true
    require_numbers   = true
    require_symbols   = true
    require_uppercase = true
  }

  # Schema definition for custom role attribute
  schema {
    attribute_data_type      = "String"
    developer_only_attribute = false
    mutable                  = true
    name                     = "role"
    required                 = false

    string_attribute_constraints {
      min_length = 2
      max_length = 20
    }
  }

  # Email configuration
  email_configuration {
    email_sending_account = "COGNITO_DEFAULT"
  }

  lambda_config {
    post_confirmation = aws_lambda_function.cognito_trigger.arn
  }

  tags = {
    Name = "${var.project_name}-user-pool"
  }
}

# User Pool Client for React Single Page Application (SPA)
resource "aws_cognito_user_pool_client" "web_client" {
  name            = "${var.project_name}-web-client"
  user_pool_id    = aws_cognito_user_pool.user_pool.id
  generate_secret = false # Set to false for single page apps (React)

  explicit_auth_flows = [
    "ALLOW_USER_PASSWORD_AUTH",
    "ALLOW_REFRESH_TOKEN_AUTH",
    "ALLOW_USER_SRP_AUTH"
  ]
}

# User Groups mapping roles
resource "aws_cognito_user_group" "super_admin_group" {
  name         = "SUPER_ADMIN"
  user_pool_id = aws_cognito_user_pool.user_pool.id
  description  = "Super administrator with ultimate system ownership"
}

resource "aws_cognito_user_group" "admin_group" {
  name         = "ADMIN"
  user_pool_id = aws_cognito_user_pool.user_pool.id
  description  = "Studio administrators and coordinators"
}

resource "aws_cognito_user_group" "readonly_group" {
  name         = "READ_ONLY"
  user_pool_id = aws_cognito_user_pool.user_pool.id
  description  = "View-only crew members and financial auditors"
}

resource "aws_cognito_user_group" "client_group" {
  name         = "CLIENT"
  user_pool_id = aws_cognito_user_pool.user_pool.id
  description  = "Photography clients accessing their projects"
}

# Pre-seeded users inside User Pool

resource "aws_cognito_user" "superadmin" {
  user_pool_id = aws_cognito_user_pool.user_pool.id
  username     = "kesav@thestorybox.in"
  password     = "StoryboxSuper2026!"
  attributes = {
    email          = "kesav@thestorybox.in"
    email_verified = "true"
    "custom:role"  = "SUPER_ADMIN"
  }
}

resource "aws_cognito_user_in_group" "superadmin_assoc" {
  user_pool_id = aws_cognito_user_pool.user_pool.id
  username     = aws_cognito_user.superadmin.username
  group_name   = aws_cognito_user_group.super_admin_group.name
}

resource "aws_cognito_user" "admin" {
  user_pool_id = aws_cognito_user_pool.user_pool.id
  username     = "karan@thestorybox.in"
  password     = "StoryboxAdmin2026!"
  attributes = {
    email          = "karan@thestorybox.in"
    email_verified = "true"
    "custom:role"  = "ADMIN"
  }
}

resource "aws_cognito_user_in_group" "admin_assoc" {
  user_pool_id = aws_cognito_user_pool.user_pool.id
  username     = aws_cognito_user.admin.username
  group_name   = aws_cognito_user_group.admin_group.name
}

resource "aws_cognito_user" "readonly" {
  user_pool_id = aws_cognito_user_pool.user_pool.id
  username     = "sid@thestorybox.in"
  password     = "StoryboxViewer2026!"
  attributes = {
    email          = "sid@thestorybox.in"
    email_verified = "true"
    "custom:role"  = "READ_ONLY"
  }
}

resource "aws_cognito_user_in_group" "readonly_assoc" {
  user_pool_id = aws_cognito_user_pool.user_pool.id
  username     = aws_cognito_user.readonly.username
  group_name   = aws_cognito_user_group.readonly_group.name
}

resource "aws_cognito_user" "client" {
  user_pool_id = aws_cognito_user_pool.user_pool.id
  username     = "rohan@gmail.com"
  password     = "StoryboxClient2026!"
  attributes = {
    email          = "rohan@gmail.com"
    email_verified = "true"
    "custom:role"  = "CLIENT"
  }
}

resource "aws_cognito_user_in_group" "client_assoc" {
  user_pool_id = aws_cognito_user_pool.user_pool.id
  username     = aws_cognito_user.client.username
  group_name   = aws_cognito_user_group.client_group.name
}
