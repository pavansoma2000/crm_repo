import uuid
from src.utils.db import put_item, get_item, query_by_gsi1, update_item_attributes, delete_item

def list_employees():
    """List all employee metadata records using GSI1."""
    try:
        items = query_by_gsi1("EMPLOYEE")
        return {'statusCode': 200, 'body': items}
    except Exception as e:
        return {'statusCode': 500, 'body': {'error': str(e)}}

def create_employee(body: dict):
    """Create a new employee profile in DynamoDB."""
    emp_id = str(uuid.uuid4())
    required_fields = ['name', 'email', 'designation']
    for field in required_fields:
        if not body.get(field):
            return {'statusCode': 400, 'body': {'error': f"Missing required field: {field}"}}
            
    try:
        employee_item = {
            'PK': f"EMPLOYEE#{emp_id}",
            'SK': "METADATA",
            'GSI1PK': "EMPLOYEE",
            'GSI1SK': f"EMPLOYEE#{emp_id}",
            'employeeId': emp_id,
            'name': body.get('name'),
            'email': body.get('email'),
            'phone': body.get('phone', ''),
            'designation': body.get('designation'),
            'department': body.get('department', 'Production'),
            'dateOfJoining': body.get('dateOfJoining', ''),
            'bloodGroup': body.get('bloodGroup', ''),
            'personalEmail': body.get('personalEmail', ''),
            'address': body.get('address', ''),
            
            # Financial Data
            'ctc': body.get('ctc', 0),
            'monthlySalary': body.get('monthlySalary', 0),
            'bankDetails': body.get('bankDetails', {
                'bankName': '', 'accountName': '', 'accountNumber': '', 'ifscCode': '', 'branch': ''
            }),
            
            # Government IDs
            'panCard': body.get('panCard', ''),
            'aadharCard': body.get('aadharCard', ''),
            
            # Health Insurance
            'healthInsurance': body.get('healthInsurance', {
                'policyNumber': '', 'provider': '', 'sumInsured': 0, 'tpaName': '', 'expiryDate': ''
            }),
            
            # Lists of Objects
            'employmentHistory': body.get('employmentHistory', []), # List of dicts
            'travelHistory': body.get('travelHistory', []), # List of dicts
            'emergencyContacts': body.get('emergencyContacts', []), # List of dicts
            'status': body.get('status', 'ACTIVE')
        }
        
        success = put_item(employee_item)
        if success:
            return {'statusCode': 201, 'body': employee_item}
        return {'statusCode': 500, 'body': {'error': 'Failed to save employee profile'}}
    except Exception as e:
        return {'statusCode': 500, 'body': {'error': str(e)}}

def update_employee(emp_id: str, body: dict):
    """Update specific attributes on an employee record."""
    try:
        existing = get_item(f"EMPLOYEE#{emp_id}", "METADATA")
        if not existing:
            return {'statusCode': 404, 'body': {'error': 'Employee profile not found'}}
            
        # Strip internal PK/SK attributes to avoid key updates
        body.pop('PK', None)
        body.pop('SK', None)
        body.pop('GSI1PK', None)
        body.pop('GSI1SK', None)
        
        updated = update_item_attributes(f"EMPLOYEE#{emp_id}", "METADATA", body)
        return {'statusCode': 200, 'body': updated}
    except Exception as e:
        return {'statusCode': 500, 'body': {'error': str(e)}}

def delete_employee(emp_id: str):
    """Permanently delete an employee profile."""
    try:
        success = delete_item(f"EMPLOYEE#{emp_id}", "METADATA")
        if success:
            return {'statusCode': 200, 'body': {'message': 'Employee profile deleted successfully'}}
        return {'statusCode': 500, 'body': {'error': 'Failed to delete employee profile'}}
    except Exception as e:
        return {'statusCode': 500, 'body': {'error': str(e)}}
