import uuid
import datetime
from src.utils.db import put_item, delete_item, table, update_item_attributes, get_item
from boto3.dynamodb.conditions import Key, Attr
from src.utils.s3 import generate_presigned_upload_url, generate_presigned_download_url, STORAGE_BUCKET, REGION

# --- VENDORS HANDLERS ---

def list_vendors():
    """List all HOA vendors from DynamoDB."""
    try:
        response = table.scan(
            FilterExpression=Attr('SK').eq('METADATA') & Attr('PK').begins_with('HOA#VENDOR#')
        )
        items = response.get('Items', [])
        for item in items:
            shop_image = item.get('shopImage')
            if shop_image and not shop_image.startswith('http'):
                item['shopImage'] = generate_presigned_download_url(shop_image)
        return {'statusCode': 200, 'body': items}
    except Exception as e:
        return {'statusCode': 500, 'body': {'error': str(e)}}

def create_vendor(body: dict):
    """Create a new HOA vendor record."""
    vendor_id = str(uuid.uuid4())
    name = body.get('name')
    contact_person = body.get('contactPerson', '')
    email = body.get('email', '')
    phone = body.get('phone', '')
    address = body.get('address', '')
    category = body.get('category', '')
    status = body.get('status', 'ACTIVE')
    performance_score = body.get('performanceScore', 5)
    shop_image = body.get('shopImage', '')
    location = body.get('location', '')
    supplied_items = body.get('suppliedItems', [])

    if not name:
        return {'statusCode': 400, 'body': {'error': 'Vendor name is required'}}

    vendor_item = {
        'PK': f"HOA#VENDOR#{vendor_id}",
        'SK': "METADATA",
        'GSI1PK': "HOA#VENDORS",
        'GSI1SK': f"VENDOR#{name}",
        'vendorId': vendor_id,
        'name': name,
        'contactPerson': contact_person,
        'email': email,
        'phone': phone,
        'address': address,
        'category': category,
        'status': status,
        'performanceScore': performance_score,
        'shopImage': shop_image,
        'location': location,
        'suppliedItems': supplied_items
    }

    success = put_item(vendor_item)
    if success:
        res_item = dict(vendor_item)
        if shop_image and not shop_image.startswith('http'):
            res_item['shopImage'] = generate_presigned_download_url(shop_image)
        return {'statusCode': 201, 'body': res_item}
    return {'statusCode': 500, 'body': {'error': 'Failed to save vendor'}}

def update_vendor(vendor_id: str, body: dict):
    """Update vendor details."""
    allowed_fields = ['name', 'contactPerson', 'email', 'phone', 'address', 'category', 'status', 'performanceScore', 'shopImage', 'location', 'suppliedItems']
    update_attrs = {k: v for k, v in body.items() if k in allowed_fields}

    if not update_attrs:
        return {'statusCode': 400, 'body': {'error': 'No valid update parameters'}}

    try:
        vendor_meta = get_item(f"HOA#VENDOR#{vendor_id}", "METADATA")
        if not vendor_meta:
            return {'statusCode': 404, 'body': {'error': 'Vendor not found'}}

        old_name = vendor_meta.get('name', '')
        new_name = update_attrs.get('name')

        if new_name and new_name != old_name:
            vendor_meta.update(update_attrs)
            vendor_meta['GSI1SK'] = f"VENDOR#{new_name}"
            put_item(vendor_meta)
            updated = vendor_meta
        else:
            updated = update_item_attributes(f"HOA#VENDOR#{vendor_id}", "METADATA", update_attrs)

        if updated:
            res_updated = dict(updated)
            s_img = res_updated.get('shopImage')
            if s_img and not s_img.startswith('http'):
                res_updated['shopImage'] = generate_presigned_download_url(s_img)
        else:
            res_updated = updated

        return {'statusCode': 200, 'body': res_updated}
    except Exception as e:
        return {'statusCode': 500, 'body': {'error': str(e)}}

def delete_vendor(vendor_id: str):
    """Delete a vendor."""
    success = delete_item(f"HOA#VENDOR#{vendor_id}", "METADATA")
    if success:
        return {'statusCode': 200, 'body': {'message': 'Vendor deleted successfully'}}
    return {'statusCode': 404, 'body': {'error': 'Vendor not found'}}


# --- INVENTORY ITEMS HANDLERS ---

def list_hoa_inventory():
    """List all HOA inventory items."""
    try:
        response = table.scan(
            FilterExpression=Attr('SK').eq('METADATA') & Attr('PK').begins_with('HOA#ITEM#')
        )
        items = response.get('Items', [])
        for item in items:
            item_image = item.get('itemImage')
            if item_image and not item_image.startswith('http'):
                item['itemImage'] = generate_presigned_download_url(item_image)
        return {'statusCode': 200, 'body': items}
    except Exception as e:
        return {'statusCode': 500, 'body': {'error': str(e)}}

def create_hoa_item(body: dict):
    """Create a new HOA inventory item."""
    item_id = str(uuid.uuid4())
    name = body.get('name')
    sku = body.get('sku', '')
    category = body.get('category', '')
    stock_level = int(body.get('stockLevel', 0))
    reorder_point = int(body.get('reorderPoint', 5))
    unit_price = float(body.get('unitPrice', 0.0))
    vendor_id = body.get('vendorId', '')
    item_image = body.get('itemImage', '')
    
    if not name:
        return {'statusCode': 400, 'body': {'error': 'Item name is required'}}

    status = 'IN_STOCK'
    if stock_level <= 0:
        status = 'OUT_OF_STOCK'
    elif stock_level <= reorder_point:
        status = 'LOW_STOCK'

    now = datetime.datetime.utcnow().isoformat() + 'Z'

    inv_item = {
        'PK': f"HOA#ITEM#{item_id}",
        'SK': "METADATA",
        'GSI1PK': "HOA#INVENTORY",
        'GSI1SK': f"ITEM#{sku or name}",
        'itemId': item_id,
        'name': name,
        'sku': sku,
        'category': category,
        'stockLevel': stock_level,
        'reorderPoint': reorder_point,
        'unitPrice': unit_price,
        'vendorId': vendor_id,
        'status': status,
        'itemImage': item_image,
        'lastUpdated': now
    }

    success = put_item(inv_item)
    if success:
        res_item = dict(inv_item)
        if item_image and not item_image.startswith('http'):
            res_item['itemImage'] = generate_presigned_download_url(item_image)
        return {'statusCode': 201, 'body': res_item}
    return {'statusCode': 500, 'body': {'error': 'Failed to save inventory item'}}

def update_hoa_item(item_id: str, body: dict):
    """Update an HOA inventory item."""
    allowed_fields = ['name', 'sku', 'category', 'stockLevel', 'reorderPoint', 'unitPrice', 'vendorId', 'status', 'itemImage']
    update_attrs = {k: v for k, v in body.items() if k in allowed_fields}

    if 'stockLevel' in update_attrs:
        update_attrs['stockLevel'] = int(update_attrs['stockLevel'])
    if 'reorderPoint' in update_attrs:
        update_attrs['reorderPoint'] = int(update_attrs['reorderPoint'])
    if 'unitPrice' in update_attrs:
        update_attrs['unitPrice'] = float(update_attrs['unitPrice'])

    try:
        item_meta = get_item(f"HOA#ITEM#{item_id}", "METADATA")
        if not item_meta:
            return {'statusCode': 404, 'body': {'error': 'Item not found'}}

        # Recalculate status based on new stock level and reorder point
        stock_level = update_attrs.get('stockLevel', item_meta.get('stockLevel', 0))
        reorder_point = update_attrs.get('reorderPoint', item_meta.get('reorderPoint', 5))
        
        status = 'IN_STOCK'
        if stock_level <= 0:
            status = 'OUT_OF_STOCK'
        elif stock_level <= reorder_point:
            status = 'LOW_STOCK'
        update_attrs['status'] = status
        update_attrs['lastUpdated'] = datetime.datetime.utcnow().isoformat() + 'Z'

        old_sku = item_meta.get('sku', '')
        new_sku = update_attrs.get('sku')

        if new_sku and new_sku != old_sku:
            item_meta.update(update_attrs)
            item_meta['GSI1SK'] = f"ITEM#{new_sku}"
            put_item(item_meta)
            updated = item_meta
        else:
            updated = update_item_attributes(f"HOA#ITEM#{item_id}", "METADATA", update_attrs)

        if updated:
            res_updated = dict(updated)
            item_image = res_updated.get('itemImage')
            if item_image and not item_image.startswith('http'):
                res_updated['itemImage'] = generate_presigned_download_url(item_image)
        else:
            res_updated = updated

        return {'statusCode': 200, 'body': res_updated}
    except Exception as e:
        return {'statusCode': 500, 'body': {'error': str(e)}}

def delete_hoa_item(item_id: str):
    """Delete an HOA inventory item."""
    success = delete_item(f"HOA#ITEM#{item_id}", "METADATA")
    if success:
        return {'statusCode': 200, 'body': {'message': 'Item deleted successfully'}}
    return {'statusCode': 404, 'body': {'error': 'Item not found'}}


# --- PURCHASE ORDERS HANDLERS ---

def list_purchase_orders():
    """List all HOA purchase orders."""
    try:
        response = table.scan(
            FilterExpression=Attr('SK').eq('METADATA') & Attr('PK').begins_with('HOA#PO#')
        )
        items = response.get('Items', [])
        for item in items:
            po_image = item.get('poImage')
            if po_image and not po_image.startswith('http'):
                item['poImage'] = generate_presigned_download_url(po_image)
        return {'statusCode': 200, 'body': items}
    except Exception as e:
        return {'statusCode': 500, 'body': {'error': str(e)}}

def create_purchase_order(body: dict):
    """Create a new purchase order."""
    po_id = str(uuid.uuid4())
    vendor_id = body.get('vendorId')
    vendor_name = body.get('vendorName', '')
    order_date = body.get('orderDate', datetime.datetime.utcnow().strftime('%Y-%m-%d'))
    delivery_date = body.get('deliveryDate', '')
    items = body.get('items', [])  # list of {sku, name, quantity, unitPrice, total}
    total_amount = float(body.get('totalAmount', 0.0))
    status = body.get('status', 'DRAFT')  # DRAFT, SENT, DELIVERED, CANCELLED
    payment_status = body.get('paymentStatus', 'UNPAID')  # UNPAID, PARTIALLY_PAID, PAID
    po_image = body.get('poImage', '')

    if not vendor_id:
        return {'statusCode': 400, 'body': {'error': 'Vendor ID is required'}}

    po_item = {
        'PK': f"HOA#PO#{po_id}",
        'SK': "METADATA",
        'GSI1PK': "HOA#POS",
        'GSI1SK': f"PO#{order_date}",
        'poId': po_id,
        'vendorId': vendor_id,
        'vendorName': vendor_name,
        'orderDate': order_date,
        'deliveryDate': delivery_date,
        'items': items,
        'totalAmount': total_amount,
        'status': status,
        'paymentStatus': payment_status,
        'poImage': po_image
    }

    success = put_item(po_item)
    if success:
        # If created directly in DELIVERED status, trigger stock updates
        if status == 'DELIVERED':
            _update_stock_for_delivered_po(items)
        
        res_po = dict(po_item)
        if po_image and not po_image.startswith('http'):
            res_po['poImage'] = generate_presigned_download_url(po_image)
        return {'statusCode': 201, 'body': res_po}
    return {'statusCode': 500, 'body': {'error': 'Failed to save purchase order'}}

def update_purchase_order(po_id: str, body: dict):
    """Update a purchase order and trigger stock level increases if status transitions to DELIVERED."""
    allowed_fields = ['vendorId', 'vendorName', 'orderDate', 'deliveryDate', 'items', 'totalAmount', 'status', 'paymentStatus', 'poImage']
    update_attrs = {k: v for k, v in body.items() if k in allowed_fields}

    if 'totalAmount' in update_attrs:
        update_attrs['totalAmount'] = float(update_attrs['totalAmount'])

    try:
        po_meta = get_item(f"HOA#PO#{po_id}", "METADATA")
        if not po_meta:
            return {'statusCode': 404, 'body': {'error': 'Purchase order not found'}}

        old_status = po_meta.get('status', 'DRAFT')
        new_status = update_attrs.get('status', old_status)

        # Trigger stock updates ONLY if transitioning from non-DELIVERED to DELIVERED
        should_update_stock = (new_status == 'DELIVERED' and old_status != 'DELIVERED')

        old_order_date = po_meta.get('orderDate', '')
        new_order_date = update_attrs.get('orderDate')

        if new_order_date and new_order_date != old_order_date:
            po_meta.update(update_attrs)
            po_meta['GSI1SK'] = f"PO#{new_order_date}"
            put_item(po_meta)
            updated = po_meta
        else:
            updated = update_item_attributes(f"HOA#PO#{po_id}", "METADATA", update_attrs)

        if should_update_stock:
            po_items = update_attrs.get('items', po_meta.get('items', []))
            _update_stock_for_delivered_po(po_items)

        if updated:
            res_po = dict(updated)
            p_img = res_po.get('poImage')
            if p_img and not p_img.startswith('http'):
                res_po['poImage'] = generate_presigned_download_url(p_img)
        else:
            res_po = updated

        return {'statusCode': 200, 'body': res_po}
    except Exception as e:
        return {'statusCode': 500, 'body': {'error': str(e)}}

def delete_purchase_order(po_id: str):
    """Delete a purchase order."""
    success = delete_item(f"HOA#PO#{po_id}", "METADATA")
    if success:
        return {'statusCode': 200, 'body': {'message': 'Purchase order deleted successfully'}}
    return {'statusCode': 404, 'body': {'error': 'Purchase order not found'}}


# --- HELPER FUNCTION ---

def _update_stock_for_delivered_po(po_items):
    """Helper to scan inventory items and increment stock levels for matching SKU or name."""
    if not po_items:
        return
        
    try:
        # Load all HOA inventory items
        scan_res = table.scan(
            FilterExpression=Attr('SK').eq('METADATA') & Attr('PK').begins_with('HOA#ITEM#')
        )
        inv_items = scan_res.get('Items', [])
        
        # Map them by SKU and name for faster lookup
        inv_by_sku = {}
        inv_by_name = {}
        for item in inv_items:
            sku = item.get('sku')
            if sku:
                inv_by_sku[sku.lower()] = item
            name = item.get('name')
            if name:
                inv_by_name[name.lower()] = item

        for po_item in po_items:
            sku = po_item.get('sku', '')
            name = po_item.get('name', '')
            qty = int(po_item.get('quantity', 0))

            if qty <= 0:
                continue

            matched_item = None
            if sku and sku.lower() in inv_by_sku:
                matched_item = inv_by_sku[sku.lower()]
            elif name and name.lower() in inv_by_name:
                matched_item = inv_by_name[name.lower()]

            if matched_item:
                current_stock = int(matched_item.get('stockLevel', 0))
                new_stock = current_stock + qty
                reorder_point = int(matched_item.get('reorderPoint', 5))
                
                status = 'IN_STOCK'
                if new_stock <= 0:
                    status = 'OUT_OF_STOCK'
                elif new_stock <= reorder_point:
                    status = 'LOW_STOCK'

                now = datetime.datetime.utcnow().isoformat() + 'Z'
                
                update_item_attributes(
                    matched_item['PK'], 
                    matched_item['SK'], 
                    {
                        'stockLevel': new_stock, 
                        'status': status, 
                        'lastUpdated': now
                    }
                )
    except Exception as err:
        print(f"Error auto updating stock levels: {err}")

def generate_hoa_upload_url(body: dict):
    """Generate a presigned upload URL for HOA images."""
    file_name = body.get('fileName')
    content_type = body.get('contentType', 'image/jpeg')
    if not file_name:
        return {'statusCode': 400, 'body': {'error': 'fileName is required'}}
    
    unique_key = f"hoa/{uuid.uuid4()}-{file_name}"
    presigned = generate_presigned_upload_url(unique_key, content_type=content_type)
    if presigned:
        return {
            'statusCode': 200,
            'body': {
                'uploadUrl': presigned['upload_url'],
                'objectKey': presigned['object_key']
            }
        }
    return {'statusCode': 500, 'body': {'error': 'Failed to generate upload URL'}}
