import os
import boto3
from botocore.exceptions import ClientError

REGION = os.environ.get('AWS_REGION', 'ap-south-2')
SENDER_EMAIL = os.environ.get('SENDER_EMAIL', 'hello@thestorybox.in')

ses_client = boto3.client('ses', region_name=REGION)

def send_email(to_address: str, subject: str, html_body: str, text_body: str = ""):
    """Send an email using AWS SES, with graceful logging fallback if in sandbox/unverified."""
    print(f"Attempting to send email to {to_address} | Subject: {subject}")
    
    try:
        response = ses_client.send_email(
            Source=SENDER_EMAIL,
            Destination={'ToAddresses': [to_address]},
            Message={
                'Subject': {'Data': subject, 'Charset': 'UTF-8'},
                'Body': {
                    'Html': {'Data': html_body, 'Charset': 'UTF-8'},
                    'Text': {'Data': text_body or html_body, 'Charset': 'UTF-8'}
                }
            }
        )
        print(f"Email sent successfully! MessageId: {response['MessageId']}")
        return True
    except ClientError as e:
        print(f"SES Error: {e.response['Error']['Message']}")
        print("--- SES Sandbox Mode Fallback ---")
        print(f"Sender: {SENDER_EMAIL}")
        print(f"Recipient: {to_address}")
        print(f"Subject: {subject}")
        print(f"Body: {html_body[:300]}...")
        print("---------------------------------")
        return False

def notify_gallery_ready(client_email: str, client_name: str, project_title: str, gallery_url: str):
    subject = f"Your Storybox Gallery is Ready! - {project_title}"
    html = f"""
    <html>
    <body style="font-family: Arial, sans-serif; background-color: #faf9f6; padding: 20px; color: #333;">
        <div style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border: 1px solid #e0dfdb; padding: 40px; border-radius: 8px;">
            <h2 style="color: #c9a063; font-weight: 300; letter-spacing: 1px;">The Storybox</h2>
            <hr style="border: 0; border-top: 1px solid #e0dfdb; margin-bottom: 30px;">
            <p>Dear {client_name},</p>
            <p>We are thrilled to share that the gallery for your project <strong>{project_title}</strong> is now complete and ready for viewing.</p>
            <p>You can access your high-resolution proofs, select your favorites for editing, and leave feedback comments directly in our portal.</p>
            <div style="margin: 30px 0; text-align: center;">
                <a href="{gallery_url}" style="background-color: #1a1a1a; color: #ffffff; padding: 14px 28px; text-decoration: none; border-radius: 4px; font-weight: bold; letter-spacing: 0.5px; display: inline-block;">View Gallery</a>
            </div>
            <p>If you have any questions or feedback, please reply directly to this email or drop us a line.</p>
            <br>
            <p style="margin-bottom: 0;">Warmly,</p>
            <p style="font-style: italic; margin-top: 5px;">The Storybox Team</p>
        </div>
    </body>
    </html>
    """
    return send_email(client_email, subject, html)

def notify_invoice_created(client_email: str, client_name: str, amount: float, description: str, payment_url: str):
    subject = f"Invoice Created for Your Storybox Shoot - Pending Payment"
    html = f"""
    <html>
    <body style="font-family: Arial, sans-serif; background-color: #faf9f6; padding: 20px; color: #333;">
        <div style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border: 1px solid #e0dfdb; padding: 40px; border-radius: 8px;">
            <h2 style="color: #c9a063; font-weight: 300;">The Storybox</h2>
            <hr style="border: 0; border-top: 1px solid #e0dfdb; margin-bottom: 30px;">
            <p>Dear {client_name},</p>
            <p>A new invoice has been generated for your recent project description: <strong>{description}</strong>.</p>
            <p><strong>Amount Due:</strong> ₹{amount:,.2f}</p>
            <p>Please review and complete payment by clicking the link below:</p>
            <div style="margin: 30px 0; text-align: center;">
                <a href="{payment_url}" style="background-color: #c9a063; color: #ffffff; padding: 14px 28px; text-decoration: none; border-radius: 4px; font-weight: bold; display: inline-block;">Pay Invoice</a>
            </div>
            <p>Thank you for choosing The Storybox.</p>
            <br>
            <p style="margin-bottom: 0;">Sincerely,</p>
            <p style="font-style: italic; margin-top: 5px;">The Storybox Billing Team</p>
        </div>
    </body>
    </html>
    """
    return send_email(client_email, subject, html)
