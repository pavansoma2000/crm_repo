import os
import boto3
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError
from decimal import Decimal

# Initialize DynamoDB resource
# When running in AWS Lambda, AWS_REGION is set automatically.
# During local or external tests, it will fall back or use local environment variables.
REGION = os.environ.get('AWS_REGION', 'ap-south-2')
TABLE_NAME = os.environ.get('DYNAMODB_TABLE', 'storybox-crm-prod')

dynamodb = boto3.resource('dynamodb', region_name=REGION)
table = dynamodb.Table(TABLE_NAME)

def convert_floats_to_decimals(obj):
    """Recursively convert all float values in an object to Decimal for boto3."""
    if isinstance(obj, float):
        return Decimal(str(obj))
    elif isinstance(obj, dict):
        return {k: convert_floats_to_decimals(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [convert_floats_to_decimals(x) for x in obj]
    return obj

def get_item(pk: str, sk: str):
    """Fetch a single item by partition key and sort key."""
    try:
        response = table.get_item(Key={'PK': pk, 'SK': sk})
        return response.get('Item')
    except ClientError as e:
        print(f"Error getting item {pk}/{sk}: {e.response['Error']['Message']}")
        return None

def put_item(item: dict):
    """Insert or replace an item in the single table."""
    try:
        decimal_item = convert_floats_to_decimals(item)
        table.put_item(Item=decimal_item)
        return True
    except ClientError as e:
        print(f"Error putting item {item.get('PK')}: {e.response['Error']['Message']}")
        return False
    except Exception as e:
        print(f"General error putting item {item.get('PK')}: {e}")
        return False

def delete_item(pk: str, sk: str):
    """Delete an item by PK and SK."""
    try:
        table.delete_item(Key={'PK': pk, 'SK': sk})
        return True
    except ClientError as e:
        print(f"Error deleting item {pk}/{sk}: {e.response['Error']['Message']}")
        return False

def query_by_pk(pk: str, sk_prefix: str = None):
    """Query items under a Partition Key, optionally matching a prefix on Sort Key."""
    try:
        if sk_prefix:
            condition = Key('PK').eq(pk) & Key('SK').begins_with(sk_prefix)
        else:
            condition = Key('PK').eq(pk)
        
        response = table.query(KeyConditionExpression=condition)
        return response.get('Items', [])
    except ClientError as e:
        print(f"Error querying by PK {pk}: {e.response['Error']['Message']}")
        return []

def query_by_gsi1(gsi1_pk: str, gsi1_sk_prefix: str = None):
    """Query items using the Global Secondary Index 1 (GSI1)."""
    try:
        if gsi1_sk_prefix:
            condition = Key('GSI1PK').eq(gsi1_pk) & Key('GSI1SK').begins_with(gsi1_sk_prefix)
        else:
            condition = Key('GSI1PK').eq(gsi1_pk)
            
        response = table.query(
            IndexName='GSI1',
            KeyConditionExpression=condition
        )
        return response.get('Items', [])
    except ClientError as e:
        print(f"Error querying GSI1 {gsi1_pk}: {e.response['Error']['Message']}")
        return []

def update_item_attributes(pk: str, sk: str, update_attrs: dict):
    """Update specific attributes on an item without replacing the entire item."""
    if not update_attrs:
        return False
    
    decimal_attrs = convert_floats_to_decimals(update_attrs)
    
    update_expression = "SET "
    expression_attribute_names = {}
    expression_attribute_values = {}
    
    for idx, (key, val) in enumerate(decimal_attrs.items()):
        attr_name = f"#attr_{key}"
        attr_val = f":val_{key}"
        update_expression += f"{attr_name} = {attr_val}, "
        expression_attribute_names[attr_name] = key
        expression_attribute_values[attr_val] = val
        
    update_expression = update_expression.rstrip(", ")
    
    try:
        response = table.update_item(
            Key={'PK': pk, 'SK': sk},
            UpdateExpression=update_expression,
            ExpressionAttributeNames=expression_attribute_names,
            ExpressionAttributeValues=expression_attribute_values,
            ReturnValues="ALL_NEW"
        )
        return response.get('Attributes')
    except ClientError as e:
        print(f"Error updating item {pk}/{sk}: {e.response['Error']['Message']}")
        return None
