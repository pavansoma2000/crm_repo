import os
import boto3
from botocore.exceptions import ClientError
from botocore.config import Config

REGION = os.environ.get('AWS_REGION', 'ap-south-2')
STORAGE_BUCKET = os.environ.get('STORAGE_BUCKET_NAME', 'storybox-crm-storage')

# Use signature version v4 for ap-south-2 compatibility
s3_client = boto3.client(
    's3', 
    region_name=REGION,
    endpoint_url=f"https://s3.{REGION}.amazonaws.com",
    config=Config(signature_version='s3v4', s3={'addressing_style': 'virtual'})
)

def generate_presigned_upload_url(object_key: str, content_type: str = None, expires_in: int = 3600) -> dict:
    """Generate a presigned S3 PUT URL so clients/staff can upload directly to S3."""
    try:
        params = {
            'Bucket': STORAGE_BUCKET,
            'Key': object_key
        }
        if content_type:
            params['ContentType'] = content_type
            
        url = s3_client.generate_presigned_url(
            ClientMethod='put_object',
            Params=params,
            ExpiresIn=expires_in
        )
        return {
            'upload_url': url,
            'object_key': object_key
        }
    except ClientError as e:
        print(f"Error generating presigned upload URL: {e}")
        return None

def generate_presigned_download_url(object_key: str, expires_in: int = 3600) -> str:
    """Generate a presigned S3 GET URL to download/view private assets."""
    try:
        url = s3_client.generate_presigned_url(
            ClientMethod='get_object',
            Params={
                'Bucket': STORAGE_BUCKET,
                'Key': object_key
            },
            ExpiresIn=expires_in
        )
        return url
    except ClientError as e:
        print(f"Error generating presigned download URL: {e}")
        return None
