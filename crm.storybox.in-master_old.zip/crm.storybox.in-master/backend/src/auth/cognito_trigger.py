import json
from src.utils.db import put_item

def handler(event, context):
    """
    Cognito Post Confirmation Trigger.
    Saves the user information to DynamoDB when their email is confirmed/activated.
    """
    print("Received Cognito Trigger Event:", json.dumps(event))
    
    user_attributes = event['request']['userAttributes']
    user_id = event['userName']  # Cognito Username or sub
    email = user_attributes.get('email')
    name = user_attributes.get('name', email.split('@')[0])
    phone = user_attributes.get('phone_number', '')
    
    # Check for custom role, default to CLIENT
    role = user_attributes.get('custom:role', 'CLIENT').upper()
    
    # Save user to DynamoDB table
    user_item = {
        'PK': f"USER#{user_id}",
        'SK': "METADATA",
        'GSI1PK': f"ROLE#{role}",
        'GSI1SK': f"USER#{user_id}",
        'userId': user_id,
        'email': email,
        'name': name,
        'phone': phone,
        'role': role,
        'status': 'ACTIVE'
    }
    
    print(f"Syncing Cognito user {user_id} to DynamoDB: {user_item}")
    success = put_item(user_item)
    
    if not success:
        print(f"Failed to sync user {user_id} to DynamoDB.")
        # We don't raise an exception to prevent Cognito signup process from failing,
        # but in production, you might want to raise it depending on requirements.
        
    return event
