import uuid
import datetime
from src.utils.db import put_item, delete_item, table, update_item_attributes, get_item
from boto3.dynamodb.conditions import Key, Attr

def list_leads():
    """List all leads and enquiries from DynamoDB."""
    try:
        # Perform scan on table filtering by PK begins_with("LEAD#") and SK = "METADATA"
        response = table.scan(
            FilterExpression=Attr('SK').eq('METADATA') & Attr('PK').begins_with('LEAD#')
        )
        return {'statusCode': 200, 'body': response.get('Items', [])}
    except Exception as e:
        return {'statusCode': 500, 'body': {'error': str(e)}}

def create_lead(body: dict):
    """Create a new qualified lead or enquiry in DynamoDB."""
    lead_id = str(uuid.uuid4())
    client_name = body.get('clientName', 'Anonymous')
    client_email = body.get('clientEmail')
    client_phone = body.get('clientPhone', '')
    event_type = body.get('eventType', 'Wedding')
    event_date = body.get('eventDate', datetime.date.today().isoformat())
    budget = float(body.get('budget', 0.0))
    notes = body.get('notes', '')
    status = body.get('status', 'ENQUIRY').upper() # ENQUIRY, LEAD, CONVERTED, LOST
    source = body.get('source', 'Manual Addition')
    
    lead_item = {
        'PK': f"LEAD#{lead_id}",
        'SK': "METADATA",
        'GSI1PK': f"STATUS#{status}",
        'GSI1SK': f"LEAD#{lead_id}",
        'leadId': lead_id,
        'clientName': client_name,
        'clientEmail': client_email,
        'clientPhone': client_phone,
        'eventType': event_type,
        'eventDate': event_date,
        'budget': budget,
        'status': status,
        'source': source,
        'notes': notes,
        'createdAt': datetime.datetime.utcnow().isoformat()
    }
    
    success = put_item(lead_item)
    if success:
        return {'statusCode': 201, 'body': lead_item}
    return {'statusCode': 500, 'body': {'error': 'Failed to create lead'}}

def update_lead(lead_id: str, body: dict):
    """Update a lead's status, details, or qualified budget in DynamoDB."""
    allowed_fields = ['clientName', 'clientEmail', 'clientPhone', 'eventType', 'eventDate', 'budget', 'notes', 'status', 'source']
    update_attrs = {k: v for k, v in body.items() if k in allowed_fields}
    
    if not update_attrs:
        return {'statusCode': 400, 'body': {'error': 'No valid update parameters'}}
        
    try:
        lead_metadata = get_item(f"LEAD#{lead_id}", "METADATA")
        if not lead_metadata:
            return {'statusCode': 404, 'body': {'error': 'Lead not found'}}
            
        old_status = lead_metadata.get('status', 'ENQUIRY')
        new_status = update_attrs.get('status')
        
        # If status changes, update GSI1PK
        if new_status and new_status.upper() != old_status.upper():
            lead_metadata.update(update_attrs)
            lead_metadata['GSI1PK'] = f"STATUS#{new_status.upper()}"
            put_item(lead_metadata)
            updated = lead_metadata
        else:
            updated = update_item_attributes(f"LEAD#{lead_id}", "METADATA", update_attrs)
            
        return {'statusCode': 200, 'body': updated}
    except Exception as e:
        return {'statusCode': 500, 'body': {'error': str(e)}}

def delete_lead(lead_id: str):
    """Hard delete a qualified lead or enquiry record from DynamoDB."""
    success = delete_item(f"LEAD#{lead_id}", "METADATA")
    if success:
        return {'statusCode': 200, 'body': {'message': 'Lead deleted successfully'}}
    return {'statusCode': 404, 'body': {'error': 'Lead not found'}}
