import uuid
import datetime
from src.utils.db import put_item, delete_item, table, update_item_attributes, get_item, query_by_pk
from boto3.dynamodb.conditions import Key, Attr

def list_proposals():
    """List all proposals along with their complete version revision history from DynamoDB."""
    try:
        response = table.scan(
            FilterExpression=Attr('PK').begins_with('PROPOSAL#')
        )
        items = response.get('Items', [])
        
        proposals_map = {}
        for item in items:
            pk = item.get('PK')
            sk = item.get('SK')
            prop_id = pk.split('#')[1]
            
            if prop_id not in proposals_map:
                proposals_map[prop_id] = {
                    'proposalId': prop_id,
                    'clientName': '',
                    'clientEmail': '',
                    'clientPhone': '',
                    'status': 'DRAFT',
                    'currentVersion': 1,
                    'createdAt': '',
                    'versions': []
                }
                
            if sk == 'METADATA':
                proposals_map[prop_id].update({
                    'clientName': item.get('clientName', 'Anonymous'),
                    'clientEmail': item.get('clientEmail', ''),
                    'clientPhone': item.get('clientPhone', ''),
                    'status': item.get('status', 'DRAFT'),
                    'currentVersion': int(item.get('currentVersion', 1)),
                    'createdAt': item.get('createdAt', '')
                })
            elif sk.startswith('VERSION#'):
                try:
                    version_num = int(sk.split('#')[1])
                except ValueError:
                    continue
                proposals_map[prop_id]['versions'].append({
                    'version': version_num,
                    'title': item.get('title', 'Celebration Proposal'),
                    'description': item.get('description', ''),
                    'budget': float(item.get('budget', 0.0)),
                    'deliverables': item.get('deliverables', []),
                    'terms': item.get('terms', ''),
                    'createdAt': item.get('createdAt', '')
                })
                
        # Format and sort
        for prop_id, prop in proposals_map.items():
            prop['versions'].sort(key=lambda x: x['version'])
            
        return {'statusCode': 200, 'body': list(proposals_map.values())}
    except Exception as e:
        return {'statusCode': 500, 'body': {'error': str(e)}}

def create_proposal(body: dict):
    """Create a new proposal along with its metadata and initial version (Version 1) in DynamoDB."""
    proposal_id = str(uuid.uuid4())
    client_name = body.get('clientName', 'Anonymous')
    client_email = body.get('clientEmail', '')
    client_phone = body.get('clientPhone', '')
    status = body.get('status', 'DRAFT').upper()
    
    # Version 1 elements
    title = body.get('title', 'Celebration Proposal')
    description = body.get('description', '')
    budget = float(body.get('budget', 0.0))
    deliverables = body.get('deliverables', [])
    terms = body.get('terms', '')
    
    created_at = datetime.datetime.utcnow().isoformat()
    
    metadata_item = {
        'PK': f"PROPOSAL#{proposal_id}",
        'SK': "METADATA",
        'GSI1PK': f"CLIENT#{client_email}",
        'GSI1SK': f"PROPOSAL#{proposal_id}",
        'proposalId': proposal_id,
        'clientName': client_name,
        'clientEmail': client_email,
        'clientPhone': client_phone,
        'status': status,
        'currentVersion': 1,
        'createdAt': created_at
    }
    
    version_item = {
        'PK': f"PROPOSAL#{proposal_id}",
        'SK': "VERSION#1",
        'GSI1PK': f"PROPOSAL#{proposal_id}",
        'GSI1SK': "VERSION#1",
        'version': 1,
        'title': title,
        'description': description,
        'budget': budget,
        'deliverables': deliverables,
        'terms': terms,
        'createdAt': created_at
    }
    
    ok1 = put_item(metadata_item)
    ok2 = put_item(version_item)
    
    if ok1 and ok2:
        return {'statusCode': 201, 'body': metadata_item}
    return {'statusCode': 500, 'body': {'error': 'Failed to save proposal records'}}

def update_proposal(prop_id: str, body: dict):
    """Create a brand new proposal version (retaining revision history) or update status in DynamoDB."""
    try:
        metadata = get_item(f"PROPOSAL#{prop_id}", "METADATA")
        if not metadata:
            return {'statusCode': 404, 'body': {'error': 'Proposal not found'}}
            
        status_only = body.get('statusOnly', False)
        
        if status_only:
            new_status = body.get('status', 'DRAFT').upper()
            metadata['status'] = new_status
            put_item(metadata)
            return {'statusCode': 200, 'body': metadata}
            
        current_version = int(metadata.get('currentVersion', 1))
        next_version = current_version + 1
        
        title = body.get('title', 'Celebration Proposal')
        description = body.get('description', '')
        budget = float(body.get('budget', 0.0))
        deliverables = body.get('deliverables', [])
        terms = body.get('terms', '')
        created_at = datetime.datetime.utcnow().isoformat()
        
        new_version_item = {
            'PK': f"PROPOSAL#{prop_id}",
            'SK': f"VERSION#{next_version}",
            'GSI1PK': f"PROPOSAL#{prop_id}",
            'GSI1SK': f"VERSION#{next_version}",
            'version': next_version,
            'title': title,
            'description': description,
            'budget': budget,
            'deliverables': deliverables,
            'terms': terms,
            'createdAt': created_at
        }
        
        metadata['currentVersion'] = next_version
        if 'status' in body:
            metadata['status'] = body['status'].upper()
            
        ok1 = put_item(metadata)
        ok2 = put_item(new_version_item)
        
        if ok1 and ok2:
            return {'statusCode': 200, 'body': metadata}
        return {'statusCode': 500, 'body': {'error': 'Failed to save new proposal version'}}
    except Exception as e:
        return {'statusCode': 500, 'body': {'error': str(e)}}

def delete_proposal(prop_id: str):
    """Delete the proposal and all its historic version revisions from DynamoDB."""
    try:
        all_items = query_by_pk(f"PROPOSAL#{prop_id}")
        success = True
        for item in all_items:
            sk = item.get('SK')
            if sk:
                ok = delete_item(f"PROPOSAL#{prop_id}", sk)
                if not ok:
                    success = False
        if success:
            return {'statusCode': 200, 'body': {'message': 'Proposal deleted successfully'}}
        return {'statusCode': 500, 'body': {'error': 'Failed to delete proposal versions'}}
    except Exception as e:
        return {'statusCode': 500, 'body': {'error': str(e)}}
