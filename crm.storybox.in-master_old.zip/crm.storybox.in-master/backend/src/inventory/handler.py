import uuid
from src.utils.db import put_item, delete_item, table, update_item_attributes, get_item
from boto3.dynamodb.conditions import Key, Attr

def list_inventory():
    """List all camera bodies, lenses, and gear items from DynamoDB."""
    try:
        response = table.scan(
            FilterExpression=Attr('SK').eq('METADATA') & Attr('PK').begins_with('INVENTORY#')
        )
        return {'statusCode': 200, 'body': response.get('Items', [])}
    except Exception as e:
        return {'statusCode': 500, 'body': {'error': str(e)}}

def create_inventory(body: dict):
    """Add a new photography equipment gear item to DynamoDB."""
    item_id = str(uuid.uuid4())
    name = body.get('name')
    category = body.get('category', 'CAMERA').upper() # CAMERA, LENS, DRONE, LIGHTING, ACCESSORY
    serial_number = body.get('serialNumber', '')
    status = body.get('status', 'IN_STUDIO').upper() # IN_STUDIO, ON_LOCATION, MAINTENANCE
    assigned_to = body.get('assignedTo', '')
    
    if not name:
        return {'statusCode': 400, 'body': {'error': 'Gear equipment name required'}}
        
    inv_item = {
        'PK': f"INVENTORY#{item_id}",
        'SK': "METADATA",
        'GSI1PK': f"CATEGORY#{category}",
        'GSI1SK': f"INVENTORY#{item_id}",
        'itemId': item_id,
        'name': name,
        'category': category,
        'serialNumber': serial_number,
        'status': status,
        'assignedTo': assigned_to
    }
    
    success = put_item(inv_item)
    if success:
        return {'statusCode': 201, 'body': inv_item}
    return {'statusCode': 500, 'body': {'error': 'Failed to save inventory item'}}

def update_inventory(item_id: str, body: dict):
    """Update gear assignment or repair status in DynamoDB."""
    allowed_fields = ['name', 'category', 'serialNumber', 'status', 'assignedTo']
    update_attrs = {k: v for k, v in body.items() if k in allowed_fields}
    
    if not update_attrs:
        return {'statusCode': 400, 'body': {'error': 'No valid update parameters'}}
        
    try:
        inv_metadata = get_item(f"INVENTORY#{item_id}", "METADATA")
        if not inv_metadata:
            return {'statusCode': 404, 'body': {'error': 'Inventory item not found'}}
            
        old_cat = inv_metadata.get('category', 'CAMERA')
        new_cat = update_attrs.get('category')
        
        # If category changes, update GSI1PK
        if new_cat and new_cat.upper() != old_cat.upper():
            inv_metadata.update(update_attrs)
            inv_metadata['GSI1PK'] = f"CATEGORY#{new_cat.upper()}"
            put_item(inv_metadata)
            updated = inv_metadata
        else:
            updated = update_item_attributes(f"INVENTORY#{item_id}", "METADATA", update_attrs)
            
        return {'statusCode': 200, 'body': updated}
    except Exception as e:
        return {'statusCode': 500, 'body': {'error': str(e)}}

def delete_inventory(item_id: str):
    """Remove photography equipment gear record from database."""
    success = delete_item(f"INVENTORY#{item_id}", "METADATA")
    if success:
        return {'statusCode': 200, 'body': {'message': 'Inventory item deleted successfully'}}
    return {'statusCode': 404, 'body': {'error': 'Inventory item not found'}}
