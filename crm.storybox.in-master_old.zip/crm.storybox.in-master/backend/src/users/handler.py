import os
import boto3
import uuid
from src.utils.db import table, put_item, query_by_gsi1, update_item_attributes, get_item
from boto3.dynamodb.conditions import Key

COGNITO_CLIENT = boto3.client('cognito-idp', region_name=os.environ.get('AWS_REGION', 'ap-south-2'))
USER_POOL_ID = os.environ.get('USER_POOL_ID')

def list_users(role_group: str):
    """List team crew members or clients from DynamoDB."""
    try:
        if role_group == 'team':
            # Retrieve SUPER_ADMIN, ADMIN, READ_ONLY, and HOA_STAFF
            super_admins = query_by_gsi1("ROLE#SUPER_ADMIN")
            admins = query_by_gsi1("ROLE#ADMIN")
            readonlys = query_by_gsi1("ROLE#READ_ONLY")
            hoa_staff = query_by_gsi1("ROLE#HOA_STAFF")
            users = super_admins + admins + readonlys + hoa_staff
        else:
            # Retrieve clients
            users = query_by_gsi1("ROLE#CLIENT")
            
        return {'statusCode': 200, 'body': users}
    except Exception as e:
        return {'statusCode': 500, 'body': {'error': str(e)}}

def create_user(body: dict):
    """Create a new user in Cognito and store metadata in DynamoDB."""
    email = body.get('email')
    name = body.get('name')
    phone = body.get('phone', '+91 9999999999')
    role = body.get('role', 'CLIENT').upper()
    
    if not email or not name:
        return {'statusCode': 400, 'body': {'error': 'Missing name or email'}}
        
    try:
        # Create in Cognito
        cognito_user_id = str(uuid.uuid4())
        try:
            # We can use AdminCreateUser to invite the user
            COGNITO_CLIENT.admin_create_user(
                UserPoolId=USER_POOL_ID,
                Username=email,
                UserAttributes=[
                    {'Name': 'email', 'Value': email},
                    {'Name': 'email_verified', 'Value': 'true'},
                    {'Name': 'name', 'Value': name},
                    {'Name': 'phone_number', 'Value': phone},
                    {'Name': 'custom:role', 'Value': role}
                ],
                MessageAction='SUPPRESS' # Suppress invitation emails for seed ease, can be removed
            )
            
            # Retrieve Cognito Sub (User ID)
            cog_res = COGNITO_CLIENT.admin_get_user(
                UserPoolId=USER_POOL_ID,
                Username=email
            )
            for attr in cog_res.get('UserAttributes', []):
                if attr['Name'] == 'sub':
                    cognito_user_id = attr['Value']
                    break
        except Exception as cognito_err:
            print(f"Cognito user creation skipped or user already exists: {cognito_err}")
            # If user already exists in Cognito, check if we can retrieve sub
            try:
                cog_res = COGNITO_CLIENT.admin_get_user(
                    UserPoolId=USER_POOL_ID,
                    Username=email
                )
                for attr in cog_res.get('UserAttributes', []):
                    if attr['Name'] == 'sub':
                        cognito_user_id = attr['Value']
                        break
            except Exception:
                # Fallback to local UID if totally fails (e.g. offline testing)
                pass

        # Set Cognito password permanently if provided
        password = body.get('password')
        if password and USER_POOL_ID:
            try:
                COGNITO_CLIENT.admin_set_user_password(
                    UserPoolId=USER_POOL_ID,
                    Username=email,
                    Password=password,
                    Permanent=True
                )
            except Exception as set_pass_err:
                print(f"Failed to set Cognito user password: {set_pass_err}")

        user_item = {
            'PK': f"USER#{cognito_user_id}",
            'SK': "METADATA",
            'GSI1PK': f"ROLE#{role}",
            'GSI1SK': f"USER#{cognito_user_id}",
            'userId': cognito_user_id,
            'email': email,
            'name': name,
            'phone': phone,
            'role': role,
            'status': 'ACTIVE',
            'permissions': body.get('permissions', {'canProof': True, 'canPay': True, 'canViewDetails': True})
        }
        
        success = put_item(user_item)
        if success:
            return {'statusCode': 201, 'body': user_item}
        return {'statusCode': 500, 'body': {'error': 'Failed to save user to database'}}
    except Exception as e:
        return {'statusCode': 500, 'body': {'error': f"Internal error creating user: {str(e)}"}}

def update_user(user_id: str, body: dict):
    """Update a user's details and sync role/attributes to Cognito."""
    allowed_fields = ['name', 'phone', 'role', 'status', 'permissions']
    update_attrs = {k: v for k, v in body.items() if k in allowed_fields}
    
    if not update_attrs:
        return {'statusCode': 400, 'body': {'error': 'No valid update parameters'}}
        
    try:
        user_metadata = get_item(f"USER#{user_id}", "METADATA")
        if not user_metadata:
            return {'statusCode': 404, 'body': {'error': 'User not found'}}
            
        old_role = user_metadata.get('role', 'CLIENT')
        new_role = update_attrs.get('role')
        
        # If role changes, we need to update GSI1PK
        if new_role and new_role.upper() != old_role.upper():
            # Delete old item or just recreate with GSI1PK updated (since we do SET update, we can re-save user item)
            user_metadata.update(update_attrs)
            user_metadata['GSI1PK'] = f"ROLE#{new_role.upper()}"
            put_item(user_metadata)
            updated = user_metadata
        else:
            updated = update_item_attributes(f"USER#{user_id}", "METADATA", update_attrs)
            
        # Synchronize to Cognito Admin User Attributes
        email = user_metadata.get('email')
        if email and USER_POOL_ID:
            attrs = []
            if 'name' in update_attrs:
                attrs.append({'Name': 'name', 'Value': update_attrs['name']})
            if 'phone' in update_attrs:
                attrs.append({'Name': 'phone_number', 'Value': update_attrs['phone']})
            if 'role' in update_attrs:
                attrs.append({'Name': 'custom:role', 'Value': update_attrs['role'].upper()})
                
            try:
                COGNITO_CLIENT.admin_update_user_attributes(
                    UserPoolId=USER_POOL_ID,
                    Username=email,
                    UserAttributes=attrs
                )
            except Exception as cog_err:
                print(f"Failed to update Cognito attributes: {cog_err}")
                
        return {'statusCode': 200, 'body': updated}
    except Exception as e:
        return {'statusCode': 500, 'body': {'error': str(e)}}

def delete_user(user_id: str):
    """Delete a user from DynamoDB and Cognito."""
    try:
        user_metadata = get_item(f"USER#{user_id}", "METADATA")
        if not user_metadata:
            return {'statusCode': 404, 'body': {'error': 'User not found'}}
            
        email = user_metadata.get('email')
        
        # Delete from DynamoDB
        from src.utils.db import table
        table.delete_item(
            Key={
                'PK': f"USER#{user_id}",
                'SK': 'METADATA'
            }
        )
        
        # Delete from Cognito
        if email and USER_POOL_ID:
            try:
                COGNITO_CLIENT.admin_delete_user(
                    UserPoolId=USER_POOL_ID,
                    Username=email
                )
            except Exception as cog_err:
                print(f"Failed to delete Cognito user: {cog_err}")
                
        return {'statusCode': 200, 'body': {'message': 'User deleted successfully'}}
    except Exception as e:
        return {'statusCode': 500, 'body': {'error': str(e)}}
