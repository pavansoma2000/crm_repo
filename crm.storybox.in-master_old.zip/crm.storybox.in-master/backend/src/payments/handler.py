import datetime
import uuid
from src.utils.db import get_item, put_item, update_item_attributes

def create_invoice(project_id: str, body: dict):
    """Generate a new invoice for a photography project (Admin only)."""
    invoice_id = str(uuid.uuid4())
    amount = float(body.get('amount', 0.0))
    description = body.get('description', 'Photography Services')
    due_date = body.get('dueDate', (datetime.date.today() + datetime.timedelta(days=14)).isoformat())
    
    project_metadata = get_item(f"PROJECT#{project_id}", "METADATA")
    if not project_metadata:
        return {'statusCode': 404, 'body': {'error': 'Project not found'}}
        
    invoice_item = {
        'PK': f"PROJECT#{project_id}",
        'SK': f"INVOICE#{invoice_id}",
        'GSI1PK': f"INVOICE#{invoice_id}",
        'GSI1SK': "METADATA",
        'invoiceId': invoice_id,
        'projectId': project_id,
        'clientId': project_metadata.get('clientId'),
        'projectTitle': project_metadata.get('title'),
        'amount': amount,
        'description': description,
        'status': 'PENDING',  # PENDING, PAID, OVERDUE
        'dueDate': due_date,
        'createdAt': datetime.datetime.utcnow().isoformat()
    }
    
    success = put_item(invoice_item)
    if success:
        return {'statusCode': 201, 'body': invoice_item}
    return {'statusCode': 500, 'body': {'error': 'Failed to create invoice'}}

def list_invoices(user_id: str, role: str):
    """List invoices. Admins see all; clients see only their own invoices."""
    from src.utils.db import table
    from boto3.dynamodb.conditions import Attr
    
    if role.upper() in ['ADMIN', 'SUPER_ADMIN', 'PHOTOGRAPHER']:
        try:
            # Query all invoices via scanning or master keys
            response = table.scan(
                FilterExpression=Attr('SK').begins_with('INVOICE#')
            )
            return {'statusCode': 200, 'body': response.get('Items', [])}
        except Exception as e:
            return {'statusCode': 500, 'body': {'error': str(e)}}
    else:
        # Client: Scan or Query using Client's projects.
        # Since Client PK is f"USER#{client_id}" and GSI1 indexes clients,
        # we can scan for invoices filtered by clientId = user_id.
        try:
            response = table.scan(
                FilterExpression=Attr('SK').begins_with('INVOICE#') & Attr('clientId').eq(user_id)
            )
            return {'statusCode': 200, 'body': response.get('Items', [])}
        except Exception as e:
            return {'statusCode': 500, 'body': {'error': str(e)}}

def pay_invoice(project_id: str, invoice_id: str):
    """Complete a payment and transition the invoice status to PAID."""
    invoice = get_item(f"PROJECT#{project_id}", f"INVOICE#{invoice_id}")
    if not invoice:
        return {'statusCode': 404, 'body': {'error': 'Invoice not found'}}
        
    updated = update_item_attributes(
        f"PROJECT#{project_id}",
        f"INVOICE#{invoice_id}",
        {'status': 'PAID', 'paidAt': datetime.datetime.utcnow().isoformat()}
    )
    
    if updated:
        return {'statusCode': 200, 'body': updated}
    return {'statusCode': 500, 'body': {'error': 'Failed to record payment'}}
