import uuid
import datetime
from src.utils.db import put_item, delete_item, table, update_item_attributes, get_item
from boto3.dynamodb.conditions import Key, Attr

def list_subscriptions():
    """List all active software and client hosting subscriptions from DynamoDB."""
    try:
        response = table.scan(
            FilterExpression=Attr('SK').eq('METADATA') & Attr('PK').begins_with('SUBSCRIPTION#')
        )
        return {'statusCode': 200, 'body': response.get('Items', [])}
    except Exception as e:
        return {'statusCode': 500, 'body': {'error': str(e)}}

def create_subscription(body: dict):
    """Add a new software subscription record to DynamoDB."""
    subscription_id = str(uuid.uuid4())
    client_name = body.get('clientName', 'Vendor')
    plan_name = body.get('planName', 'BASIC PROOFING') # BASIC PROOFING, PREMIUM GALLERY, ENTERPRISE RETOUCHING
    price = float(body.get('price', 0.0))
    billing_cycle = body.get('billingCycle', 'ANNUAL').upper() # ANNUAL, MONTHLY
    start_date = body.get('startDate', datetime.date.today().isoformat())
    status = body.get('status', 'ACTIVE').upper() # ACTIVE, EXPIRED, PENDING
    
    sub_item = {
        'PK': f"SUBSCRIPTION#{subscription_id}",
        'SK': "METADATA",
        'GSI1PK': f"STATUS#{status}",
        'GSI1SK': f"SUBSCRIPTION#{subscription_id}",
        'subscriptionId': subscription_id,
        'clientName': client_name,
        'planName': plan_name,
        'price': price,
        'billingCycle': billing_cycle,
        'startDate': start_date,
        'status': status
    }
    
    success = put_item(sub_item)
    if success:
        return {'statusCode': 201, 'body': sub_item}
    return {'statusCode': 500, 'body': {'error': 'Failed to save subscription'}}

def update_subscription(sub_id: str, body: dict):
    """Update subscription billing cycle, status, or price in DynamoDB."""
    allowed_fields = ['clientName', 'planName', 'price', 'billingCycle', 'startDate', 'status']
    update_attrs = {k: v for k, v in body.items() if k in allowed_fields}
    
    if not update_attrs:
        return {'statusCode': 400, 'body': {'error': 'No valid update parameters'}}
        
    try:
        sub_metadata = get_item(f"SUBSCRIPTION#{sub_id}", "METADATA")
        if not sub_metadata:
            return {'statusCode': 404, 'body': {'error': 'Subscription not found'}}
            
        old_status = sub_metadata.get('status', 'ACTIVE')
        new_status = update_attrs.get('status')
        
        # If status changes, update GSI1PK
        if new_status and new_status.upper() != old_status.upper():
            sub_metadata.update(update_attrs)
            sub_metadata['GSI1PK'] = f"STATUS#{new_status.upper()}"
            put_item(sub_metadata)
            updated = sub_metadata
        else:
            updated = update_item_attributes(f"SUBSCRIPTION#{sub_id}", "METADATA", update_attrs)
            
        return {'statusCode': 200, 'body': updated}
    except Exception as e:
        return {'statusCode': 500, 'body': {'error': str(e)}}

def delete_subscription(sub_id: str):
    """Remove subscription record from database."""
    success = delete_item(f"SUBSCRIPTION#{sub_id}", "METADATA")
    if success:
        return {'statusCode': 200, 'body': {'message': 'Subscription deleted successfully'}}
    return {'statusCode': 404, 'body': {'error': 'Subscription not found'}}
