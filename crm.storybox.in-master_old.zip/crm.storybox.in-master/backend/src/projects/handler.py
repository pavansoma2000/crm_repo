import json
import uuid
import datetime
from src.utils.db import get_item, put_item, query_by_pk, query_by_gsi1, update_item_attributes, delete_item
from src.utils.s3 import generate_presigned_upload_url, generate_presigned_download_url

def create_project(body: dict, creator_id: str):
    """Create a new photography project (Admin only)."""
    project_id = str(uuid.uuid4())
    client_id = body.get('clientId')  # The Cognito userId of the client
    title = body.get('title', 'Untitled Shoot')
    project_type = body.get('type', 'Wedding')  # Wedding, Commercial, Portfolio, etc.
    shoot_date = body.get('date', datetime.date.today().isoformat())
    total_amount = float(body.get('totalAmount', 0.0))
    notes = body.get('notes', '')
    
    project_item = {
        'PK': f"PROJECT#{project_id}",
        'SK': "METADATA",
        'GSI1PK': f"USER#{client_id}",
        'GSI1SK': f"PROJECT#{project_id}",
        'projectId': project_id,
        'clientId': client_id,
        'title': title,
        'type': project_type,
        'date': shoot_date,
        'totalAmount': total_amount,
        'status': 'PLANNING',  # PLANNING, IN_PROGRESS, PROOFING, COMPLETED
        'notes': notes,
        'createdAt': datetime.datetime.utcnow().isoformat()
    }
    
    success = put_item(project_item)
    if success:
        return {'statusCode': 201, 'body': project_item}
    return {'statusCode': 500, 'body': {'error': 'Failed to create project'}}

def list_projects(user_id: str, role: str):
    """List projects. Admins see all. Clients see only their own projects."""
    if role.upper() in ['ADMIN', 'SUPER_ADMIN', 'PHOTOGRAPHER']:
        # Fetch all projects. Since DynamoDB doesn't allow scan easily, 
        # we can query by GSI1 using ROLE#CLIENT or list all users of role CLIENT, 
        # or we query using GSI1 for all active clients.
        # For a simple robust admin lookup, query projects by checking a master ADMIN PK or query client users first.
        # Alternatively, we can use Scan on the table filter by Key begins_with(PK, "PROJECT#") and SK = "METADATA".
        # In a single-table design with a modest number of items, a query or scan is fine.
        # Let's perform a table scan for PROJECT# keys with METADATA sort key to retrieve all projects.
        from src.utils.db import table
        from boto3.dynamodb.conditions import Attr
        try:
            response = table.scan(
                FilterExpression=Attr('SK').eq('METADATA') & Attr('PK').begins_with('PROJECT#')
            )
            return {'statusCode': 200, 'body': response.get('Items', [])}
        except Exception as e:
            return {'statusCode': 500, 'body': {'error': str(e)}}
    else:
        # Client: query projects assigned to this specific client user using GSI1
        projects = query_by_gsi1(f"USER#{user_id}", "PROJECT#")
        return {'statusCode': 200, 'body': projects}

def get_project_details(project_id: str, user_id: str, role: str):
    """Retrieve detailed project including metadata, bookings, invoices, and galleries."""
    # Check authorization first: admins/staff see all; clients see only theirs
    project_metadata = get_item(f"PROJECT#{project_id}", "METADATA")
    if not project_metadata:
        return {'statusCode': 404, 'body': {'error': 'Project not found'}}
        
    if role.upper() not in ['ADMIN', 'SUPER_ADMIN', 'PHOTOGRAPHER'] and project_metadata.get('clientId') != user_id:
        return {'statusCode': 403, 'body': {'error': 'Unauthorized'}}
        
    # Query all sub-entities under this PROJECT PK (Bookings, Galleries, Invoices)
    all_entities = query_by_pk(f"PROJECT#{project_id}")
    
    bookings = []
    galleries = []
    invoices = []
    
    for item in all_entities:
        sk = item.get('SK', '')
        if sk == 'METADATA':
            continue
        elif sk.startswith('BOOKING#'):
            bookings.append(item)
        elif sk.startswith('GALLERY#'):
            galleries.append(item)
        elif sk.startswith('INVOICE#'):
            invoices.append(item)
            
    return {
        'statusCode': 200,
        'body': {
            'metadata': project_metadata,
            'bookings': bookings,
            'galleries': galleries,
            'invoices': invoices
        }
    }

def update_project(project_id: str, body: dict):
    """Update a project's status, title, dates, or notes (Admin only)."""
    allowed_fields = ['title', 'status', 'date', 'notes', 'totalAmount']
    update_attrs = {k: v for k, v in body.items() if k in allowed_fields}
    
    if not update_attrs:
        return {'statusCode': 400, 'body': {'error': 'No valid update parameters'}}
        
    updated = update_item_attributes(f"PROJECT#{project_id}", "METADATA", update_attrs)
    if updated:
        return {'statusCode': 200, 'body': updated}
    return {'statusCode': 500, 'body': {'error': 'Failed to update project'}}

def add_booking(project_id: str, body: dict):
    """Add a shoot booking to a project (Admin only)."""
    booking_id = str(uuid.uuid4())
    location = body.get('location', 'Studio')
    start_time = body.get('startTime')  # ISO datetime
    end_time = body.get('endTime')      # ISO datetime
    photographers = body.get('photographers', [])  # list of staff names
    notes = body.get('notes', '')
    
    booking_item = {
        'PK': f"PROJECT#{project_id}",
        'SK': f"BOOKING#{booking_id}",
        'bookingId': booking_id,
        'projectId': project_id,
        'location': location,
        'startTime': start_time,
        'endTime': end_time,
        'photographers': photographers,
        'notes': notes,
        'createdAt': datetime.datetime.utcnow().isoformat()
    }
    
    success = put_item(booking_item)
    if success:
        return {'statusCode': 201, 'body': booking_item}
    return {'statusCode': 500, 'body': {'error': 'Failed to add booking'}}

def create_gallery(project_id: str, body: dict):
    """Create a new media gallery for photo distribution (Admin only)."""
    gallery_id = str(uuid.uuid4())
    name = body.get('name', 'Main Gallery')
    status = body.get('status', 'PROOFING')  # PROOFING, DELIVERED
    
    gallery_item = {
        'PK': f"PROJECT#{project_id}",
        'SK': f"GALLERY#{gallery_id}",
        'GSI1PK': f"GALLERY#{gallery_id}",
        'GSI1SK': "METADATA",
        'galleryId': gallery_id,
        'projectId': project_id,
        'name': name,
        'status': status,
        'images': [],  # List of objects: {'key': s3_key, 'selected': bool, 'comment': str}
        'createdAt': datetime.datetime.utcnow().isoformat()
    }
    
    success = put_item(gallery_item)
    if success:
        return {'statusCode': 201, 'body': gallery_item}
    return {'statusCode': 500, 'body': {'error': 'Failed to create gallery'}}

def generate_bulk_upload_urls(project_id: str, gallery_id: str, body: dict):
    """Generate pre-signed upload URLs for bulk image uploads (Admin only)."""
    file_names = body.get('fileNames', [])
    if not file_names:
        return {'statusCode': 400, 'body': {'error': 'No file names provided'}}
        
    urls = []
    for name in file_names:
        unique_key = f"projects/{project_id}/galleries/{gallery_id}/{uuid.uuid4()}-{name}"
        presigned = generate_presigned_upload_url(unique_key)
        if presigned:
            urls.append({
                'originalName': name,
                'uploadUrl': presigned['upload_url'],
                'objectKey': presigned['object_key']
            })
            
    return {'statusCode': 200, 'body': {'uploads': urls}}

def add_images_to_gallery(project_id: str, gallery_id: str, body: dict):
    """Add newly uploaded image S3 keys to a gallery (Admin only)."""
    image_keys = body.get('imageKeys', [])  # List of S3 object keys
    if not image_keys:
        return {'statusCode': 400, 'body': {'error': 'No image keys provided'}}
        
    gallery = get_item(f"PROJECT#{project_id}", f"GALLERY#{gallery_id}")
    if not gallery:
        return {'statusCode': 404, 'body': {'error': 'Gallery not found'}}
        
    current_images = gallery.get('images', [])
    new_images = [{'key': key, 'selected': False, 'comment': ''} for key in image_keys]
    current_images.extend(new_images)
    
    updated = update_item_attributes(
        f"PROJECT#{project_id}", 
        f"GALLERY#{gallery_id}", 
        {'images': current_images}
    )
    
    if updated:
        # Generate temporary download URLs for all images in response
        for img in updated['images']:
            img['url'] = generate_presigned_download_url(img['key'])
        return {'statusCode': 200, 'body': updated}
    return {'statusCode': 500, 'body': {'error': 'Failed to add images'}}

def get_gallery_photos(project_id: str, gallery_id: str, user_id: str, role: str):
    """Get all photos in a gallery with temporary presigned download links."""
    # Auth verification
    project_metadata = get_item(f"PROJECT#{project_id}", "METADATA")
    if not project_metadata:
        return {'statusCode': 404, 'body': {'error': 'Project not found'}}
    if role.upper() not in ['ADMIN', 'SUPER_ADMIN', 'PHOTOGRAPHER'] and project_metadata.get('clientId') != user_id:
        return {'statusCode': 403, 'body': {'error': 'Unauthorized'}}
        
    gallery = get_item(f"PROJECT#{project_id}", f"GALLERY#{gallery_id}")
    if not gallery:
        return {'statusCode': 404, 'body': {'error': 'Gallery not found'}}
        
    images = gallery.get('images', [])
    # Append fresh download URLs to image keys
    for img in images:
        img['url'] = generate_presigned_download_url(img['key'])
        
    return {'statusCode': 200, 'body': {'gallery': gallery, 'images': images}}

def client_proof_photos(project_id: str, gallery_id: str, body: dict, client_id: str):
    """Update selection and comments on pictures (Client photo proofing)."""
    selections = body.get('selections', {})  # Map of s3_key -> {'selected': bool, 'comment': str}
    
    gallery = get_item(f"PROJECT#{project_id}", f"GALLERY#{gallery_id}")
    if not gallery:
        return {'statusCode': 404, 'body': {'error': 'Gallery not found'}}
        
    current_images = gallery.get('images', [])
    updated_any = False
    
    for img in current_images:
        key = img.get('key')
        if key in selections:
            img['selected'] = selections[key].get('selected', False)
            img['comment'] = selections[key].get('comment', '')
            updated_any = True
            
    if not updated_any:
        return {'statusCode': 400, 'body': {'error': 'No matching image selections to update'}}
        
    updated = update_item_attributes(
        f"PROJECT#{project_id}", 
        f"GALLERY#{gallery_id}", 
        {'images': current_images}
    )
    
    if updated:
        return {'statusCode': 200, 'body': updated}
    return {'statusCode': 500, 'body': {'error': 'Failed to save proofing selections'}}

def delete_project(project_id: str):
    """Delete a photography project and all associated bookings, galleries, and invoices (Admin only)."""
    # Fetch all items under this project partition key
    all_entities = query_by_pk(f"PROJECT#{project_id}")
    
    if not all_entities:
        success = delete_item(f"PROJECT#{project_id}", "METADATA")
        if success:
            return {'statusCode': 200, 'body': {'message': 'Project deleted successfully'}}
        return {'statusCode': 404, 'body': {'error': 'Project not found'}}

    success_all = True
    for item in all_entities:
        sk = item.get('SK')
        if sk:
            ok = delete_item(f"PROJECT#{project_id}", sk)
            if not ok:
                success_all = False
                
    if success_all:
        return {'statusCode': 200, 'body': {'message': 'Project deleted successfully'}}
    return {'statusCode': 500, 'body': {'error': 'Failed to delete some project entities'}}
