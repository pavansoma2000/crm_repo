const fs = require('fs');

let content = fs.readFileSync('src/services/api.ts', 'utf-8');

// We want to remove MOCK_* constants and MOCK arrays
content = content.replace(/const MOCK_[A-Z_]+:.*?\];/gs, '');

// We want to remove getLocalData and setLocalData
content = content.replace(/const getLocalData =.*?};/gs, '');
content = content.replace(/const setLocalData =.*?};/gs, '');

// Remove standard if (API_STAGE_URL) blocks in a safer way
// We know that `if (API_STAGE_URL) {` is used, and usually followed by `} else {`
// Let's use a bracket counter to extract the true block and remove the else block.

function stripMocks(code) {
    let result = '';
    let i = 0;
    while (i < code.length) {
        let match = code.indexOf('if (API_STAGE_URL', i);
        if (match === -1) {
            result += code.slice(i);
            break;
        }

        // Add everything before the match
        result += code.slice(i, match);
        i = match;

        // Skip to the opening brace
        let openBrace = code.indexOf('{', i);
        let braceCount = 1;
        let j = openBrace + 1;
        let ifBlockInner = '';

        while (braceCount > 0 && j < code.length) {
            if (code[j] === '{') braceCount++;
            else if (code[j] === '}') braceCount--;
            if (braceCount > 0) ifBlockInner += code[j];
            j++;
        }

        // Add the inside of the if block
        result += ifBlockInner;

        // Now skip the 'else' block
        let remainder = code.slice(j);
        let elseMatch = remainder.match(/^\s*else\s*\{/);
        if (elseMatch) {
            let elseStart = j + elseMatch[0].length;
            braceCount = 1;
            let k = elseStart;
            while (braceCount > 0 && k < code.length) {
                if (code[k] === '{') braceCount++;
                else if (code[k] === '}') braceCount--;
                k++;
            }
            i = k;
        } else {
            i = j;
        }
    }
    return result;
}

let newContent = stripMocks(content);

// Clean up some remaining local storage auth code like `return getLocalData("storybox_session_user", MOCK_USERS[0]);`
newContent = newContent.replace(/return getLocalData\("storybox_session_user", MOCK_USERS\[0\]\);/, `
    const userStr = localStorage.getItem("storybox_session_user");
    return userStr ? JSON.parse(userStr) : null;
`);

// Clean up currentUser function if there are local fallbacks
// Clean up logout to clear localstorage appropriately
// Note: We need API_STAGE_URL to be defined at the top. Since we removed the if check, let's make sure it's valid.

fs.writeFileSync('src/services/api.ts', newContent);
console.log('Mocks stripped successfully!');
