import React, { useState, useEffect } from 'react';
import { apiService } from './services/api';
import type { User, Project, Booking, Gallery, Invoice, GalleryImage, Lead, InventoryItem, Subscription, Proposal, ProposalVersion, Employee, EmploymentHistory, OnsiteTravel, EmergencyContact, HoaVendor, HoaInventoryItem, HoaPurchaseOrder } from './services/api';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [projects, setProjects] = useState<Project[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [selectedProject, setSelectedProject] = useState<{
    metadata: Project;
    bookings: Booking[];
    galleries: Gallery[];
    invoices: Invoice[];
  } | null>(null);
  const [activeGallery, setActiveGallery] = useState<Gallery | null>(null);
  const [galleryImages, setGalleryImages] = useState<GalleryImage[]>([]);
  const [lightboxImage, setLightboxImage] = useState<GalleryImage | null>(null);
  const [lightboxIndex, setLightboxIndex] = useState<number>(0);
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(window.innerWidth > 1024);

  // Proposals States
  const [proposals, setProposals] = useState<Proposal[]>([]);
  const [showNewProposalModal, setShowNewProposalModal] = useState(false);
  const [showEditProposalModal, setShowEditProposalModal] = useState(false);
  const [selectedProposal, setSelectedProposal] = useState<Proposal | null>(null);
  
  // Proposal Builder fields
  const [propClientEmail, setPropClientEmail] = useState('');
  const [propClientName, setPropClientName] = useState('');
  const [propClientPhone, setPropClientPhone] = useState('');
  const [propTitle, setPropTitle] = useState('Photography Proposal');
  const [propDescription, setPropDescription] = useState('');
  const [propBudget, setPropBudget] = useState(360000);
  const [propDeliverables, setPropDeliverables] = useState<string>('');
  const [propTerms, setPropTerms] = useState('50% booking advance required.');
  const [selectedPropVersionNum, setSelectedPropVersionNum] = useState<number>(1);

  // Expanded CRM States
  const [team, setTeam] = useState<User[]>([]);
  const [clients, setClients] = useState<User[]>([]);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  
  // Employee states
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [isEditingEmployee, setIsEditingEmployee] = useState(false);
  const [showEmployeeFormModal, setShowEmployeeFormModal] = useState(false);

  // HOA States
  const [hoaVendors, setHoaVendors] = useState<HoaVendor[]>([]);
  const [hoaInventory, setHoaInventory] = useState<HoaInventoryItem[]>([]);
  const [hoaPurchaseOrders, setHoaPurchaseOrders] = useState<HoaPurchaseOrder[]>([]);

  // Vendor Modals & Forms
  const [showNewVendorModal, setShowNewVendorModal] = useState(false);
  const [showEditVendorModal, setShowEditVendorModal] = useState(false);
  const [selectedVendor, setSelectedVendor] = useState<HoaVendor | null>(null);
  
  const [newVendorName, setNewVendorName] = useState('');
  const [newVendorContact, setNewVendorContact] = useState('');
  const [newVendorEmail, setNewVendorEmail] = useState('');
  const [newVendorPhone, setNewVendorPhone] = useState('');
  const [newVendorAddress, setNewVendorAddress] = useState('');
  const [newVendorCategory, setNewVendorCategory] = useState('');
  const [newVendorScore, setNewVendorScore] = useState(5);
  const [newVendorShopImage, setNewVendorShopImage] = useState('');
  const [newVendorLocation, setNewVendorLocation] = useState('Chennai');
  const [newVendorCustomLocation, setNewVendorCustomLocation] = useState('');
  const [newVendorSuppliedItems, setNewVendorSuppliedItems] = useState('');

  const [editVendorName, setEditVendorName] = useState('');
  const [editVendorContact, setEditVendorContact] = useState('');
  const [editVendorEmail, setEditVendorEmail] = useState('');
  const [editVendorPhone, setEditVendorPhone] = useState('');
  const [editVendorAddress, setEditVendorAddress] = useState('');
  const [editVendorCategory, setEditVendorCategory] = useState('');
  const [editVendorScore, setEditVendorScore] = useState(5);
  const [editVendorShopImage, setEditVendorShopImage] = useState('');
  const [editVendorLocation, setEditVendorLocation] = useState('');
  const [editVendorCustomLocation, setEditVendorCustomLocation] = useState('');
  const [editVendorSuppliedItems, setEditVendorSuppliedItems] = useState('');

  // HOA Inventory Modals & Forms
  const [showNewHoaItemModal, setShowNewHoaItemModal] = useState(false);
  const [showEditHoaItemModal, setShowEditHoaItemModal] = useState(false);
  const [selectedHoaItem, setSelectedHoaItem] = useState<HoaInventoryItem | null>(null);

  const [newHoaItemName, setNewHoaItemName] = useState('');
  const [newHoaItemSku, setNewHoaItemSku] = useState('');
  const [newHoaItemCategory, setNewHoaItemCategory] = useState('');
  const [newHoaItemStock, setNewHoaItemStock] = useState(0);
  const [newHoaItemReorder, setNewHoaItemReorder] = useState(5);
  const [newHoaItemUnitPrice, setNewHoaItemUnitPrice] = useState(0);
  const [newHoaItemVendorId, setNewHoaItemVendorId] = useState('');
  const [newHoaItemImage, setNewHoaItemImage] = useState('');

  const [editHoaItemName, setEditHoaItemName] = useState('');
  const [editHoaItemSku, setEditHoaItemSku] = useState('');
  const [editHoaItemCategory, setEditHoaItemCategory] = useState('');
  const [editHoaItemStock, setEditHoaItemStock] = useState(0);
  const [editHoaItemReorder, setEditHoaItemReorder] = useState(5);
  const [editHoaItemUnitPrice, setEditHoaItemUnitPrice] = useState(0);
  const [editHoaItemVendorId, setEditHoaItemVendorId] = useState('');
  const [editHoaItemImage, setEditHoaItemImage] = useState('');

  // Purchase Order Modals & Forms
  const [showNewPoModal, setShowNewPoModal] = useState(false);
  const [showEditPoModal, setShowEditPoModal] = useState(false);
  const [selectedPo, setSelectedPo] = useState<HoaPurchaseOrder | null>(null);
  
  const [newPoVendorId, setNewPoVendorId] = useState('');
  const [newPoDeliveryDate, setNewPoDeliveryDate] = useState('');
  const [newPoImage, setNewPoImage] = useState('');
  const [newPoItems, setNewPoItems] = useState<{ sku?: string; name: string; quantity: number; unitPrice: number; total: number }[]>([]);
  
  const [newPoItemName, setNewPoItemName] = useState('');
  const [newPoItemSku, setNewPoItemSku] = useState('');
  const [newPoItemQuantity, setNewPoItemQuantity] = useState(1);
  const [newPoItemUnitPrice, setNewPoItemUnitPrice] = useState(0);

  // Edit PO states
  const [editPoVendorId, setEditPoVendorId] = useState('');
  const [editPoDeliveryDate, setEditPoDeliveryDate] = useState('');
  const [editPoStatus, setEditPoStatus] = useState<'DRAFT' | 'SENT' | 'DELIVERED' | 'CANCELLED'>('DRAFT');
  const [editPoPaymentStatus, setEditPoPaymentStatus] = useState<'UNPAID' | 'PARTIALLY_PAID' | 'PAID'>('UNPAID');
  const [editPoImage, setEditPoImage] = useState('');
  const [editPoItems, setEditPoItems] = useState<{ sku?: string; name: string; quantity: number; unitPrice: number; total: number }[]>([]);
  const [editPoItemName, setEditPoItemName] = useState('');
  const [editPoItemSku, setEditPoItemSku] = useState('');
  const [editPoItemQuantity, setEditPoItemQuantity] = useState(1);
  const [editPoItemUnitPrice, setEditPoItemUnitPrice] = useState(0);

  // Upload progress indicators
  const [isVendorUploading, setIsVendorUploading] = useState(false);
  const [isEditVendorUploading, setIsEditVendorUploading] = useState(false);
  const [isPoUploading, setIsPoUploading] = useState(false);
  const [isEditPoUploading, setIsEditPoUploading] = useState(false);
  const [isInventoryUploading, setIsInventoryUploading] = useState(false);
  const [isEditInventoryUploading, setIsEditInventoryUploading] = useState(false);

  // Sub-tabs and filters for hoa-tracker and hoa-inventory
  const [hoaTrackerTab, setHoaTrackerTab] = useState<'vendors' | 'purchase_orders'>('vendors');
  const [hoaFilterCategory, setHoaFilterCategory] = useState('');
  const [hoaFilterStatus, setHoaFilterStatus] = useState('');
  const [hoaSearchQuery, setHoaSearchQuery] = useState('');
  const [activeProfileTab, setActiveProfileTab] = useState<'overview' | 'identity' | 'financials' | 'history' | 'travel'>('overview');

  // Employee form field states
  const [empName, setEmpName] = useState('');
  const [empEmail, setEmpEmail] = useState('');
  const [empPhone, setEmpPhone] = useState('');
  const [empDesignation, setEmpDesignation] = useState('');
  const [empDepartment, setEmpDepartment] = useState('Production');
  const [empDateOfJoining, setEmpDateOfJoining] = useState('');
  const [empBloodGroup, setEmpBloodGroup] = useState('');
  const [empPersonalEmail, setEmpPersonalEmail] = useState('');
  const [empAddress, setEmpAddress] = useState('');
  
  const [empCtc, setEmpCtc] = useState(0);
  const [empMonthlySalary, setEmpMonthlySalary] = useState(0);
  
  // Bank details form states
  const [empBankName, setEmpBankName] = useState('');
  const [empBankAccountName, setEmpBankAccountName] = useState('');
  const [empBankAccountNumber, setEmpBankAccountNumber] = useState('');
  const [empBankIfscCode, setEmpBankIfscCode] = useState('');
  const [empBankBranch, setEmpBankBranch] = useState('');
  
  // IDs form states
  const [empPanCard, setEmpPanCard] = useState('');
  const [empAadharCard, setEmpAadharCard] = useState('');
  
  // Insurance form states
  const [empInsurancePolicyNumber, setEmpInsurancePolicyNumber] = useState('');
  const [empInsuranceProvider, setEmpInsuranceProvider] = useState('');
  const [empInsuranceSumInsured, setEmpInsuranceSumInsured] = useState(0);
  const [empInsuranceTpaName, setEmpInsuranceTpaName] = useState('');
  const [empInsuranceExpiryDate, setEmpInsuranceExpiryDate] = useState('');
  
  // Lists for history / travel / emergency
  const [empEmploymentHistory, setEmpEmploymentHistory] = useState<EmploymentHistory[]>([]);
  const [empTravelHistory, setEmpTravelHistory] = useState<OnsiteTravel[]>([]);
  const [empEmergencyContacts, setEmpEmergencyContacts] = useState<EmergencyContact[]>([]);
  const [empStatus, setEmpStatus] = useState<'ACTIVE' | 'INACTIVE'>('ACTIVE');

  // List fields for additions
  const [newExpCompany, setNewExpCompany] = useState('');
  const [newExpDesignation, setNewExpDesignation] = useState('');
  const [newExpStartDate, setNewExpStartDate] = useState('');
  const [newExpEndDate, setNewExpEndDate] = useState('');
  const [newExpReason, setNewExpReason] = useState('');

  const [newTravelCountry, setNewTravelCountry] = useState('');
  const [newTravelPurpose, setNewTravelPurpose] = useState('');
  const [newTravelStartDate, setNewTravelStartDate] = useState('');
  const [newTravelEndDate, setNewTravelEndDate] = useState('');
  const [newTravelStatus, setNewTravelStatus] = useState<'PENDING' | 'APPROVED' | 'COMPLETED' | 'CANCELLED'>('PENDING');

  const [newContactName, setNewContactName] = useState('');
  const [newContactRelation, setNewContactRelation] = useState('');
  const [newContactPhone, setNewContactPhone] = useState('');
  
  // Dashboard metrics
  const [stats, setStats] = useState({
    totalProjects: 0,
    activeClients: 0,
    totalRevenue: 0,
    collectedRevenue: 0,
    upcomingShoots: 0
  });

  // Login form states
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  const [errorMsg, setErrorMsg] = useState('');

  // Forgot Password / Password Reset states
  const [isForgotPasswordView, setIsForgotPasswordView] = useState(false);
  const [forgotPasswordStep, setForgotPasswordStep] = useState<1 | 2>(1);
  const [forgotPasswordEmail, setForgotPasswordEmail] = useState('');
  const [forgotPasswordCode, setForgotPasswordCode] = useState('');
  const [forgotPasswordNewPassword, setForgotPasswordNewPassword] = useState('');
  const [forgotPasswordSuccessMsg, setForgotPasswordSuccessMsg] = useState('');

  // Sign Up / Registration states
  const [isSignUpView, setIsSignUpView] = useState(false);
  const [signUpStep, setSignUpStep] = useState<1 | 2>(1);
  const [signUpName, setSignUpName] = useState('');
  const [signUpEmail, setSignUpEmail] = useState('');
  const [signUpPhone, setSignUpPhone] = useState('');
  const [signUpPassword, setSignUpPassword] = useState('');
  const [signUpCode, setSignUpCode] = useState('');
  const [signUpSuccessMsg, setSignUpSuccessMsg] = useState('');

  // Create User Modal states
  const [showCreateUserModal, setShowCreateUserModal] = useState(false);
  const [newUserType, setNewUserType] = useState<'TEAM' | 'CLIENT'>('TEAM');
  const [newUserName, setNewUserName] = useState('');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserPhone, setNewUserPhone] = useState('');
  const [newUserRole, setNewUserRole] = useState<'SUPER_ADMIN' | 'ADMIN' | 'READ_ONLY' | 'CLIENT' | 'HOA_STAFF'>('CLIENT');
  const [newUserPassword, setNewUserPassword] = useState('');

  // Permissions Modal state
  const [showPermissionsModal, setShowPermissionsModal] = useState(false);
  const [permissionUser, setPermissionUser] = useState<User | null>(null);
  const [editName, setEditName] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [editRole, setEditRole] = useState<'SUPER_ADMIN' | 'ADMIN' | 'READ_ONLY' | 'CLIENT' | 'HOA_STAFF'>('CLIENT');
  const [editStatus, setEditStatus] = useState<'ACTIVE' | 'INACTIVE'>('ACTIVE');
  const [editCanProof, setEditCanProof] = useState(true);
  const [editCanPay, setEditCanPay] = useState(true);
  const [editCanViewDetails, setEditCanViewDetails] = useState(true);

  // Form states for creating a new lead
  const [showNewLeadModal, setShowNewLeadModal] = useState(false);
  const [newLeadName, setNewLeadName] = useState('');
  const [newLeadEmail, setNewLeadEmail] = useState('');
  const [newLeadPhone, setNewLeadPhone] = useState('');
  const [newLeadEventType, setNewLeadEventType] = useState('Wedding');
  const [newLeadEventDate, setNewLeadEventDate] = useState('');
  const [newLeadBudget, setNewLeadBudget] = useState(50000);
  const [newLeadNotes, setNewLeadNotes] = useState('');
  const [newLeadStatus, setNewLeadStatus] = useState<'ENQUIRY' | 'LEAD'>('LEAD');

  // Form states for creating a new project
  const [showNewProjectModal, setShowNewProjectModal] = useState(false);
  const [newProjTitle, setNewProjTitle] = useState('');
  const [newProjType, setNewProjType] = useState('Wedding');
  const [newProjDate, setNewProjDate] = useState('');
  const [newProjAmount, setNewProjAmount] = useState(150000);
  const [newProjClientEmail, setNewProjClientEmail] = useState('rohan@gmail.com');
  const [newProjNotes, setNewProjNotes] = useState('');

  // Form states for adding booking
  const [showNewBookingModal, setShowNewBookingModal] = useState(false);
  const [newBookLocation, setNewBookLocation] = useState('');
  const [newBookStart, setNewBookStart] = useState('');
  const [newBookEnd, setNewBookEnd] = useState('');
  const [newBookPhotographers, setNewBookPhotographers] = useState('Kesav TSB');
  const [newBookNotes, setNewBookNotes] = useState('');

  // Form states for creating gallery / uploading
  const [showNewGalleryModal, setShowNewGalleryModal] = useState(false);
  const [newGalleryName, setNewGalleryName] = useState('Main Shoot Deliverables');
  const [mockUploadUrl, setMockUploadUrl] = useState('');

  // Form states for inventory gear
  const [showNewGearModal, setShowNewGearModal] = useState(false);
  const [newGearName, setNewGearName] = useState('');
  const [newGearCategory, setNewGearCategory] = useState<'CAMERA' | 'LENS' | 'DRONE' | 'LIGHTING' | 'ACCESSORY'>('CAMERA');
  const [newGearSerial, setNewGearSerial] = useState('');

  // Form states for subscriptions
  const [showNewSubscriptionModal, setShowNewSubscriptionModal] = useState(false);
  const [newSubClientName, setNewSubClientName] = useState('');
  const [newSubPlanName, setNewSubPlanName] = useState('');
  const [newSubPrice, setNewSubPrice] = useState(1000);
  const [newSubBillingCycle, setNewSubBillingCycle] = useState<'ANNUAL' | 'MONTHLY'>('MONTHLY');
  const [newSubStartDate, setNewSubStartDate] = useState('');
  const [newSubStatus, setNewSubStatus] = useState<'ACTIVE' | 'EXPIRED' | 'PENDING'>('ACTIVE');

  // Form states for invoices
  const [showNewInvoiceModal, setShowNewInvoiceModal] = useState(false);
  const [newInvoiceProjectId, setNewInvoiceProjectId] = useState('');
  const [newInvoiceAmount, setNewInvoiceAmount] = useState(10000);
  const [newInvoiceDescription, setNewInvoiceDescription] = useState('Second Milestone Shoot Payment');
  const [newInvoiceDueDate, setNewInvoiceDueDate] = useState('');

  // Edit Gear States
  const [showEditGearModal, setShowEditGearModal] = useState(false);
  const [selectedGear, setSelectedGear] = useState<InventoryItem | null>(null);
  const [editGearName, setEditGearName] = useState('');
  const [editGearCategory, setEditGearCategory] = useState<'CAMERA' | 'LENS' | 'DRONE' | 'LIGHTING' | 'ACCESSORY'>('CAMERA');
  const [editGearSerial, setEditGearSerial] = useState('');
  const [editGearStatus, setEditGearStatus] = useState<'IN_STUDIO' | 'ON_LOCATION' | 'MAINTENANCE'>('IN_STUDIO');
  const [editGearAssignedTo, setEditGearAssignedTo] = useState('');

  // Edit Subscription States
  const [showEditSubscriptionModal, setShowEditSubscriptionModal] = useState(false);
  const [selectedSubscription, setSelectedSubscription] = useState<Subscription | null>(null);
  const [editSubClientName, setEditSubClientName] = useState('');
  const [editSubPlanName, setEditSubPlanName] = useState('');
  const [editSubPrice, setEditSubPrice] = useState(1000);
  const [editSubBillingCycle, setEditSubBillingCycle] = useState<'ANNUAL' | 'MONTHLY'>('MONTHLY');
  const [editSubStartDate, setEditSubStartDate] = useState('');
  const [editSubStatus, setEditSubStatus] = useState<'ACTIVE' | 'EXPIRED' | 'PENDING'>('ACTIVE');

  // Edit Lead / Conversion States
  const [showEditLeadModal, setShowEditLeadModal] = useState(false);
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [editLeadClientName, setEditLeadClientName] = useState('');
  const [editLeadClientEmail, setEditLeadClientEmail] = useState('');
  const [editLeadClientPhone, setEditLeadClientPhone] = useState('');
  const [editLeadEventType, setEditLeadEventType] = useState('');
  const [editLeadEventDate, setEditLeadEventDate] = useState('');
  const [editLeadBudget, setEditLeadBudget] = useState(1000);
  const [editLeadNotes, setEditLeadNotes] = useState('');
  const [editLeadStatus, setEditLeadStatus] = useState<'ENQUIRY' | 'LEAD' | 'CONVERTED' | 'LOST'>('ENQUIRY');

  // Client proofing selections map
  const [selectionsMap, setSelectionsMap] = useState<{ [key: string]: { selected: boolean; comment: string } }>({});

  useEffect(() => {
    // Check session
    const activeSession = apiService.currentUser();
    if (activeSession) {
      setUser(activeSession);
      setIsSidebarOpen(window.innerWidth > 1024);
      if (activeSession.role === 'HOA_STAFF') {
        setCurrentTab('hoa-tracker');
      }
    }
  }, []);

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);



  const loadData = async () => {
    try {
      const currentRole = user?.role;
      
      if (currentRole === 'SUPER_ADMIN' || currentRole === 'ADMIN' || currentRole === 'READ_ONLY') {
        const projs = await apiService.getProjects();
        const invs = await apiService.getInvoices();
        const props = await apiService.getProposals();
        setProjects(projs);
        setInvoices(invs);
        setProposals(props);
        
        const dashboardStats = await apiService.getDashboardStats();
        setStats(dashboardStats);

        const t = await apiService.getTeam();
        const c = await apiService.getClients();
        const l = await apiService.getLeads();
        const inv = await apiService.getInventory();
        const s = await apiService.getSubscriptions();

        const emps = await apiService.getEmployees();
        setTeam(t);
        setClients(c);
        setLeads(l);
        setInventory(inv);
        setSubscriptions(s);
        setEmployees(emps);
      }

      if (currentRole === 'SUPER_ADMIN' || currentRole === 'HOA_STAFF') {
        const v = await apiService.getHoaVendors();
        const i = await apiService.getHoaInventory();
        const po = await apiService.getHoaPurchaseOrders();
        setHoaVendors(v);
        setHoaInventory(i);
        setHoaPurchaseOrders(po);
      }
    } catch (err: any) {
      console.error("Error loading CRM data", err);
    }
  };

  const handlePrintProposal = (prop: Proposal, ver: ProposalVersion) => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    
    const inclusions = Array.isArray(ver.deliverables) ? ver.deliverables : String(ver.deliverables).split('\n');
    
    printWindow.document.write(`
      <html>
        <head>
          <title>${prop.clientName} - Proposal v${ver.version}</title>
          <link rel="preconnect" href="https://fonts.googleapis.com">
          <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
          <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;1,300;1,400&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
          <style>
            :root {
              --bg-primary: #faf9f6;
              --bg-secondary: #f4f2ec;
              --text-primary: #1c1916;
              --text-secondary: #4a453f;
              --accent-gold: #736248;
              --border-color: #e2ded5;
              --font-display: 'Cormorant Garamond', serif;
              --font-body: 'Inter', sans-serif;
            }
            body {
              background-color: var(--bg-primary);
              color: var(--text-primary);
              font-family: var(--font-body);
              margin: 0;
              padding: 0;
              -webkit-print-color-adjust: exact;
              print-color-adjust: exact;
            }
            .page {
              width: 100vw;
              min-height: 100vh;
              box-sizing: border-box;
              padding: 80px 10%;
              page-break-after: always;
              display: flex;
              flex-direction: column;
              justify-content: center;
              position: relative;
              background-color: var(--bg-primary);
            }
            h1, h2, h3 {
              font-family: var(--font-display);
              font-weight: 300;
              letter-spacing: 0.5px;
            }
            .brand-header {
              font-family: var(--font-display);
              font-size: 14px;
              text-transform: uppercase;
              letter-spacing: 3px;
              color: var(--accent-gold);
              border-bottom: 1px solid var(--border-color);
              padding-bottom: 15px;
              margin-bottom: 60px;
              display: flex;
              justify-content: space-between;
            }
            .cover-title {
              font-size: 64px;
              line-height: 1.1;
              color: var(--text-primary);
              margin-bottom: 30px;
            }
            .cover-subtitle {
              font-size: 20px;
              font-family: var(--font-display);
              font-style: italic;
              color: var(--accent-gold);
              margin-bottom: 50px;
              line-height: 1.5;
            }
            .catalog-img {
              width: 100%;
              height: 380px;
              object-fit: cover;
              border-radius: 4px;
              filter: brightness(0.95);
            }
            .welcome-letter {
              font-size: 16px;
              line-height: 1.8;
              color: var(--text-secondary);
              max-width: 800px;
            }
            .welcome-heading {
              font-size: 44px;
              color: var(--accent-gold);
              margin-bottom: 20px;
            }
            .package-rate {
              font-family: var(--font-display);
              font-size: 42px;
              color: var(--accent-gold);
              border: 1px solid var(--border-color);
              padding: 10px 25px;
              border-radius: 4px;
              background-color: var(--bg-secondary);
            }
            .deliverables-grid {
              display: grid;
              grid-template-columns: 1fr 1fr;
              gap: 20px;
              margin-top: 30px;
            }
            .deliverable-item {
              display: flex;
              align-items: flex-start;
              gap: 12px;
              font-size: 15px;
              line-height: 1.5;
            }
            .bullet-dot {
              color: var(--accent-gold);
              font-size: 18px;
              line-height: 1;
            }
            .terms-box {
              border-top: 1px solid var(--border-color);
              padding-top: 25px;
              margin-top: 40px;
              font-size: 13px;
              color: var(--text-secondary);
              line-height: 1.6;
            }
            .footer-nav {
              position: absolute;
              bottom: 40px;
              left: 10%;
              right: 10%;
              border-top: 1px solid var(--border-color);
              padding-top: 15px;
              display: flex;
              justify-content: space-between;
              font-size: 11px;
              color: var(--text-secondary);
              text-transform: uppercase;
              letter-spacing: 2px;
            }
            @media print {
              body {
                background-color: #fff;
              }
              .page {
                padding: 60px 8%;
                page-break-after: always;
                min-height: 100vh;
              }
            }
          </style>
        </head>
        <body>
          <!-- PAGE 1: COVER -->
          <div class="page">
            <div class="brand-header">
              <span>The Story Box</span>
              <span>Est. 2012 &bull; Hyderabad</span>
            </div>
            <h1 class="cover-title">Weddings, remembered as the stories they actually are.</h1>
            <p class="cover-subtitle">A Celebration Proposal for <strong>${prop.clientName}</strong> &mdash;<br/>For you, and the years to come.</p>
            <img class="catalog-img" src="https://images.unsplash.com/photo-1519741497674-611481863552?q=80&width=1600&auto=format&fit=crop" alt="The Storybox Fine Art Photography" />
            <div class="footer-nav">
              <span>Stories Across Hyderabad & World</span>
              <span>thestorybox.in</span>
            </div>
          </div>

          <!-- PAGE 2: WELCOME -->
          <div class="page">
            <div class="brand-header">
              <span>The Story Box</span>
              <span>Letter</span>
            </div>
            <h2 class="welcome-heading">Hello, dear friends.</h2>
            <div class="welcome-letter">
              <p>Thank you for considering us to tell the story of your wedding.</p>
              <p>Every Indian wedding is its own kind of universe &mdash; its rituals, its families, its quiet corners, and its loudest joys. We have spent years learning how to walk into those universes gently, watch closely, and leave with something the years can't dim.</p>
              <p>What follows is a custom-tailored package curated specifically for your celebrations: <strong>${ver.title}</strong> (Version ${ver.version}).</p>
              <p>Read at your pace. There is no rush, and there is no negotiation hidden in the margins. The numbers are honest, the inclusions are exact, and the door is always open for a conversation.</p>
              <br/>
              <p style="font-family: var(--font-display); font-size: 24px; color: var(--accent-gold); margin: 0;">with warmth, The Story Box &mdash;</p>
            </div>
            <div class="footer-nav">
              <span>A Celebration Proposal</span>
              <span>02 / 04</span>
            </div>
          </div>

          <!-- PAGE 3: DELIVERABLES & INCLUSIONS -->
          <div class="page">
            <div class="brand-header">
              <span>The Story Box</span>
              <span>Curated Packaging</span>
            </div>
            
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
              <div>
                <h2 style="font-size: 42px; margin: 0; color: var(--text-primary);">${ver.title}</h2>
                <p style="font-size: 13px; color: var(--text-secondary); margin-top: 5px;">Custom proposal Version ${ver.version} drafted on ${new Date(ver.createdAt).toLocaleDateString()}</p>
              </div>
              <div class="package-rate">₹${ver.budget.toLocaleString()}</div>
            </div>

            <p style="font-size: 15px; font-style: italic; color: var(--text-secondary); margin-bottom: 30px; line-height: 1.6;">
              "${ver.description}"
            </p>

            <h3 style="font-size: 20px; text-transform: uppercase; letter-spacing: 1px; color: var(--accent-gold); margin-bottom: 20px;">What You'll Receive</h3>
            <div class="deliverables-grid">
              ${inclusions.map(del => `
                <div class="deliverable-item">
                  <span class="bullet-dot">&#10022;</span>
                  <span>${del.trim()}</span>
                </div>
              `).join('')}
            </div>

            <div class="terms-box">
              <h4 style="font-size: 11px; text-transform: uppercase; letter-spacing: 1.5px; color: var(--accent-gold); margin-bottom: 10px;">Terms, Payment & Flow</h4>
              <p>${ver.terms}</p>
            </div>

            <div class="footer-nav">
              <span>Proposal Sheet Details</span>
              <span>03 / 04</span>
            </div>
          </div>

          <!-- PAGE 4: HOW WE WORK & WRAPUP -->
          <div class="page">
            <div class="brand-header">
              <span>The Story Box</span>
              <span>Closing Notes</span>
            </div>
            
            <h2 style="font-size: 48px; color: var(--accent-gold); line-height: 1.1; margin-bottom: 25px;">Ready to lock your date?</h2>
            
            <div style="font-size: 16px; line-height: 1.8; color: var(--text-secondary); margin-bottom: 50px;">
              <p>Reply with your preferred package/version and your wedding date. We'll confirm availability and share the next steps within 24 hours.</p>
              <p>Or if you'd rather talk first &mdash; a fifteen-minute call is always welcome. Some weddings begin with a feeling, not a form.</p>
            </div>

            <div style="display: flex; gap: 40px; border-top: 1px solid var(--border-color); padding-top: 40px;">
              <div>
                <span style="font-size: 10px; text-transform: uppercase; letter-spacing: 1px; color: var(--text-secondary)">WhatsApp</span>
                <p style="font-size: 16px; font-weight: 600; margin-top: 5px;">+91-6309908899</p>
              </div>
              <div>
                <span style="font-size: 10px; text-transform: uppercase; letter-spacing: 1px; color: var(--text-secondary)">Online</span>
                <p style="font-size: 16px; font-weight: 600; margin-top: 5px;">thestorybox.in</p>
              </div>
              <div>
                <span style="font-size: 10px; text-transform: uppercase; letter-spacing: 1px; color: var(--text-secondary)">Instagram</span>
                <p style="font-size: 16px; font-weight: 600; margin-top: 5px;">@thestorybox.photography</p>
              </div>
            </div>

            <div class="footer-nav">
              <span>with warmth, The Story Box</span>
              <span>04 / 04</span>
            </div>
          </div>

          <script>
            window.onload = function() {
              window.print();
            }
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  const handleSignUpRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!signUpName || !signUpEmail || !signUpPassword) {
      setErrorMsg("Please fill in name, email, and password");
      return;
    }
    setErrorMsg('');
    setSignUpSuccessMsg('');
    try {
      await apiService.signUp(signUpName, signUpEmail, signUpPhone, 'CLIENT', signUpPassword);
      setSignUpStep(2);
      setSignUpSuccessMsg("Account registered. A verification code has been sent to your email.");
    } catch (err: any) {
      setErrorMsg(err.message || "Registration failed");
    }
  };

  const handleSignUpConfirm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!signUpCode) {
      setErrorMsg("Please enter the verification code");
      return;
    }
    setErrorMsg('');
    setSignUpSuccessMsg('');
    try {
      await apiService.confirmSignUp(signUpEmail, signUpCode);
      setSignUpSuccessMsg("Account verified successfully. You can now log in.");
      setTimeout(() => {
        setIsSignUpView(false);
        setSignUpStep(1);
        setSignUpName('');
        setSignUpEmail('');
        setSignUpPhone('');
        setSignUpPassword('');
        setSignUpCode('');
        setSignUpSuccessMsg('');
        setLoginEmail(signUpEmail);
      }, 3000);
    } catch (err: any) {
      setErrorMsg(err.message || "Verification failed");
    }
  };

  const handleForgotPasswordRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotPasswordEmail) {
      setErrorMsg("Please enter your email address");
      return;
    }
    setErrorMsg('');
    setForgotPasswordSuccessMsg('');
    try {
      await apiService.forgotPassword(forgotPasswordEmail);
      setForgotPasswordStep(2);
      setForgotPasswordSuccessMsg("A password reset verification code has been sent to your email.");
    } catch (err: any) {
      setErrorMsg(err.message || "Failed to send verification code");
    }
  };

  const handleForgotPasswordConfirm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotPasswordCode || !forgotPasswordNewPassword) {
      setErrorMsg("Please enter the verification code and your new password");
      return;
    }
    setErrorMsg('');
    setForgotPasswordSuccessMsg('');
    try {
      await apiService.confirmForgotPassword(forgotPasswordEmail, forgotPasswordCode, forgotPasswordNewPassword);
      setForgotPasswordSuccessMsg("Password reset successfully. You can now log in with your new password.");
      setTimeout(() => {
        setIsForgotPasswordView(false);
        setForgotPasswordStep(1);
        setForgotPasswordEmail('');
        setForgotPasswordCode('');
        setForgotPasswordNewPassword('');
        setForgotPasswordSuccessMsg('');
      }, 3000);
    } catch (err: any) {
      setErrorMsg(err.message || "Failed to reset password");
    }
  };

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserName || !newUserEmail) {
      alert("Please fill in name and email");
      return;
    }
    try {
      await apiService.createUser({
        name: newUserName,
        email: newUserEmail,
        phone: newUserPhone || '+91 9999999999',
        role: newUserRole,
        status: 'ACTIVE',
        password: newUserPassword || undefined,
        permissions: newUserRole === 'CLIENT' ? { canProof: true, canPay: true, canViewDetails: true } : undefined
      });
      setShowCreateUserModal(false);
      
      // Reset form fields
      setNewUserName('');
      setNewUserEmail('');
      setNewUserPhone('');
      setNewUserPassword('');
      
      loadData();
      alert("User created successfully.");
    } catch (err: any) {
      alert(err.message || "Failed to create user");
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginEmail) {
      setErrorMsg('Please enter a valid email address');
      return;
    }
    try {
      const loggedUser = await apiService.login(loginEmail, loginPassword);
      setUser(loggedUser);
      setIsSidebarOpen(window.innerWidth > 1024);
      setErrorMsg('');
      if (loggedUser.role === 'HOA_STAFF') {
        setCurrentTab('hoa-tracker');
      } else {
        setCurrentTab('dashboard');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Login failed');
    }
  };

  const handleLogout = () => {
    apiService.logout();
    setUser(null);
    setSelectedProject(null);
    setActiveGallery(null);
  };

  const handleNavigate = (tab: string) => {
    setCurrentTab(tab);
    setSelectedProject(null);
    if (window.innerWidth <= 1024) {
      setIsSidebarOpen(false);
    }
  };

  const viewProjectDetails = async (projectId: string) => {
    try {
      const details = await apiService.getProjectDetails(projectId);
      setSelectedProject(details);
      setActiveGallery(null);
    } catch (err) {
      console.error(err);
    }
  };

  // Create Project
  const handleCreateProject = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      let clientId = "";
      const existingClient = clients.find(c => c.email.toLowerCase() === newProjClientEmail.toLowerCase());
      
      if (existingClient) {
        clientId = existingClient.userId;
      } else {
        // Automatically create a client profile for new users
        const namePart = newProjClientEmail.split('@')[0];
        const newClient = await apiService.createUser({
          name: namePart.charAt(0).toUpperCase() + namePart.slice(1),
          email: newProjClientEmail,
          phone: "+91 9999999999",
          role: "CLIENT",
          status: "ACTIVE"
        });
        clientId = newClient.userId;
      }

      await apiService.createProject(
        newProjTitle,
        newProjType,
        newProjDate,
        newProjAmount,
        clientId,
        newProjNotes
      );
      
      // Reset & Reload
      setShowNewProjectModal(false);
      setNewProjTitle('');
      loadData();
    } catch (err) {
      console.error(err);
      alert("Failed to create project. Please verify client details.");
    }
  };

  // Create Gear Inventory Item
  const handleCreateGear = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiService.createInventoryItem(newGearName, newGearCategory, newGearSerial);
      setShowNewGearModal(false);
      setNewGearName('');
      setNewGearSerial('');
      loadData();
    } catch (err) {
      console.error(err);
    }
  };

  // Create Subscription
  const handleCreateSubscription = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiService.createSubscription(
        newSubClientName,
        newSubPlanName,
        newSubPrice,
        newSubBillingCycle,
        newSubStartDate,
        newSubStatus
      );
      setShowNewSubscriptionModal(false);
      setNewSubClientName('');
      setNewSubPlanName('');
      setNewSubPrice(1000);
      setNewSubStartDate('');
      loadData();
    } catch (err) {
      console.error(err);
    }
  };

  // Create or Update Employee
  const handleSaveEmployee = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data: Partial<Employee> = {
        name: empName,
        email: empEmail,
        phone: empPhone,
        designation: empDesignation,
        department: empDepartment,
        dateOfJoining: empDateOfJoining,
        bloodGroup: empBloodGroup,
        personalEmail: empPersonalEmail,
        address: empAddress,
        ctc: Number(empCtc),
        monthlySalary: Number(empMonthlySalary),
        bankDetails: {
          bankName: empBankName,
          accountName: empBankAccountName,
          accountNumber: empBankAccountNumber,
          ifscCode: empBankIfscCode,
          branch: empBankBranch
        },
        panCard: empPanCard,
        aadharCard: empAadharCard,
        healthInsurance: {
          policyNumber: empInsurancePolicyNumber,
          provider: empInsuranceProvider,
          sumInsured: Number(empInsuranceSumInsured),
          tpaName: empInsuranceTpaName,
          expiryDate: empInsuranceExpiryDate
        },
        employmentHistory: empEmploymentHistory,
        travelHistory: empTravelHistory,
        emergencyContacts: empEmergencyContacts,
        status: empStatus
      };

      if (isEditingEmployee && selectedEmployee) {
        const updated = await apiService.updateEmployee(selectedEmployee.employeeId, data);
        setSelectedEmployee(updated);
        alert("Employee profile updated successfully.");
      } else {
        await apiService.createEmployee(data);
        alert("New employee profile created successfully.");
      }
      
      setShowEmployeeFormModal(false);
      resetEmployeeForm();
      loadData();
    } catch (err) {
      console.error(err);
      alert("Failed to save employee profile.");
    }
  };

  const handleEditEmployeeClick = (emp: Employee) => {
    setSelectedEmployee(emp);
    setIsEditingEmployee(true);
    setEmpName(emp.name || '');
    setEmpEmail(emp.email || '');
    setEmpPhone(emp.phone || '');
    setEmpDesignation(emp.designation || '');
    setEmpDepartment(emp.department || 'Production');
    setEmpDateOfJoining(emp.dateOfJoining || '');
    setEmpBloodGroup(emp.bloodGroup || '');
    setEmpPersonalEmail(emp.personalEmail || '');
    setEmpAddress(emp.address || '');
    
    setEmpCtc(emp.ctc || 0);
    setEmpMonthlySalary(emp.monthlySalary || 0);
    
    setEmpBankName(emp.bankDetails?.bankName || '');
    setEmpBankAccountName(emp.bankDetails?.accountName || '');
    setEmpBankAccountNumber(emp.bankDetails?.accountNumber || '');
    setEmpBankIfscCode(emp.bankDetails?.ifscCode || '');
    setEmpBankBranch(emp.bankDetails?.branch || '');
    
    setEmpPanCard(emp.panCard || '');
    setEmpAadharCard(emp.aadharCard || '');
    
    setEmpInsurancePolicyNumber(emp.healthInsurance?.policyNumber || '');
    setEmpInsuranceProvider(emp.healthInsurance?.provider || '');
    setEmpInsuranceSumInsured(emp.healthInsurance?.sumInsured || 0);
    setEmpInsuranceTpaName(emp.healthInsurance?.tpaName || '');
    setEmpInsuranceExpiryDate(emp.healthInsurance?.expiryDate || '');
    
    setEmpEmploymentHistory(emp.employmentHistory || []);
    setEmpTravelHistory(emp.travelHistory || []);
    setEmpEmergencyContacts(emp.emergencyContacts || []);
    setEmpStatus(emp.status || 'ACTIVE');
    
    setShowEmployeeFormModal(true);
  };

  const handleDeleteEmployee = async (empId: string) => {
    if (!window.confirm("Are you sure you want to permanently delete this employee profile? All financial, travel, and emergency details will be removed.")) return;
    try {
      await apiService.deleteEmployee(empId);
      setSelectedEmployee(null);
      loadData();
      alert("Employee profile deleted successfully.");
    } catch (err) {
      console.error(err);
      alert("Failed to delete employee profile.");
    }
  };

  const resetEmployeeForm = () => {
    setIsEditingEmployee(false);
    setEmpName('');
    setEmpEmail('');
    setEmpPhone('');
    setEmpDesignation('');
    setEmpDepartment('Production');
    setEmpDateOfJoining('');
    setEmpBloodGroup('');
    setEmpPersonalEmail('');
    setEmpAddress('');
    setEmpCtc(0);
    setEmpMonthlySalary(0);
    setEmpBankName('');
    setEmpBankAccountName('');
    setEmpBankAccountNumber('');
    setEmpBankIfscCode('');
    setEmpBankBranch('');
    setEmpPanCard('');
    setEmpAadharCard('');
    setEmpInsurancePolicyNumber('');
    setEmpInsuranceProvider('');
    setEmpInsuranceSumInsured(0);
    setEmpInsuranceTpaName('');
    setEmpInsuranceExpiryDate('');
    setEmpEmploymentHistory([]);
    setEmpTravelHistory([]);
    setEmpEmergencyContacts([]);
    setEmpStatus('ACTIVE');
  };

  const handleAddExperience = () => {
    if (!newExpCompany || !newExpDesignation || !newExpStartDate) {
      alert("Please fill in company name, designation, and start date.");
      return;
    }
    const exp: EmploymentHistory = {
      company: newExpCompany,
      designation: newExpDesignation,
      startDate: newExpStartDate,
      endDate: newExpEndDate,
      reasonForLeaving: newExpReason
    };
    setEmpEmploymentHistory([...empEmploymentHistory, exp]);
    setNewExpCompany('');
    setNewExpDesignation('');
    setNewExpStartDate('');
    setNewExpEndDate('');
    setNewExpReason('');
  };

  const handleAddTravel = () => {
    if (!newTravelCountry || !newTravelPurpose || !newTravelStartDate) {
      alert("Please fill in country, purpose, and start date.");
      return;
    }
    const travel: OnsiteTravel = {
      country: newTravelCountry,
      purpose: newTravelPurpose,
      startDate: newTravelStartDate,
      endDate: newTravelEndDate,
      status: newTravelStatus
    };
    setEmpTravelHistory([...empTravelHistory, travel]);
    setNewTravelCountry('');
    setNewTravelPurpose('');
    setNewTravelStartDate('');
    setNewTravelEndDate('');
    setNewTravelStatus('PENDING');
  };

  const handleAddContact = () => {
    if (!newContactName || !newContactRelation || !newContactPhone) {
      alert("Please fill in contact name, relationship, and contact number.");
      return;
    }
    const contact: EmergencyContact = {
      name: newContactName,
      relationship: newContactRelation,
      phone: newContactPhone
    };
    setEmpEmergencyContacts([...empEmergencyContacts, contact]);
    setNewContactName('');
    setNewContactRelation('');
    setNewContactPhone('');
  };

  // Create Invoice
  const handleCreateInvoice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newInvoiceProjectId) {
      alert("Please select a project to invoice");
      return;
    }
    try {
      await apiService.createInvoice(
        newInvoiceProjectId,
        newInvoiceAmount,
        newInvoiceDescription,
        newInvoiceDueDate || new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
      );
      setShowNewInvoiceModal(false);
      setNewInvoiceProjectId('');
      setNewInvoiceAmount(10000);
      setNewInvoiceDescription('Second Milestone Shoot Payment');
      setNewInvoiceDueDate('');
      loadData();
      if (selectedProject && selectedProject.metadata.projectId === newInvoiceProjectId) {
        // Refresh project details
        const details = await apiService.getProjectDetails(newInvoiceProjectId);
        setSelectedProject(details);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Create Lead
  const handleCreateLead = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const created = await apiService.createLead(
        newLeadName,
        newLeadEmail,
        newLeadPhone,
        newLeadEventType,
        newLeadEventDate || new Date().toISOString().split('T')[0],
        newLeadBudget,
        newLeadNotes
      );
      
      if (newLeadStatus === 'LEAD') {
        await apiService.updateLeadStatus(created.leadId, 'LEAD');
      }
      
      setShowNewLeadModal(false);
      setNewLeadName('');
      setNewLeadEmail('');
      setNewLeadPhone('');
      setNewLeadEventType('Wedding');
      setNewLeadEventDate('');
      setNewLeadBudget(50000);
      setNewLeadNotes('');
      loadData();
    } catch (err) {
      console.error(err);
    }
  };

  // Edit Gear Inventory Item
  const handleEditGear = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedGear) return;
    try {
      await apiService.updateInventoryItem(selectedGear.itemId, {
        name: editGearName,
        category: editGearCategory,
        serialNumber: editGearSerial,
        status: editGearStatus,
        assignedTo: editGearAssignedTo
      });
      setShowEditGearModal(false);
      setSelectedGear(null);
      loadData();
    } catch (err) {
      console.error(err);
    }
  };

  // Edit Subscription
  const handleEditSubscription = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSubscription) return;
    try {
      await apiService.updateSubscription(selectedSubscription.subscriptionId, {
        clientName: editSubClientName,
        planName: editSubPlanName,
        price: editSubPrice,
        billingCycle: editSubBillingCycle,
        startDate: editSubStartDate,
        status: editSubStatus
      });
      setShowEditSubscriptionModal(false);
      setSelectedSubscription(null);
      loadData();
    } catch (err) {
      console.error(err);
    }
  };

  // --- HOA HANDLERS ---
  const uploadFileToS3 = async (file: File): Promise<string> => {
    try {
      const { uploadUrl, objectKey } = await apiService.getHoaUploadUrl(file.name, file.type);
      const response = await fetch(uploadUrl, {
        method: 'PUT',
        headers: {
          'Content-Type': file.type
        },
        body: file
      });
      if (!response.ok) {
        throw new Error("Failed to upload image to S3");
      }
      return objectKey;
    } catch (err: any) {
      console.error("Error uploading to S3:", err);
      throw new Error(err.message || "Failed to upload file to S3");
    }
  };

  const handleCreateVendor = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const locationVal = newVendorLocation === 'Other' ? newVendorCustomLocation : newVendorLocation;
      const suppliedItemsList = newVendorSuppliedItems
        .split(',')
        .map(item => item.trim())
        .filter(item => item.length > 0);

      await apiService.createHoaVendor({
        name: newVendorName,
        contactPerson: newVendorContact,
        email: newVendorEmail,
        phone: newVendorPhone,
        address: newVendorAddress,
        category: newVendorCategory,
        performanceScore: Number(newVendorScore),
        shopImage: newVendorShopImage,
        location: locationVal,
        suppliedItems: suppliedItemsList
      });
      setShowNewVendorModal(false);
      loadData();
      alert("Vendor created successfully.");
    } catch (err: any) {
      alert(err.message || "Failed to create vendor");
    }
  };

  const handleEditVendor = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedVendor) return;
    try {
      const locationVal = editVendorLocation === 'Other' ? editVendorCustomLocation : editVendorLocation;
      const suppliedItemsList = editVendorSuppliedItems
        .split(',')
        .map(item => item.trim())
        .filter(item => item.length > 0);

      await apiService.updateHoaVendor(selectedVendor.vendorId, {
        name: editVendorName,
        contactPerson: editVendorContact,
        email: editVendorEmail,
        phone: editVendorPhone,
        address: editVendorAddress,
        category: editVendorCategory,
        performanceScore: Number(editVendorScore),
        shopImage: editVendorShopImage,
        location: locationVal,
        suppliedItems: suppliedItemsList
      });
      setShowEditVendorModal(false);
      setSelectedVendor(null);
      loadData();
      alert("Vendor updated successfully.");
    } catch (err: any) {
      alert(err.message || "Failed to update vendor");
    }
  };

  const handleCreateHoaItem = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiService.createHoaInventoryItem({
        name: newHoaItemName,
        sku: newHoaItemSku,
        category: newHoaItemCategory,
        stockLevel: Number(newHoaItemStock),
        reorderPoint: Number(newHoaItemReorder),
        unitPrice: Number(newHoaItemUnitPrice),
        vendorId: newHoaItemVendorId,
        itemImage: newHoaItemImage || undefined
      });
      setShowNewHoaItemModal(false);
      loadData();
      alert("Inventory item created successfully.");
    } catch (err: any) {
      alert(err.message || "Failed to create item");
    }
  };

  const handleEditHoaItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedHoaItem) return;
    try {
      await apiService.updateHoaInventoryItem(selectedHoaItem.itemId, {
        name: editHoaItemName,
        sku: editHoaItemSku,
        category: editHoaItemCategory,
        stockLevel: Number(editHoaItemStock),
        reorderPoint: Number(editHoaItemReorder),
        unitPrice: Number(editHoaItemUnitPrice),
        vendorId: editHoaItemVendorId,
        itemImage: editHoaItemImage || undefined
      });
      setShowEditHoaItemModal(false);
      setSelectedHoaItem(null);
      loadData();
      alert("Inventory item updated successfully.");
    } catch (err: any) {
      alert(err.message || "Failed to update item");
    }
  };

  const handleAddPoItem = () => {
    if (!newPoItemName) {
      alert("Item name required");
      return;
    }
    const total = newPoItemQuantity * newPoItemUnitPrice;
    setNewPoItems([
      ...newPoItems,
      {
        sku: newPoItemSku || undefined,
        name: newPoItemName,
        quantity: newPoItemQuantity,
        unitPrice: newPoItemUnitPrice,
        total: total
      }
    ]);
    setNewPoItemName('');
    setNewPoItemSku('');
    setNewPoItemQuantity(1);
    setNewPoItemUnitPrice(0);
  };

  const handleCreatePo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPoVendorId) {
      alert("Please select a vendor");
      return;
    }
    if (newPoItems.length === 0) {
      alert("Please add at least one item to the Purchase Order");
      return;
    }
    try {
      const vendor = hoaVendors.find(v => v.vendorId === newPoVendorId);
      const totalAmount = newPoItems.reduce((sum, item) => sum + item.total, 0);
      await apiService.createHoaPurchaseOrder({
        vendorId: newPoVendorId,
        vendorName: vendor ? vendor.name : 'Unknown Vendor',
        deliveryDate: newPoDeliveryDate || undefined,
        items: newPoItems,
        totalAmount: totalAmount,
        status: 'SENT',
        paymentStatus: 'UNPAID',
        poImage: newPoImage || undefined
      });
      setShowNewPoModal(false);
      loadData();
      alert("Purchase Order created and marked as SENT successfully.");
    } catch (err: any) {
      alert(err.message || "Failed to create PO");
    }
  };

  const handleEditPo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPo) return;
    if (editPoItems.length === 0) {
      alert("Please add at least one item to the Purchase Order");
      return;
    }
    try {
      const vendor = hoaVendors.find(v => v.vendorId === editPoVendorId);
      const totalAmount = editPoItems.reduce((sum, item) => sum + item.total, 0);
      await apiService.updateHoaPurchaseOrder(selectedPo.poId, {
        vendorId: editPoVendorId,
        vendorName: vendor ? vendor.name : 'Unknown Vendor',
        deliveryDate: editPoDeliveryDate || undefined,
        items: editPoItems,
        totalAmount: totalAmount,
        status: editPoStatus,
        paymentStatus: editPoPaymentStatus,
        poImage: editPoImage || undefined
      });
      setShowEditPoModal(false);
      setSelectedPo(null);
      loadData();
      alert("Purchase Order updated successfully.");
    } catch (err: any) {
      alert(err.message || "Failed to update PO");
    }
  };

  const handleAddEditPoItem = () => {
    if (!editPoItemName) return;
    const total = editPoItemQuantity * editPoItemUnitPrice;
    setEditPoItems([
      ...editPoItems,
      {
        sku: editPoItemSku || undefined,
        name: editPoItemName,
        quantity: editPoItemQuantity,
        unitPrice: editPoItemUnitPrice,
        total: total
      }
    ]);
    setEditPoItemName('');
    setEditPoItemSku('');
    setEditPoItemQuantity(1);
    setEditPoItemUnitPrice(0);
  };

  const handleRemoveEditPoItem = (index: number) => {
    setEditPoItems(editPoItems.filter((_, idx) => idx !== index));
  };

  // Edit Lead / Conversion
  const handleEditLead = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedLead) return;
    try {
      await apiService.updateLead(selectedLead.leadId, {
        clientName: editLeadClientName,
        clientEmail: editLeadClientEmail,
        clientPhone: editLeadClientPhone,
        eventType: editLeadEventType,
        eventDate: editLeadEventDate,
        budget: editLeadBudget,
        notes: editLeadNotes,
        status: editLeadStatus
      });
      setShowEditLeadModal(false);
      setSelectedLead(null);
      loadData();
    } catch (err) {
      console.error(err);
    }
  };

  // Add Booking
  const handleAddBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject) return;
    try {
      await apiService.addBooking(
        selectedProject.metadata.projectId,
        newBookLocation,
        newBookStart,
        newBookEnd,
        newBookPhotographers.split(','),
        newBookNotes
      );
      setShowNewBookingModal(false);
      viewProjectDetails(selectedProject.metadata.projectId);
    } catch (err) {
      console.error(err);
    }
  };

  // Create Gallery
  const handleCreateGallery = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject) return;
    try {
      const newGal = await apiService.createGallery(selectedProject.metadata.projectId, newGalleryName);
      setShowNewGalleryModal(false);
      viewProjectDetails(selectedProject.metadata.projectId);
      
      // Open the new gallery directly
      openGallery(newGal);
    } catch (err) {
      console.error(err);
    }
  };

  const openGallery = (gallery: Gallery) => {
    setActiveGallery(gallery);
    setGalleryImages(gallery.images);
    
    // Seed selectionsMap
    const initialMap: { [key: string]: { selected: boolean; comment: string } } = {};
    gallery.images.forEach(img => {
      initialMap[img.key] = { selected: img.selected, comment: img.comment };
    });
    setSelectionsMap(initialMap);
  };

  // Mock Upload Image
  const handleMockUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject || !activeGallery) return;
    
    // Use user-entered image URL or Unsplash backup
    const imgUrl = mockUploadUrl || "https://images.unsplash.com/photo-1519741497674-611481863552?q=80&w=600&auto=format&fit=crop";
    try {
      const updatedGal = await apiService.uploadImageToGallery(
        selectedProject.metadata.projectId,
        activeGallery.galleryId,
        imgUrl
      );
      openGallery(updatedGal);
      setMockUploadUrl('');
      // Refresh project panel details
      viewProjectDetails(selectedProject.metadata.projectId);
    } catch (err) {
      console.error(err);
    }
  };

  // Client favorite/toggle proof selection
  const toggleProofImage = (imageKey: string) => {
    const current = selectionsMap[imageKey] || { selected: false, comment: "" };
    const updated = {
      ...selectionsMap,
      [imageKey]: { ...current, selected: !current.selected }
    };
    setSelectionsMap(updated);
    
    // Save to local state for instant rendering response
    setGalleryImages(prev => prev.map(img => img.key === imageKey ? { ...img, selected: !img.selected } : img));
  };

  // Client comment update
  const updateComment = (imageKey: string, comment: string) => {
    const current = selectionsMap[imageKey] || { selected: false, comment: "" };
    const updated = {
      ...selectionsMap,
      [imageKey]: { ...current, comment }
    };
    setSelectionsMap(updated);
    
    // Save to local state
    setGalleryImages(prev => prev.map(img => img.key === imageKey ? { ...img, comment } : img));
  };

  // Save proof selections back to server/storage
  const handleSaveProofing = async () => {
    if (!selectedProject || !activeGallery) return;
    try {
      const updatedGal = await apiService.submitClientSelections(
        selectedProject.metadata.projectId,
        activeGallery.galleryId,
        selectionsMap
      );
      openGallery(updatedGal);
      alert("Selections and feedback comments saved successfully.");
    } catch (err) {
      console.error(err);
    }
  };

  // Mock Pay invoice
  const handleMockPay = async (projectId: string, invoiceId: string) => {
    try {
      await apiService.payInvoice(projectId, invoiceId);
      loadData();
      if (selectedProject) {
        viewProjectDetails(selectedProject.metadata.projectId);
      }
      alert("Payment processed successfully.");
    } catch (err) {
      console.error(err);
    }
  };

  // Fullscreen visual lightboxes
  const launchLightbox = (img: GalleryImage, idx: number) => {
    setLightboxImage(img);
    setLightboxIndex(idx);
  };

  const navigateLightbox = (dir: 'next' | 'prev') => {
    let nextIdx = lightboxIndex;
    if (dir === 'next') {
      nextIdx = (lightboxIndex + 1) % galleryImages.length;
    } else {
      nextIdx = (lightboxIndex - 1 + galleryImages.length) % galleryImages.length;
    }
    setLightboxIndex(nextIdx);
    setLightboxImage(galleryImages[nextIdx]);
  };

  if (!user) {
    return (
      <div className="flex-center" style={{ minHeight: '100vh', background: 'radial-gradient(circle, #fcfbfa 0%, #f5f3ee 100%)', padding: '20px' }}>
        <div className="card" style={{ maxWidth: '420px', width: '100%', border: '1px solid var(--accent-gold-border)' }}>
          <div style={{ textAlign: 'center', marginBottom: '30px' }}>
            <h1 style={{ fontSize: '38px', fontWeight: 300, letterSpacing: '3px', color: 'var(--text-primary)', fontFamily: 'var(--font-display)', textTransform: 'uppercase' }}>THE STORY BOX</h1>
            <p style={{ fontSize: '10px', textTransform: 'uppercase', letterSpacing: '4px', color: 'var(--accent-gold)', marginTop: '4px', fontWeight: 400, fontFamily: 'var(--font-body)' }}>B Y  K A R A N  S O M A</p>
          </div>

          {errorMsg && (
            <div style={{ padding: '10px 14px', backgroundColor: 'rgba(239, 68, 68, 0.1)', color: 'var(--danger)', borderRadius: '4px', fontSize: '13px', marginBottom: '20px', border: '1px solid rgba(239, 68, 68, 0.2)' }}>
              {errorMsg}
            </div>
          )}

          {forgotPasswordSuccessMsg && (
            <div style={{ padding: '10px 14px', backgroundColor: 'rgba(16, 185, 129, 0.1)', color: 'var(--success)', borderRadius: '4px', fontSize: '13px', marginBottom: '20px', border: '1px solid rgba(16, 185, 129, 0.2)' }}>
              {forgotPasswordSuccessMsg}
            </div>
          )}

          {signUpSuccessMsg && (
            <div style={{ padding: '10px 14px', backgroundColor: 'rgba(16, 185, 129, 0.1)', color: 'var(--success)', borderRadius: '4px', fontSize: '13px', marginBottom: '20px', border: '1px solid rgba(16, 185, 129, 0.2)' }}>
              {signUpSuccessMsg}
            </div>
          )}

          {isSignUpView ? (
            <div>
              <div className="flex-between" style={{ marginBottom: '20px' }}>
                <h2 style={{ fontSize: '24px', fontWeight: 300, display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <span style={{ fontSize: '20px' }}>✨</span>
                  Create Client Account
                </h2>
                <p style={{ fontSize: '12px', color: 'var(--text-secondary)', marginTop: '4px' }}>
                  {signUpStep === 1 
                    ? "Register your email and details to access the storybox portal." 
                    : "Enter the verification code sent to your registered email."}
                </p>
              </div>

              {signUpStep === 1 ? (
                <form onSubmit={handleSignUpRequest}>
                  <div className="form-group" style={{ marginBottom: '15px' }}>
                    <label className="form-label">Full Name</label>
                    <input
                      type="text"
                      className="form-control"
                      required
                      placeholder="e.g. Rohan Sharma"
                      value={signUpName}
                      onChange={(e) => setSignUpName(e.target.value)}
                    />
                  </div>

                  <div className="form-group" style={{ marginBottom: '15px' }}>
                    <label className="form-label">Email Address</label>
                    <input
                      type="email"
                      className="form-control"
                      required
                      placeholder="e.g. rohan@gmail.com"
                      value={signUpEmail}
                      onChange={(e) => setSignUpEmail(e.target.value)}
                    />
                  </div>

                  <div className="form-group" style={{ marginBottom: '15px' }}>
                    <label className="form-label">Contact Phone</label>
                    <input
                      type="text"
                      className="form-control"
                      required
                      placeholder="e.g. +91 9999999999"
                      value={signUpPhone}
                      onChange={(e) => setSignUpPhone(e.target.value)}
                    />
                  </div>

                  <div className="form-group" style={{ marginBottom: '20px' }}>
                    <label className="form-label">Account Password</label>
                    <input
                      type="password"
                      className="form-control"
                      required
                      placeholder="At least 8 characters with numbers"
                      value={signUpPassword}
                      onChange={(e) => setSignUpPassword(e.target.value)}
                    />
                  </div>

                  <button type="submit" className="btn btn-primary" style={{ width: '100%', height: '45px' }}>
                    Register Account
                  </button>

                  <button 
                    type="button" 
                    onClick={() => { setIsSignUpView(false); setErrorMsg(''); setSignUpSuccessMsg(''); }}
                    className="btn btn-secondary" 
                    style={{ width: '100%', marginTop: '10px', height: '45px' }}
                  >
                    Back to Login
                  </button>
                </form>
              ) : (
                <form onSubmit={handleSignUpConfirm}>
                  <div className="form-group" style={{ marginBottom: '15px' }}>
                    <label className="form-label">Email Address</label>
                    <input
                      type="email"
                      className="form-control"
                      disabled
                      value={signUpEmail}
                    />
                  </div>

                  <div className="form-group" style={{ marginBottom: '15px' }}>
                    <label className="form-label">Verification OTP Code</label>
                    <input
                      type="text"
                      className="form-control"
                      required
                      placeholder="Enter 6-digit confirmation code"
                      value={signUpCode}
                      onChange={(e) => setSignUpCode(e.target.value)}
                    />
                  </div>

                  <button type="submit" className="btn btn-primary" style={{ width: '100%', height: '45px' }}>
                    Confirm Verification OTP
                  </button>

                  <button 
                    type="button" 
                    onClick={() => { setSignUpStep(1); setSignUpSuccessMsg(''); setErrorMsg(''); }}
                    className="btn btn-secondary" 
                    style={{ width: '100%', marginTop: '10px', height: '45px' }}
                  >
                    Change Registration Info
                  </button>
                </form>
              )}
            </div>
          ) : isForgotPasswordView ? (
            <div>
              <div style={{ marginBottom: '20px' }}>
                <h3 style={{ fontSize: '20px', fontWeight: 300, color: 'var(--text-primary)' }}>Reset Your Password</h3>
                <p style={{ fontSize: '12px', color: 'var(--text-secondary)', marginTop: '4px' }}>
                  {forgotPasswordStep === 1 
                    ? "Enter your registered email address to receive a verification code." 
                    : "Enter the code sent to your email and choose a new password."}
                </p>
              </div>

              {forgotPasswordStep === 1 ? (
                <form onSubmit={handleForgotPasswordRequest}>
                  <div className="form-group" style={{ marginBottom: '15px' }}>
                    <label className="form-label">Email Address</label>
                    <input
                      type="email"
                      className="form-control"
                      required
                      placeholder="e.g. kesav@thestorybox.in"
                      value={forgotPasswordEmail}
                      onChange={(e) => setForgotPasswordEmail(e.target.value)}
                    />
                  </div>

                  <button type="submit" className="btn btn-primary" style={{ width: '100%', height: '45px' }}>
                    Send Verification Code
                  </button>

                  <button 
                    type="button" 
                    onClick={() => { setIsForgotPasswordView(false); setErrorMsg(''); }}
                    className="btn btn-secondary" 
                    style={{ width: '100%', marginTop: '10px', height: '45px' }}
                  >
                    Back to Login
                  </button>
                </form>
              ) : (
                <form onSubmit={handleForgotPasswordConfirm}>
                  <div className="form-group" style={{ marginBottom: '15px' }}>
                    <label className="form-label">Email Address</label>
                    <input
                      type="email"
                      className="form-control"
                      disabled
                      value={forgotPasswordEmail}
                    />
                  </div>

                  <div className="form-group" style={{ marginBottom: '15px' }}>
                    <label className="form-label">Verification Code</label>
                    <input
                      type="text"
                      className="form-control"
                      required
                      placeholder="Enter 6-digit code"
                      value={forgotPasswordCode}
                      onChange={(e) => setForgotPasswordCode(e.target.value)}
                    />
                  </div>

                  <div className="form-group" style={{ marginBottom: '15px' }}>
                    <label className="form-label">New Password</label>
                    <input
                      type="password"
                      className="form-control"
                      required
                      placeholder="••••••••"
                      value={forgotPasswordNewPassword}
                      onChange={(e) => setForgotPasswordNewPassword(e.target.value)}
                    />
                  </div>

                  <button type="submit" className="btn btn-primary" style={{ width: '100%', height: '45px' }}>
                    Confirm Password Reset
                  </button>

                  <button 
                    type="button" 
                    onClick={() => { setForgotPasswordStep(1); setForgotPasswordSuccessMsg(''); setErrorMsg(''); }}
                    className="btn btn-secondary" 
                    style={{ width: '100%', marginTop: '10px', height: '45px' }}
                  >
                    Resend Code
                  </button>
                </form>
              )}
            </div>
          ) : (
            <form onSubmit={handleLogin}>
              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Email Address</label>
                <input
                  type="email"
                  className="form-control"
                  required
                  placeholder="e.g. email@thestorybox.in"
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                />
              </div>

              <div className="form-group" style={{ marginBottom: '15px' }}>
                <div className="flex-between" style={{ marginBottom: '5px' }}>
                  <label className="form-label" style={{ marginBottom: 0 }}>Account Password</label>
                  <button 
                    type="button" 
                    onClick={() => { setIsForgotPasswordView(true); setIsSignUpView(false); setErrorMsg(''); }}
                    style={{ background: 'none', border: 'none', color: 'var(--accent-gold)', fontSize: '11px', cursor: 'pointer', padding: 0 }}
                  >
                    Forgot Password?
                  </button>
                </div>
                <input
                  type="password"
                  className="form-control"
                  required
                  placeholder="••••••••"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                />
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '10px', height: '45px' }}>
                Sign In to Portal
              </button>

              <div style={{ textAlign: 'center', marginTop: '18px' }}>
                <span className="text-muted" style={{ fontSize: '13px' }}>New to Storybox? </span>
                <button 
                  type="button" 
                  onClick={() => { setIsSignUpView(true); setIsForgotPasswordView(false); setErrorMsg(''); setSignUpSuccessMsg(''); }}
                  style={{ background: 'none', border: 'none', color: 'var(--accent-gold)', fontSize: '13px', cursor: 'pointer', padding: 0, fontWeight: 500 }}
                >
                  Register Client Account
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="app-container">
      {/* MOBILE BAR HEADER */}
      <div className="mobile-header">
        <button onClick={() => setIsSidebarOpen(true)} className="mobile-menu-btn">
          ☰
        </button>
        <span className="mobile-brand-title">THE STORY BOX</span>
        <div style={{ width: '36px' }}></div>
      </div>

      {/* SHUTTER TOGGLE HANDLE */}
      <button
        onClick={() => setIsSidebarOpen(!isSidebarOpen)}
        className="shutter-handle"
        style={{
          position: 'fixed',
          left: isSidebarOpen ? '245px' : '15px',
          top: '30px',
          zIndex: 110,
          width: '30px',
          height: '30px',
          borderRadius: '50%',
          backgroundColor: 'var(--accent-gold)',
          color: '#ffffff',
          border: 'none',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          cursor: 'pointer',
          boxShadow: 'var(--shadow-premium)',
          transition: 'var(--transition-smooth)',
          fontSize: '14px',
          fontWeight: 'bold',
        }}
        title={isSidebarOpen ? "Collapse Sidebar" : "Expand Sidebar"}
      >
        {isSidebarOpen ? '‹' : '›'}
      </button>

      {/* SIDEBAR NAVIGATION */}
      <div className={`sidebar ${isSidebarOpen ? 'open' : ''}`}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '40px' }}>
          <div>
            <h2 style={{ fontSize: '24px', fontWeight: 300, letterSpacing: '2px', color: 'var(--text-primary)', fontFamily: 'var(--font-display)', textTransform: 'uppercase' }}>THE STORY BOX</h2>
            <p style={{ fontSize: '9px', textTransform: 'uppercase', letterSpacing: '3px', color: 'var(--accent-gold)', marginTop: '2px', fontWeight: 400, fontFamily: 'var(--font-body)' }}>B Y  K A R A N  S O M A</p>
          </div>
          <button onClick={() => setIsSidebarOpen(false)} className="sidebar-close-btn">
            ✕
          </button>
        </div>

        <nav style={{ display: 'flex', flexDirection: 'column', gap: '10px', flex: 1 }}>
          {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN' || user.role === 'READ_ONLY') && (
            <button
              onClick={() => handleNavigate('dashboard')}
              className={`btn ${currentTab === 'dashboard' && !selectedProject ? 'btn-primary' : 'btn-secondary'}`}
              style={{ justifyContent: 'flex-start', border: 'none', padding: '12px 16px' }}
            >
              Dashboard
            </button>
          )}

          <button
            onClick={() => handleNavigate('projects')}
            className={`btn ${currentTab === 'projects' && !selectedProject ? 'btn-primary' : 'btn-secondary'}`}
            style={{ justifyContent: 'flex-start', border: 'none', padding: '12px 16px' }}
          >
            {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN' || user.role === 'READ_ONLY') 
              ? 'Projects' 
              : (user.role === 'HOA_STAFF' ? 'Dashboard' : 'My Shoots')}
          </button>

          {user.role === 'SUPER_ADMIN' && (
            <button
              onClick={() => handleNavigate('invoices')}
              className={`btn ${currentTab === 'invoices' && !selectedProject ? 'btn-primary' : 'btn-secondary'}`}
              style={{ justifyContent: 'flex-start', border: 'none', padding: '12px 16px' }}
            >
              Invoices & Revenue
            </button>
          )}

          {user.role === 'CLIENT' && (
            <button
              onClick={() => handleNavigate('invoices')}
              className={`btn ${currentTab === 'invoices' && !selectedProject ? 'btn-primary' : 'btn-secondary'}`}
              style={{ justifyContent: 'flex-start', border: 'none', padding: '12px 16px' }}
            >
              My Invoices & Payments
            </button>
          )}

          {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') && (
            <button
              onClick={() => handleNavigate('proposals')}
              className={`btn ${currentTab === 'proposals' && !selectedProject ? 'btn-primary' : 'btn-secondary'}`}
              style={{ justifyContent: 'flex-start', border: 'none', padding: '12px 16px' }}
            >
              Proposals
            </button>
          )}

          {user.role === 'CLIENT' && (
            <button
              onClick={() => handleNavigate('proposals')}
              className={`btn ${currentTab === 'proposals' && !selectedProject ? 'btn-primary' : 'btn-secondary'}`}
              style={{ justifyContent: 'flex-start', border: 'none', padding: '12px 16px' }}
            >
              My Proposals
            </button>
          )}

          {user.role === 'SUPER_ADMIN' && (
            <button
              onClick={() => handleNavigate('team')}
              className={`btn ${currentTab === 'team' && !selectedProject ? 'btn-primary' : 'btn-secondary'}`}
              style={{ justifyContent: 'flex-start', border: 'none', padding: '12px 16px' }}
            >
              Team
            </button>
          )}

          {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') && (
            <button
              onClick={() => handleNavigate('insights')}
              className={`btn ${currentTab === 'insights' && !selectedProject ? 'btn-primary' : 'btn-secondary'}`}
              style={{ justifyContent: 'flex-start', border: 'none', padding: '12px 16px' }}
            >
              Team Insights
            </button>
          )}

          {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') && (
            <>
              <button
                onClick={() => handleNavigate('clients')}
                className={`btn ${currentTab === 'clients' && !selectedProject ? 'btn-primary' : 'btn-secondary'}`}
                style={{ justifyContent: 'flex-start', border: 'none', padding: '12px 16px' }}
              >
                Clients
              </button>

              <button
                onClick={() => handleNavigate('enquiries')}
                className={`btn ${currentTab === 'enquiries' && !selectedProject ? 'btn-primary' : 'btn-secondary'}`}
                style={{ justifyContent: 'flex-start', border: 'none', padding: '12px 16px' }}
              >
                Enquiries
              </button>

              <button
                onClick={() => handleNavigate('leads')}
                className={`btn ${currentTab === 'leads' && !selectedProject ? 'btn-primary' : 'btn-secondary'}`}
                style={{ justifyContent: 'flex-start', border: 'none', padding: '12px 16px' }}
              >
                Leads
              </button>

              <button
                onClick={() => handleNavigate('conversions')}
                className={`btn ${currentTab === 'conversions' && !selectedProject ? 'btn-primary' : 'btn-secondary'}`}
                style={{ justifyContent: 'flex-start', border: 'none', padding: '12px 16px' }}
              >
                Conversions
              </button>
            </>
          )}

          {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN' || user.role === 'READ_ONLY') && (
            <button
              onClick={() => handleNavigate('inventory')}
              className={`btn ${currentTab === 'inventory' && !selectedProject ? 'btn-primary' : 'btn-secondary'}`}
              style={{ justifyContent: 'flex-start', border: 'none', padding: '12px 16px' }}
            >
              Inventory
            </button>
          )}

          {user.role === 'SUPER_ADMIN' && (
            <button
              onClick={() => handleNavigate('subscriptions')}
              className={`btn ${currentTab === 'subscriptions' && !selectedProject ? 'btn-primary' : 'btn-secondary'}`}
              style={{ justifyContent: 'flex-start', border: 'none', padding: '12px 16px' }}
            >
              Subscriptions
            </button>
          )}

          {(user.role === 'SUPER_ADMIN' || user.role === 'HOA_STAFF') && (
            <>
              <button
                onClick={() => handleNavigate('hoa-tracker')}
                className={`btn ${currentTab === 'hoa-tracker' && !selectedProject ? 'btn-primary' : 'btn-secondary'}`}
                style={{ justifyContent: 'flex-start', border: 'none', padding: '12px 16px' }}
              >
                hoa-tracker
              </button>

              <button
                onClick={() => handleNavigate('hoa-inventory')}
                className={`btn ${currentTab === 'hoa-inventory' && !selectedProject ? 'btn-primary' : 'btn-secondary'}`}
                style={{ justifyContent: 'flex-start', border: 'none', padding: '12px 16px' }}
              >
                hoa-Inventory
              </button>
            </>
          )}
        </nav>

        <div style={{ marginTop: 'auto', paddingTop: '20px', borderTop: '1px solid var(--border-color)' }}>
          <div style={{ marginBottom: '15px' }}>
            <p style={{ fontSize: '13px', fontWeight: 500 }}>{user.name}</p>
            <span className="badge badge-proofing" style={{ fontSize: '9px', marginTop: '4px' }}>{user.role}</span>
          </div>
          <button 
            onClick={() => { handleLogout(); setIsSidebarOpen(false); }} 
            className="btn btn-danger" 
            style={{ width: '100%', fontSize: '12px', padding: '8px' }}
          >
            Log Out
          </button>
        </div>
      </div>

      {/* DRAWER MENU OVERLAY BACKDROP */}
      {isSidebarOpen && (
        <div className="sidebar-overlay" onClick={() => setIsSidebarOpen(false)}></div>
      )}

      {/* MAIN VIEWPORT PANEL */}
      <main className={`main-content ${isSidebarOpen ? 'sidebar-open' : ''}`}>
        
        {/* --- DETAIL SCREEN: PROJECT & PROOFING VIEW --- */}
        {selectedProject ? (
          <div>
            <div className="flex-between" style={{ marginBottom: '30px', flexWrap: 'wrap', gap: '15px' }}>
              <div>
                <button
                  onClick={() => setSelectedProject(null)}
                  className="text-muted"
                  style={{ background: 'none', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '5px', fontSize: '13px', marginBottom: '8px' }}
                >
                  ← Back to active list
                </button>
                <h1 style={{ fontSize: '32px' }}>{selectedProject.metadata.title}</h1>
                <p className="text-muted" style={{ fontSize: '13px', marginTop: '4px' }}>
                  Category: <strong>{selectedProject.metadata.type}</strong> | Shoot Date: <strong>{selectedProject.metadata.date}</strong>
                </p>
              </div>

              <div style={{ display: 'flex', gap: '10px' }}>
                <span className={`badge badge-${selectedProject.metadata.status.toLowerCase()}`} style={{ padding: '8px 16px', fontSize: '12px' }}>
                  {selectedProject.metadata.status}
                </span>
                {user.role === 'ADMIN' && (
                  <select
                    className="form-control"
                    value={selectedProject.metadata.status}
                    onChange={(e) => {
                      apiService.updateProjectStatus(selectedProject.metadata.projectId, e.target.value as any);
                      viewProjectDetails(selectedProject.metadata.projectId);
                    }}
                    style={{ padding: '4px 10px', fontSize: '12px', width: 'auto' }}
                  >
                    <option value="PLANNING">Planning</option>
                    <option value="IN_PROGRESS">In Progress</option>
                    <option value="PROOFING">Proofing</option>
                    <option value="COMPLETED">Completed</option>
                  </select>
                )}
              </div>
            </div>

            {/* Sub-tabs layout: Bookings, Galleries, Invoices */}
            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '30px', alignItems: 'start' }}>
              
              {/* LEFT SIDE: CALENDAR EVENTS / WORKFLOW GALLERIES */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '30px' }}>
                
                {/* GALLERY COMPONENT */}
                {activeGallery ? (
                  <div className="card">
                    <div className="flex-between" style={{ marginBottom: '20px' }}>
                      <div>
                        <h3 className="text-gold" style={{ fontSize: '20px' }}>Proofing Gallery: {activeGallery.name}</h3>
                        <p className="text-muted" style={{ fontSize: '12px' }}>
                          Select your favorite shots by clicking the checkmark/heart, add edit feedback, and click save.
                        </p>
                      </div>
                      <div style={{ display: 'flex', gap: '10px' }}>
                        {user.role === 'CLIENT' && (
                          <button onClick={handleSaveProofing} className="btn btn-primary" style={{ padding: '8px 16px', fontSize: '12px' }}>
                            Save Proof Selections
                          </button>
                        )}
                        <button onClick={() => setActiveGallery(null)} className="btn btn-secondary" style={{ padding: '8px 16px', fontSize: '12px' }}>
                          Close Gallery
                        </button>
                      </div>
                    </div>

                    {/* MOCK UPLOAD TOOL (Admin ONLY) */}
                    {user.role === 'ADMIN' && (
                      <form onSubmit={handleMockUpload} className="flex-between" style={{ gap: '15px', padding: '15px', border: '1px dashed var(--border-color)', borderRadius: '8px', marginBottom: '25px', backgroundColor: 'rgba(0,0,0,0.2)' }}>
                        <div style={{ flex: 1 }}>
                          <p style={{ fontSize: '12px', fontWeight: 600, marginBottom: '6px' }}>Simulate Photographer Photo Uploads</p>
                          <input
                            type="text"
                            placeholder="Enter Image URL (e.g. Unsplash picture link, or leave blank to mock auto-seed)"
                            className="form-control"
                            value={mockUploadUrl}
                            onChange={(e) => setMockUploadUrl(e.target.value)}
                            style={{ height: '36px', fontSize: '12px' }}
                          />
                        </div>
                        <button type="submit" className="btn btn-primary" style={{ alignSelf: 'flex-end', height: '36px', fontSize: '12px' }}>
                          Upload Picture
                        </button>
                      </form>
                    )}

                    {galleryImages.length === 0 ? (
                      <div style={{ textAlign: 'center', padding: '40px 20px', border: '1px dashed var(--border-color)', borderRadius: '8px' }}>
                        <p className="text-muted">No pictures in this gallery yet.</p>
                      </div>
                    ) : (
                      <div className="gallery-grid">
                        {galleryImages.map((img, idx) => (
                          <div key={img.key} className="gallery-card" onClick={() => launchLightbox(img, idx)}>
                            <img src={img.url} className="gallery-img" alt="Gallery shoot" />
                            
                            {/* FAVORITE MARKER */}
                            <div 
                              className={`gallery-proof-indicator ${img.selected ? 'selected' : ''}`}
                              onClick={(e) => {
                                e.stopPropagation();
                                if (user.role === 'CLIENT') toggleProofImage(img.key);
                              }}
                              style={{ cursor: user.role === 'CLIENT' ? 'pointer' : 'default' }}
                            >
                              ★
                            </div>

                            <div className="gallery-overlay">
                              <p style={{ fontSize: '11px', fontWeight: 600 }}>IMAGE PROOF</p>
                              {img.comment && (
                                <p style={{ fontSize: '11px', color: 'var(--accent-gold)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                  💬 {img.comment}
                                </p>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="card">
                    <div className="flex-between" style={{ marginBottom: '20px' }}>
                      <h3 style={{ fontSize: '20px', fontWeight: 300 }}>Galleries & Deliverables</h3>
                      {user.role === 'ADMIN' && (
                        <button onClick={() => setShowNewGalleryModal(true)} className="btn btn-gold-outline" style={{ padding: '6px 12px', fontSize: '12px' }}>
                          + Add Gallery
                        </button>
                      )}
                    </div>

                    {selectedProject.galleries.length === 0 ? (
                      <div style={{ textAlign: 'center', padding: '30px 20px', border: '1px dashed var(--border-color)', borderRadius: '8px' }}>
                        <p className="text-muted">No media galleries created yet for this project.</p>
                      </div>
                    ) : (
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
                        {selectedProject.galleries.map(gal => (
                          <div key={gal.galleryId} className="flex-between" style={{ padding: '16px 20px', border: '1px solid var(--border-color)', borderRadius: '8px', backgroundColor: 'var(--bg-secondary)' }}>
                            <div>
                              <h4 style={{ fontWeight: 400 }}>{gal.name}</h4>
                              <p className="text-muted" style={{ fontSize: '12px', marginTop: '2px' }}>
                                Contains: <strong>{gal.images.length} photos</strong> | Created: {new Date(gal.createdAt).toLocaleDateString()}
                              </p>
                            </div>
                            <button onClick={() => openGallery(gal)} className="btn btn-primary" style={{ padding: '8px 16px', fontSize: '12px' }}>
                              Enter Gallery
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* SHOOT BOOKINGS CALENDAR EVENTS */}
                <div className="card">
                  <div className="flex-between" style={{ marginBottom: '20px' }}>
                    <h3 style={{ fontSize: '20px', fontWeight: 300 }}>Scheduled Shoot Bookings</h3>
                    {user.role === 'ADMIN' && (
                      <button onClick={() => setShowNewBookingModal(true)} className="btn btn-gold-outline" style={{ padding: '6px 12px', fontSize: '12px' }}>
                        + Book Session
                      </button>
                    )}
                  </div>

                  {selectedProject.bookings.length === 0 ? (
                    <div style={{ textAlign: 'center', padding: '30px 20px', border: '1px dashed var(--border-color)', borderRadius: '8px' }}>
                      <p className="text-muted">No active bookings scheduled for this project.</p>
                    </div>
                  ) : (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
                      {selectedProject.bookings.map(book => (
                        <div key={book.bookingId} style={{ padding: '20px', border: '1px solid var(--border-color)', borderRadius: '8px', backgroundColor: 'var(--bg-secondary)' }}>
                          <div className="flex-between" style={{ marginBottom: '10px' }}>
                            <h4 className="text-gold" style={{ fontWeight: 400 }}>📍 {book.location}</h4>
                            <span className="badge badge-progress" style={{ fontSize: '10px' }}>CONFIRMED</span>
                          </div>
                          
                          <p style={{ fontSize: '13px', marginBottom: '8px' }}>
                            📅 <strong>{new Date(book.startTime).toLocaleDateString()}</strong> at 
                            {' '}{new Date(book.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} - 
                            {' '}{new Date(book.endTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </p>

                          <p style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>
                            📸 Assigned Crew: {book.photographers.join(', ')}
                          </p>

                          {book.notes && (
                            <p className="text-muted" style={{ fontSize: '12px', marginTop: '8px', borderTop: '1px solid #2d2d2a', paddingTop: '8px' }}>
                              Notes: {book.notes}
                            </p>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* RIGHT SIDE: BILLING & PAYMENT STATUS SUMMARY */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '30px' }}>
                <div className="card" style={{ border: '1px solid var(--accent-gold-border)' }}>
                  <div className="flex-between" style={{ marginBottom: '15px', alignItems: 'center' }}>
                    <h3 style={{ fontSize: '18px', color: 'var(--accent-gold)', margin: 0 }}>Financial Summary</h3>
                    {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') && (
                      <button
                        onClick={() => {
                          setNewInvoiceProjectId(selectedProject.metadata.projectId);
                          setShowNewInvoiceModal(true);
                        }}
                        className="btn btn-gold-outline"
                        style={{ padding: '4px 10px', fontSize: '11px' }}
                      >
                        + Add Invoice
                      </button>
                    )}
                  </div>
                  
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                    <div className="flex-between" style={{ borderBottom: '1px solid var(--border-color)', paddingBottom: '8px' }}>
                      <span className="text-muted" style={{ fontSize: '13px' }}>Contract Value:</span>
                      <strong style={{ fontSize: '16px' }}>
                        {user.role === 'SUPER_ADMIN' ? `₹${selectedProject.metadata.totalAmount.toLocaleString()}` : '***'}
                      </strong>
                    </div>

                    {selectedProject.invoices.map(inv => (
                      <div key={inv.invoiceId} style={{ padding: '12px', border: '1px solid var(--border-color)', borderRadius: '6px', backgroundColor: 'rgba(0,0,0,0.1)' }}>
                        <div className="flex-between" style={{ marginBottom: '6px' }}>
                          <span style={{ fontSize: '12px', fontWeight: 600 }}>INV-{inv.invoiceId.slice(0, 5).toUpperCase()}</span>
                          <span className={`badge ${inv.status === 'PAID' ? 'badge-completed' : 'badge-progress'}`} style={{ fontSize: '9px' }}>
                            {inv.status}
                          </span>
                        </div>
                        <p style={{ fontSize: '14px', fontWeight: 600 }}>₹{inv.amount.toLocaleString()}</p>
                        <p className="text-muted" style={{ fontSize: '11px', marginTop: '2px' }}>Due: {new Date(inv.dueDate).toLocaleDateString()}</p>
                        
                        {inv.status === 'PENDING' && (
                          <button
                            onClick={() => handleMockPay(selectedProject.metadata.projectId, inv.invoiceId)}
                            className="btn btn-primary"
                            style={{ width: '100%', fontSize: '11px', padding: '6px', marginTop: '10px' }}
                          >
                            💳 Process Mock Payment
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="card">
                  <h3 style={{ fontSize: '16px', marginBottom: '10px' }}>Project Notes</h3>
                  <p className="text-muted" style={{ fontSize: '13px', whiteSpace: 'pre-wrap' }}>
                    {selectedProject.metadata.notes || 'No project description notes provided.'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        ) : (
          
          /* --- TAB REGULAR SCREENS: DASHBOARD, PROJECTS, INVOICES LISTS --- */
          <div>
            
            {/* 1. DASHBOARD VIEW (ADMINS ONLY) */}
            {currentTab === 'dashboard' && (user.role === 'SUPER_ADMIN' || user.role === 'ADMIN' || user.role === 'READ_ONLY') && (
              <div>
                <div style={{ marginBottom: '30px' }}>
                  <h1 style={{ fontSize: '38px', fontWeight: 300, fontFamily: 'var(--font-display)', color: 'var(--text-primary)' }}>The Story Box Studio Dashboard</h1>
                  <p className="text-muted">Welcome back. Here is an overview of your active photography business metrics.</p>
                </div>

                {/* Dashboard Stats Row */}
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '20px', marginBottom: '40px' }}>
                  <div className="card" style={{ textAlign: 'center' }}>
                    <p className="form-label" style={{ fontSize: '11px' }}>Total Shoots</p>
                    <h2 style={{ fontSize: '36px', color: 'var(--accent-gold)', marginTop: '5px' }}>{stats.totalProjects}</h2>
                  </div>
                  <div className="card" style={{ textAlign: 'center' }}>
                    <p className="form-label" style={{ fontSize: '11px' }}>Upcoming Bookings</p>
                    <h2 style={{ fontSize: '36px', color: 'var(--warning)', marginTop: '5px' }}>{stats.upcomingShoots}</h2>
                  </div>
                  <div className="card" style={{ textAlign: 'center' }}>
                    <p className="form-label" style={{ fontSize: '11px' }}>Active Clients</p>
                    <h2 style={{ fontSize: '36px', color: 'var(--text-primary)', marginTop: '5px' }}>{stats.activeClients}</h2>
                  </div>
                  {user.role === 'SUPER_ADMIN' && (
                    <div className="card" style={{ textAlign: 'center' }}>
                      <p className="form-label" style={{ fontSize: '11px' }}>Revenue Generated</p>
                      <h2 style={{ fontSize: '32px', color: 'var(--success)', marginTop: '8px' }}>₹{stats.totalRevenue.toLocaleString()}</h2>
                    </div>
                  )}
                </div>

                {/* Quick Add Project Box */}
                {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') && (
                  <div className="card" style={{ marginBottom: '30px', border: '1px solid var(--accent-gold-border)' }}>
                    <div className="flex-between">
                      <div>
                        <h3 className="text-gold" style={{ fontSize: '20px' }}>Ready to schedule a new photography project?</h3>
                        <p className="text-muted" style={{ fontSize: '13px', marginTop: '2px' }}>Instantly register clients, set shoot packages, and construct custom photo proof deliverables.</p>
                      </div>
                      <button onClick={() => setShowNewProjectModal(true)} className="btn btn-primary">
                        + Create Project
                      </button>
                    </div>
                  </div>
                )}

                {/* Recent Shoots Table Grid */}
                <div className="card">
                  <h3 style={{ fontSize: '20px', marginBottom: '20px', fontWeight: 300 }}>Recent Shoots Summary</h3>
                  {projects.length === 0 ? (
                    <p className="text-muted">No photography projects scheduled yet.</p>
                  ) : (
                    <div style={{ overflowX: 'auto' }}>
                      <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
                        <thead>
                          <tr style={{ borderBottom: '1px solid var(--border-color)', color: 'var(--text-muted)', fontSize: '12px', textTransform: 'uppercase' }}>
                            <th style={{ padding: '12px' }}>Project Name</th>
                            <th style={{ padding: '12px' }}>Type</th>
                            <th style={{ padding: '12px' }}>Shoot Date</th>
                            <th style={{ padding: '12px' }}>Total Package</th>
                            <th style={{ padding: '12px' }}>Status</th>
                            <th style={{ padding: '12px' }}>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          {projects.slice(0, 5).map(p => (
                            <tr key={p.projectId} style={{ borderBottom: '1px solid var(--border-color)', fontSize: '14px' }}>
                              <td style={{ padding: '16px 12px', fontWeight: 500 }}>{p.title}</td>
                              <td style={{ padding: '16px 12px' }}>{p.type}</td>
                              <td style={{ padding: '16px 12px' }}>{new Date(p.date).toLocaleDateString()}</td>
                              <td style={{ padding: '16px 12px', fontWeight: 600 }}>
                                {user.role === 'SUPER_ADMIN' ? `₹${p.totalAmount.toLocaleString()}` : '***'}
                              </td>
                              <td style={{ padding: '16px 12px' }}>
                                <span className={`badge badge-${p.status.toLowerCase()}`}>{p.status}</span>
                              </td>
                              <td style={{ padding: '16px 12px' }}>
                                <button onClick={() => viewProjectDetails(p.projectId)} className="btn btn-gold-outline" style={{ padding: '4px 10px', fontSize: '11px' }}>
                                  View Details
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* 2. PROJECTS LIST VIEW */}
            {currentTab === 'projects' && (
              <div>
                <div className="flex-between" style={{ marginBottom: '30px' }}>
                  <div>
                    <h1 style={{ fontSize: '36px', fontWeight: 200 }}>
                      {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN' || user.role === 'READ_ONLY') 
                        ? 'Photography Assignments' 
                        : (user.role === 'HOA_STAFF' ? 'Dashboard' : 'My Project Galleries')}
                    </h1>
                    <p className="text-muted">
                      {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN' || user.role === 'READ_ONLY') 
                        ? 'Manage, coordinate, and review proofing galleries for clients.' 
                        : (user.role === 'HOA_STAFF' ? 'Welcome to your dashboard.' : 'Access your photo shoots, view proofs, and select final delivery edits.')}
                    </p>
                  </div>
                  {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') && (
                    <button onClick={() => setShowNewProjectModal(true)} className="btn btn-primary">
                      + Create Project
                    </button>
                  )}
                </div>

                {projects.length === 0 ? (
                  <div style={{ textAlign: 'center', padding: '60px 20px', border: '1px dashed var(--border-color)', borderRadius: '8px' }}>
                    <p className="text-muted">No photography projects scheduled.</p>
                  </div>
                ) : (
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '24px' }}>
                    {projects.map(p => (
                      <div key={p.projectId} className="card" onClick={() => viewProjectDetails(p.projectId)} style={{ cursor: 'pointer' }}>
                        <div className="flex-between" style={{ marginBottom: '10px' }}>
                          <span className="text-muted" style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '1px' }}>{p.type}</span>
                          <span className={`badge badge-${p.status.toLowerCase()}`}>{p.status}</span>
                        </div>
                        <h3 className="text-gold" style={{ fontSize: '20px', fontWeight: 400, marginBottom: '8px' }}>{p.title}</h3>
                        {user.role === 'CLIENT' && user.permissions?.canViewDetails === false && (
                          <span className="badge badge-progress" style={{ fontSize: '9px', marginBottom: '8px' }}>⚠️ ACCESS LOCKED</span>
                        )}
                        <p style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>📅 Shoot Date: {new Date(p.date).toLocaleDateString()}</p>
                        <p style={{ fontSize: '13px', fontWeight: 600, marginTop: '8px' }}>Package: {user.role === 'SUPER_ADMIN' ? `₹${p.totalAmount.toLocaleString()}` : '***'}</p>
                        
                        <div style={{ marginTop: '20px', borderTop: '1px solid var(--border-color)', paddingTop: '12px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') ? (
                            <button
                              onClick={async (e) => {
                                e.stopPropagation();
                                if (confirm(`Are you sure you want to delete the project "${p.title}" and all its deliverables?`)) {
                                  await apiService.deleteProject(p.projectId);
                                  loadData();
                                  alert("Project deleted.");
                                }
                              }}
                              className="btn btn-danger"
                              style={{ padding: '4px 8px', fontSize: '11px', display: 'flex', alignItems: 'center', gap: '4px' }}
                            >
                              🗑️ Delete
                            </button>
                          ) : <div />}
                          <span className="text-gold" style={{ fontSize: '12px' }}>View Details & Deliverables →</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* 3. INVOICES & BILLING VIEW */}
            {currentTab === 'invoices' && (
              <div>
                <div className="flex-between" style={{ marginBottom: '30px', alignItems: 'center', flexWrap: 'wrap', gap: '15px' }}>
                  <div>
                    <h1 style={{ fontSize: '36px', fontWeight: 200 }}>Invoices & Billing Summary</h1>
                    <p className="text-muted" style={{ margin: 0 }}>Review, verify, and complete active payments for photography services.</p>
                  </div>
                  {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') && (
                    <button
                      onClick={() => {
                        if (projects.length > 0) {
                          setNewInvoiceProjectId(projects[0].projectId);
                        }
                        setShowNewInvoiceModal(true);
                      }}
                      className="btn btn-primary"
                      style={{ padding: '10px 20px', fontSize: '13px' }}
                    >
                      + Add Invoice
                    </button>
                  )}
                </div>

                {invoices.length === 0 ? (
                  <div style={{ textAlign: 'center', padding: '60px 20px', border: '1px dashed var(--border-color)', borderRadius: '8px' }}>
                    <p className="text-muted">No active invoices found.</p>
                  </div>
                ) : (
                  <div className="card">
                    <div style={{ overflowX: 'auto' }}>
                      <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
                        <thead>
                          <tr style={{ borderBottom: '1px solid var(--border-color)', color: 'var(--text-muted)', fontSize: '12px', textTransform: 'uppercase' }}>
                            <th style={{ padding: '12px' }}>Invoice ID</th>
                            <th style={{ padding: '12px' }}>Project Title</th>
                            <th style={{ padding: '12px' }}>Description</th>
                            <th style={{ padding: '12px' }}>Due Date</th>
                            <th style={{ padding: '12px' }}>Amount</th>
                            <th style={{ padding: '12px' }}>Status</th>
                            <th style={{ padding: '12px' }}>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          {invoices.map(inv => (
                            <tr key={inv.invoiceId} style={{ borderBottom: '1px solid var(--border-color)', fontSize: '14px' }}>
                              <td style={{ padding: '16px 12px', fontWeight: 500 }}>INV-{inv.invoiceId.slice(0, 5).toUpperCase()}</td>
                              <td style={{ padding: '16px 12px' }}>{inv.projectTitle}</td>
                              <td style={{ padding: '16px 12px', color: 'var(--text-secondary)' }}>{inv.description}</td>
                              <td style={{ padding: '16px 12px' }}>{new Date(inv.dueDate).toLocaleDateString()}</td>
                              <td style={{ padding: '16px 12px', fontWeight: 600 }}>₹{inv.amount.toLocaleString()}</td>
                              <td style={{ padding: '16px 12px' }}>
                                <span className={`badge ${inv.status === 'PAID' ? 'badge-completed' : 'badge-progress'}`}>{inv.status}</span>
                              </td>
                              <td style={{ padding: '16px 12px' }}>
                                {inv.status === 'PENDING' ? (
                                  <button onClick={() => handleMockPay(inv.projectId, inv.invoiceId)} className="btn btn-primary" style={{ padding: '6px 12px', fontSize: '11px' }}>
                                    💳 Pay Now
                                  </button>
                                ) : (
                                  <span className="text-muted" style={{ fontSize: '12px' }}>Completed</span>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* 4. TEAM CREW VIEW */}
            {currentTab === 'team' && (
              <div>
                <div className="flex-between" style={{ marginBottom: '30px', alignItems: 'center' }}>
                  <div>
                    <h1 style={{ fontSize: '36px', fontWeight: 200 }}>Studio Creative Crew</h1>
                    <p className="text-muted" style={{ margin: 0 }}>Coordinate administrative staff, principal photographers, editors, and crew members.</p>
                  </div>
                  {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') && (
                    <button
                      onClick={() => {
                        setNewUserType('TEAM');
                        setNewUserRole('ADMIN');
                        setShowCreateUserModal(true);
                      }}
                      className="btn btn-primary"
                      style={{ padding: '10px 20px', fontSize: '13px' }}
                    >
                      + Add Crew Member
                    </button>
                  )}
                </div>

                <div className="card">
                  <div style={{ overflowX: 'auto' }}>
                    <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
                      <thead>
                        <tr style={{ borderBottom: '1px solid var(--border-color)', color: 'var(--text-muted)', fontSize: '12px', textTransform: 'uppercase' }}>
                          <th style={{ padding: '12px' }}>Member ID</th>
                          <th style={{ padding: '12px' }}>Name</th>
                          <th style={{ padding: '12px' }}>Email Address</th>
                          <th style={{ padding: '12px' }}>Contact Phone</th>
                          <th style={{ padding: '12px' }}>Account Status</th>
                          <th style={{ padding: '12px' }}>Role Type</th>
                          {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') && (
                            <th style={{ padding: '12px' }}>Actions</th>
                          )}
                        </tr>
                      </thead>
                      <tbody>
                        {team.map(member => (
                          <tr key={member.userId} style={{ borderBottom: '1px solid var(--border-color)', fontSize: '14px' }}>
                            <td style={{ padding: '16px 12px', fontWeight: 500 }}>{member.userId.toUpperCase().slice(0, 8)}</td>
                            <td style={{ padding: '16px 12px', fontWeight: 600 }}>{member.name}</td>
                            <td style={{ padding: '16px 12px', color: 'var(--text-secondary)' }}>{member.email}</td>
                            <td style={{ padding: '16px 12px' }}>{member.phone}</td>
                            <td style={{ padding: '16px 12px' }}>
                              <span className="badge badge-completed" style={{ fontSize: '9px' }}>{member.status}</span>
                            </td>
                            <td style={{ padding: '16px 12px' }}>
                              <span className="badge badge-proofing" style={{ fontSize: '9px' }}>{member.role}</span>
                            </td>
                            {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') && (
                              <td style={{ padding: '16px 12px' }}>
                                <div style={{ display: 'flex', gap: '8px' }}>
                                  <button
                                    onClick={() => {
                                      setPermissionUser(member);
                                      setEditName(member.name);
                                      setEditEmail(member.email);
                                      setEditPhone(member.phone);
                                      setEditRole(member.role);
                                      setEditStatus(member.status);
                                      setEditCanProof(member.permissions?.canProof !== false);
                                      setEditCanPay(member.permissions?.canPay !== false);
                                      setEditCanViewDetails(member.permissions?.canViewDetails !== false);
                                      setShowPermissionsModal(true);
                                    }}
                                    className="btn btn-gold-outline"
                                    style={{ padding: '4px 10px', fontSize: '11px', whiteSpace: 'nowrap' }}
                                  >
                                    ✏️ Edit Crew
                                  </button>
                                  {user.role === 'SUPER_ADMIN' && (
                                    <button
                                      onClick={async () => {
                                        if (window.confirm(`Are you sure you want to completely delete the crew member account for ${member.name}?`)) {
                                          try {
                                            await apiService.deleteUser(member.userId);
                                            loadData();
                                          } catch (e) {
                                            console.error(e);
                                            alert("Failed to delete user.");
                                          }
                                        }
                                      }}
                                      className="btn btn-gold-outline"
                                      style={{ padding: '4px 10px', fontSize: '11px', whiteSpace: 'nowrap', borderColor: '#d32f2f', color: '#d32f2f' }}
                                    >
                                      🗑️ Delete
                                    </button>
                                  )}
                                </div>
                              </td>
                            )}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* 4.5. TEAM INSIGHTS & EMPLOYEE PROFILES VIEW */}
            {currentTab === 'insights' && (
              <div>
                <div className="flex-between" style={{ marginBottom: '30px', alignItems: 'center' }}>
                  <div>
                    <h1 style={{ fontSize: '36px', fontWeight: 200 }}>Team Insights & Profiles</h1>
                    <p className="text-muted" style={{ margin: 0 }}>Review financial CTC payouts, government IDs, employment histories, travel logs, and emergency contacts.</p>
                  </div>
                  {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') && (
                    <button
                      onClick={() => {
                        resetEmployeeForm();
                        setShowEmployeeFormModal(true);
                      }}
                      className="btn btn-primary"
                      style={{ padding: '10px 20px', fontSize: '13px' }}
                    >
                      + Add Employee Profile
                    </button>
                  )}
                </div>

                {/* Aggregated Insights Row */}
                <div className="stats-row" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '20px', marginBottom: '30px' }}>
                  <div className="card flex-center" style={{ flexDirection: 'column', padding: '20px', textAlign: 'center' }}>
                    <p className="form-label" style={{ fontSize: '10px', color: 'var(--text-muted)' }}>Crew Headcount</p>
                    <h2 style={{ fontSize: '32px', margin: '5px 0', color: 'var(--accent-gold)' }}>
                      {employees.filter(e => e.status === 'ACTIVE').length} Active
                    </h2>
                    <span style={{ fontSize: '11px', color: 'var(--text-secondary)' }}>
                      Out of {employees.length} Total Profiles
                    </span>
                  </div>

                  <div className="card flex-center" style={{ flexDirection: 'column', padding: '20px', textAlign: 'center' }}>
                    <p className="form-label" style={{ fontSize: '10px', color: 'var(--text-muted)' }}>Monthly Salary Outflow</p>
                    <h2 style={{ fontSize: '32px', margin: '5px 0', color: 'var(--accent-gold)' }}>
                      ₹{employees.reduce((acc, curr) => acc + (curr.status === 'ACTIVE' ? Number(curr.monthlySalary || 0) : 0), 0).toLocaleString()}
                    </h2>
                    <span style={{ fontSize: '11px', color: 'var(--text-secondary)' }}>
                      Sum of Active Basic Salaries
                    </span>
                  </div>

                  <div className="card flex-center" style={{ flexDirection: 'column', padding: '20px', textAlign: 'center' }}>
                    <p className="form-label" style={{ fontSize: '10px', color: 'var(--text-muted)' }}>Average Annual CTC</p>
                    <h2 style={{ fontSize: '32px', margin: '5px 0', color: 'var(--accent-gold)' }}>
                      ₹{Math.round(employees.length ? employees.reduce((acc, curr) => acc + Number(curr.ctc || 0), 0) / employees.length : 0).toLocaleString()}
                    </h2>
                    <span style={{ fontSize: '11px', color: 'var(--text-secondary)' }}>
                      Across All Team Profiles
                    </span>
                  </div>

                  <div className="card flex-center" style={{ flexDirection: 'column', padding: '20px', textAlign: 'center' }}>
                    <p className="form-label" style={{ fontSize: '10px', color: 'var(--text-muted)' }}>Onsite Travels</p>
                    <h2 style={{ fontSize: '32px', margin: '5px 0', color: 'var(--accent-gold)' }}>
                      {employees.reduce((acc, curr) => acc + (curr.travelHistory?.filter((t: OnsiteTravel) => t.status === 'APPROVED' || t.status === 'PENDING').length || 0), 0)} Scheduled
                    </h2>
                    <span style={{ fontSize: '11px', color: 'var(--text-secondary)' }}>
                      Active Onsite Assignments
                    </span>
                  </div>
                </div>

                {/* Main Directory Layout */}
                <div style={{ display: 'grid', gridTemplateColumns: selectedEmployee ? '1.2fr 1fr' : '1fr', gap: '30px', transition: 'var(--transition-smooth)' }}>
                  
                  {/* LEFT COLUMN: EMPLOYEE LIST GRID */}
                  <div className="card">
                    <h3 style={{ fontSize: '20px', marginBottom: '20px' }}>Employee Directory</h3>
                    {employees.length === 0 ? (
                      <div style={{ textAlign: 'center', padding: '40px 20px', border: '1px dashed var(--border-color)', borderRadius: '8px' }}>
                        <p className="text-muted">No employee profiles recorded yet.</p>
                      </div>
                    ) : (
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
                        {employees.map(emp => (
                          <div 
                            key={emp.employeeId} 
                            onClick={() => {
                              setSelectedEmployee(emp);
                              setActiveProfileTab('overview');
                            }}
                            className={`flex-between`} 
                            style={{ 
                              padding: '16px 20px', 
                              border: '1px solid var(--border-color)', 
                              borderRadius: '8px', 
                              backgroundColor: selectedEmployee?.employeeId === emp.employeeId ? 'var(--bg-tertiary)' : 'var(--bg-secondary)',
                              cursor: 'pointer',
                              transition: 'var(--transition-fast)'
                            }}
                          >
                            <div>
                              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                                <h4 style={{ fontWeight: 600, margin: 0 }}>{emp.name}</h4>
                                <span className={`badge ${emp.status === 'ACTIVE' ? 'badge-completed' : 'badge-planning'}`} style={{ fontSize: '8px', padding: '2px 6px' }}>
                                  {emp.status}
                                </span>
                              </div>
                              <p className="text-muted" style={{ fontSize: '12px', marginTop: '4px' }}>
                                <strong>{emp.designation}</strong> ({emp.department}) | Join Date: {emp.dateOfJoining || 'N/A'}
                              </p>
                            </div>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                              <span style={{ fontSize: '13px', fontWeight: 600, color: 'var(--accent-gold)' }}>
                                ₹{(emp.monthlySalary || 0).toLocaleString()}/mo
                              </span>
                              <span style={{ fontSize: '16px', color: 'var(--text-muted)' }}>›</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* RIGHT COLUMN: EMPLOYEE PROFILE DETAILS DRAWER */}
                  {selectedEmployee && (
                    <div className="card" style={{ border: '1px solid var(--accent-gold-border)' }}>
                      <div className="flex-between" style={{ marginBottom: '20px' }}>
                        <div>
                          <h3 className="text-gold" style={{ fontSize: '24px', margin: 0 }}>{selectedEmployee.name}</h3>
                          <p className="text-muted" style={{ fontSize: '12px', marginTop: '2px' }}>{selectedEmployee.designation} &mdash; {selectedEmployee.department}</p>
                        </div>
                        <button 
                          onClick={() => setSelectedEmployee(null)}
                          className="btn btn-secondary"
                          style={{ padding: '6px 12px', fontSize: '11px' }}
                        >
                          ✕ Close Drawer
                        </button>
                      </div>

                      {/* Detail Tab Buttons */}
                      <div style={{ display: 'flex', borderBottom: '1px solid var(--border-color)', marginBottom: '20px', overflowX: 'auto', gap: '10px', paddingBottom: '8px' }}>
                        {(['overview', 'identity', 'financials', 'history', 'travel'] as const).map(tab => (
                          <button
                            key={tab}
                            onClick={() => setActiveProfileTab(tab)}
                            style={{
                              background: 'none',
                              border: 'none',
                              borderBottom: activeProfileTab === tab ? '2px solid var(--accent-gold)' : 'none',
                              color: activeProfileTab === tab ? 'var(--text-primary)' : 'var(--text-muted)',
                              fontWeight: activeProfileTab === tab ? 600 : 400,
                              fontSize: '12px',
                              textTransform: 'uppercase',
                              letterSpacing: '1px',
                              cursor: 'pointer',
                              padding: '4px 8px',
                              whiteSpace: 'nowrap'
                            }}
                          >
                            {tab}
                          </button>
                        ))}
                      </div>

                      {/* Tab 1: OVERVIEW & GENERAL */}
                      {activeProfileTab === 'overview' && (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', fontSize: '13px' }}>
                          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px' }}>
                            <div>
                              <p className="form-label" style={{ fontSize: '9px', color: 'var(--text-muted)' }}>Corporate Email</p>
                              <strong>{selectedEmployee.email}</strong>
                            </div>
                            <div>
                              <p className="form-label" style={{ fontSize: '9px', color: 'var(--text-muted)' }}>Personal Email</p>
                              <strong>{selectedEmployee.personalEmail || 'N/A'}</strong>
                            </div>
                            <div>
                              <p className="form-label" style={{ fontSize: '9px', color: 'var(--text-muted)' }}>Contact Phone</p>
                              <strong>{selectedEmployee.phone || 'N/A'}</strong>
                            </div>
                            <div>
                              <p className="form-label" style={{ fontSize: '9px', color: 'var(--text-muted)' }}>Blood Group</p>
                              <strong>{selectedEmployee.bloodGroup || 'N/A'}</strong>
                            </div>
                            <div>
                              <p className="form-label" style={{ fontSize: '9px', color: 'var(--text-muted)' }}>Date of Joining</p>
                              <strong>{selectedEmployee.dateOfJoining || 'N/A'}</strong>
                            </div>
                            <div>
                              <p className="form-label" style={{ fontSize: '9px', color: 'var(--text-muted)' }}>Employee Status</p>
                              <strong style={{ color: selectedEmployee.status === 'ACTIVE' ? '#2563eb' : 'inherit' }}>
                                {selectedEmployee.status}
                              </strong>
                            </div>
                          </div>
                          <div>
                            <p className="form-label" style={{ fontSize: '9px', color: 'var(--text-muted)' }}>Residential Address</p>
                            <strong>{selectedEmployee.address || 'No residential address recorded.'}</strong>
                          </div>

                          <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '15px', marginTop: '10px' }}>
                            <h4 style={{ fontSize: '15px', color: 'var(--accent-gold)', marginBottom: '12px' }}>Emergency Contacts</h4>
                            {(!selectedEmployee.emergencyContacts || selectedEmployee.emergencyContacts.length === 0) ? (
                              <p className="text-muted">No emergency contacts logged.</p>
                            ) : (
                              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                {selectedEmployee.emergencyContacts.map((c: EmergencyContact, idx: number) => (
                                  <div key={idx} style={{ padding: '10px', border: '1px solid var(--border-color)', borderRadius: '6px', backgroundColor: 'var(--bg-secondary)' }}>
                                    <div className="flex-between">
                                      <strong>{c.name}</strong>
                                      <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}>{c.relationship}</span>
                                    </div>
                                    <p style={{ margin: '4px 0 0 0', color: 'var(--text-secondary)' }}>📞 {c.phone}</p>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {/* Tab 2: IDENTITY & GOVERNMENT CARDS */}
                      {activeProfileTab === 'identity' && (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', fontSize: '13px' }}>
                          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px' }}>
                            <div>
                              <p className="form-label" style={{ fontSize: '9px', color: 'var(--text-muted)' }}>PAN Card Number</p>
                              <strong>{selectedEmployee.panCard || 'N/A'}</strong>
                            </div>
                            <div>
                              <p className="form-label" style={{ fontSize: '9px', color: 'var(--text-muted)' }}>Aadhar Card Number</p>
                              <strong>{selectedEmployee.aadharCard || 'N/A'}</strong>
                            </div>
                          </div>

                          <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '15px', marginTop: '10px' }}>
                            <h4 style={{ fontSize: '15px', color: 'var(--accent-gold)', marginBottom: '12px' }}>Health Insurance Policy</h4>
                            {(!selectedEmployee.healthInsurance || !selectedEmployee.healthInsurance.policyNumber) ? (
                              <p className="text-muted">No health insurance details logged.</p>
                            ) : (
                              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                                <div>
                                  <p className="form-label" style={{ fontSize: '9px', color: 'var(--text-muted)' }}>Policy Number</p>
                                  <strong>{selectedEmployee.healthInsurance.policyNumber}</strong>
                                </div>
                                <div>
                                  <p className="form-label" style={{ fontSize: '9px', color: 'var(--text-muted)' }}>Insurance Provider</p>
                                  <strong>{selectedEmployee.healthInsurance.provider}</strong>
                                </div>
                                <div>
                                  <p className="form-label" style={{ fontSize: '9px', color: 'var(--text-muted)' }}>Sum Insured</p>
                                  <strong>₹{selectedEmployee.healthInsurance.sumInsured?.toLocaleString()}</strong>
                                </div>
                                <div>
                                  <p className="form-label" style={{ fontSize: '9px', color: 'var(--text-muted)' }}>TPA Administrator</p>
                                  <strong>{selectedEmployee.healthInsurance.tpaName || 'N/A'}</strong>
                                </div>
                                <div>
                                  <p className="form-label" style={{ fontSize: '9px', color: 'var(--text-muted)' }}>Policy Expiry Date</p>
                                  <strong>{selectedEmployee.healthInsurance.expiryDate || 'N/A'}</strong>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {/* Tab 3: FINANCIALS & BANK DETAILS */}
                      {activeProfileTab === 'financials' && (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', fontSize: '13px' }}>
                          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px' }}>
                            <div>
                              <p className="form-label" style={{ fontSize: '9px', color: 'var(--text-muted)' }}>Annual CTC Package</p>
                              <strong style={{ fontSize: '16px', color: 'var(--accent-gold)' }}>
                                ₹{selectedEmployee.ctc?.toLocaleString()}/yr
                              </strong>
                            </div>
                            <div>
                              <p className="form-label" style={{ fontSize: '9px', color: 'var(--text-muted)' }}>Monthly Take-home Basic</p>
                              <strong style={{ fontSize: '16px', color: 'var(--accent-gold)' }}>
                                ₹{selectedEmployee.monthlySalary?.toLocaleString()}/mo
                              </strong>
                            </div>
                          </div>

                          <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '15px', marginTop: '10px' }}>
                            <h4 style={{ fontSize: '15px', color: 'var(--accent-gold)', marginBottom: '12px' }}>Corporate Bank Account</h4>
                            {(!selectedEmployee.bankDetails || !selectedEmployee.bankDetails.accountNumber) ? (
                              <p className="text-muted">No bank details logged.</p>
                            ) : (
                              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                                <div>
                                  <p className="form-label" style={{ fontSize: '9px', color: 'var(--text-muted)' }}>Bank Name</p>
                                  <strong>{selectedEmployee.bankDetails.bankName}</strong>
                                </div>
                                <div>
                                  <p className="form-label" style={{ fontSize: '9px', color: 'var(--text-muted)' }}>Account Holder Name</p>
                                  <strong>{selectedEmployee.bankDetails.accountName}</strong>
                                </div>
                                <div>
                                  <p className="form-label" style={{ fontSize: '9px', color: 'var(--text-muted)' }}>Account Number</p>
                                  <strong>{selectedEmployee.bankDetails.accountNumber}</strong>
                                </div>
                                <div>
                                  <p className="form-label" style={{ fontSize: '9px', color: 'var(--text-muted)' }}>IFSC Validation Code</p>
                                  <strong>{selectedEmployee.bankDetails.ifscCode}</strong>
                                </div>
                                <div style={{ gridColumn: 'span 2' }}>
                                  <p className="form-label" style={{ fontSize: '9px', color: 'var(--text-muted)' }}>Branch Location</p>
                                  <strong>{selectedEmployee.bankDetails.branch}</strong>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {/* Tab 4: EMPLOYMENT HISTORY */}
                      {activeProfileTab === 'history' && (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '15px', fontSize: '13px' }}>
                          <h4 style={{ fontSize: '15px', color: 'var(--accent-gold)', margin: 0 }}>Previous Job History</h4>
                          {(!selectedEmployee.employmentHistory || selectedEmployee.employmentHistory.length === 0) ? (
                            <p className="text-muted">No previous employment logs recorded.</p>
                          ) : (
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                              {selectedEmployee.employmentHistory.map((h: EmploymentHistory, idx: number) => (
                                <div key={idx} style={{ padding: '14px', border: '1px solid var(--border-color)', borderRadius: '8px', backgroundColor: 'var(--bg-secondary)' }}>
                                  <div className="flex-between">
                                    <strong style={{ fontSize: '14px' }}>{h.company}</strong>
                                    <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}>
                                      {h.startDate} to {h.endDate || 'Present'}
                                    </span>
                                  </div>
                                  <p style={{ margin: '4px 0', fontWeight: 500, color: 'var(--accent-gold)' }}>{h.designation}</p>
                                  {h.reasonForLeaving && (
                                    <p className="text-muted" style={{ fontSize: '11px', margin: '8px 0 0 0', borderTop: '1px solid #e2ded5', paddingTop: '6px' }}>
                                      Reason: {h.reasonForLeaving}
                                    </p>
                                  )}
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      )}

                      {/* Tab 5: ONSITE TRAVEL LOGS */}
                      {activeProfileTab === 'travel' && (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '15px', fontSize: '13px' }}>
                          <h4 style={{ fontSize: '15px', color: 'var(--accent-gold)', margin: 0 }}>Onsite Travel Logs</h4>
                          {(!selectedEmployee.travelHistory || selectedEmployee.travelHistory.length === 0) ? (
                            <p className="text-muted">No onsite travel history records.</p>
                          ) : (
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                              {selectedEmployee.travelHistory.map((t: OnsiteTravel, idx: number) => (
                                <div key={idx} style={{ padding: '14px', border: '1px solid var(--border-color)', borderRadius: '8px', backgroundColor: 'var(--bg-secondary)' }}>
                                  <div className="flex-between">
                                    <strong style={{ fontSize: '14px' }}>✈️ {t.country}</strong>
                                    <span className={`badge ${t.status === 'COMPLETED' ? 'badge-completed' : t.status === 'APPROVED' ? 'badge-proofing' : 'badge-planning'}`} style={{ fontSize: '8px' }}>
                                      {t.status}
                                    </span>
                                  </div>
                                  <p style={{ margin: '4px 0', color: 'var(--text-secondary)' }}>Purpose: {t.purpose}</p>
                                  <p className="text-muted" style={{ fontSize: '11px', margin: '4px 0 0 0' }}>
                                    Duration: {t.startDate} &mdash; {t.endDate}
                                  </p>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      )}

                      {/* Drawer Actions Footer */}
                      {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') && (
                        <div style={{ display: 'flex', gap: '10px', borderTop: '1px solid var(--border-color)', paddingTop: '20px', marginTop: '30px' }}>
                          <button
                            onClick={() => handleEditEmployeeClick(selectedEmployee)}
                            className="btn btn-primary"
                            style={{ flex: 1, padding: '10px', fontSize: '12px' }}
                          >
                            ✏️ Edit Profile
                          </button>
                          {user.role === 'SUPER_ADMIN' && (
                            <button
                              onClick={() => handleDeleteEmployee(selectedEmployee.employeeId)}
                              className="btn btn-danger"
                              style={{ padding: '10px', fontSize: '12px' }}
                            >
                              🗑️ Delete
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  )}

                </div>
              </div>
            )}

            {/* 5. STUDIO CLIENTS VIEW */}
            {currentTab === 'clients' && (
              <div>
                <div className="flex-between" style={{ marginBottom: '30px', alignItems: 'center' }}>
                  <div>
                    <h1 style={{ fontSize: '36px', fontWeight: 200 }}>Studio Client Database</h1>
                    <p className="text-muted" style={{ margin: 0 }}>Review verified customer accounts, profile contact sheets, and contract statuses.</p>
                  </div>
                  {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') && (
                    <button
                      onClick={() => {
                        setNewUserType('CLIENT');
                        setNewUserRole('CLIENT');
                        setShowCreateUserModal(true);
                      }}
                      className="btn btn-primary"
                      style={{ padding: '10px 20px', fontSize: '13px' }}
                    >
                      + Add Client
                    </button>
                  )}
                </div>

                <div className="card">
                  <div style={{ overflowX: 'auto' }}>
                    <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
                      <thead>
                        <tr style={{ borderBottom: '1px solid var(--border-color)', color: 'var(--text-muted)', fontSize: '12px', textTransform: 'uppercase' }}>
                          <th style={{ padding: '12px' }}>Client ID</th>
                          <th style={{ padding: '12px' }}>Name</th>
                          <th style={{ padding: '12px' }}>Email Address</th>
                          <th style={{ padding: '12px' }}>Contact Phone</th>
                          <th style={{ padding: '12px' }}>Account Status</th>
                          <th style={{ padding: '12px' }}>Role Type</th>
                          {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') && (
                            <th style={{ padding: '12px' }}>Actions</th>
                          )}
                        </tr>
                      </thead>
                      <tbody>
                        {clients.map(c => (
                          <tr key={c.userId} style={{ borderBottom: '1px solid var(--border-color)', fontSize: '14px' }}>
                            <td style={{ padding: '16px 12px', fontWeight: 500 }}>{c.userId.toUpperCase()}</td>
                            <td style={{ padding: '16px 12px', fontWeight: 600 }}>{c.name}</td>
                            <td style={{ padding: '16px 12px', color: 'var(--text-secondary)' }}>{c.email}</td>
                            <td style={{ padding: '16px 12px' }}>{c.phone}</td>
                            <td style={{ padding: '16px 12px' }}>
                              <span className="badge badge-completed" style={{ fontSize: '9px' }}>{c.status}</span>
                            </td>
                            <td style={{ padding: '16px 12px' }}>
                              <span className="badge badge-proofing" style={{ fontSize: '9px' }}>{c.role}</span>
                            </td>
                            {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') && (
                              <td style={{ padding: '16px 12px' }}>
                                <div style={{ display: 'flex', gap: '8px' }}>
                                  <button
                                    onClick={() => {
                                      setPermissionUser(c);
                                      setEditName(c.name);
                                      setEditEmail(c.email);
                                      setEditPhone(c.phone);
                                      setEditRole(c.role);
                                      setEditStatus(c.status);
                                      setEditCanProof(c.permissions?.canProof !== false);
                                      setEditCanPay(c.permissions?.canPay !== false);
                                      setEditCanViewDetails(c.permissions?.canViewDetails !== false);
                                      setShowPermissionsModal(true);
                                    }}
                                    className="btn btn-gold-outline"
                                    style={{ padding: '4px 10px', fontSize: '11px', whiteSpace: 'nowrap' }}
                                  >
                                    ✏️ Edit Client
                                  </button>
                                  {user.role === 'SUPER_ADMIN' && (
                                    <button
                                      onClick={async () => {
                                        if (window.confirm(`Are you sure you want to completely delete the client account for ${c.name}?`)) {
                                          try {
                                            await apiService.deleteUser(c.userId);
                                            loadData();
                                          } catch (e) {
                                            console.error(e);
                                            alert("Failed to delete client.");
                                          }
                                        }
                                      }}
                                      className="btn btn-gold-outline"
                                      style={{ padding: '4px 10px', fontSize: '11px', whiteSpace: 'nowrap', borderColor: '#d32f2f', color: '#d32f2f' }}
                                    >
                                      🗑️ Delete
                                    </button>
                                  )}
                                </div>
                              </td>
                            )}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* 6. WEB ENQUIRIES VIEW */}
            {currentTab === 'enquiries' && (
              <div>
                <div className="flex-between" style={{ marginBottom: '30px', alignItems: 'center', flexWrap: 'wrap', gap: '15px' }}>
                  <div>
                    <h1 style={{ fontSize: '36px', fontWeight: 200 }}>Inbound Web Enquiries</h1>
                    <p className="text-muted" style={{ margin: 0 }}>Review raw photographer inquiries captured from contact forms on thestorybox.in.</p>
                  </div>
                  {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') && (
                    <button
                      onClick={() => {
                        const randomNames = ["Pooja Sharma", "Vikram Rathore", "Neha Kapoor", "Arjun Reddy"];
                        const randomName = randomNames[Math.floor(Math.random() * randomNames.length)];
                        
                        setNewLeadName(randomName);
                        setNewLeadEmail(randomName.toLowerCase().replace(' ', '.') + "@gmail.com");
                        setNewLeadPhone("+91 " + Math.floor(6000000000 + Math.random() * 3999999999).toString());
                        setNewLeadEventType("Wedding");
                        setNewLeadEventDate(new Date(Date.now() + 60 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]);
                        setNewLeadBudget(120000);
                        setNewLeadNotes("Inbound inquiry submitted via standard website contact form. Client is interested in a 2-day wedding package.");
                        setNewLeadStatus('ENQUIRY');
                        
                        setShowNewLeadModal(true);
                      }}
                      className="btn btn-primary"
                      style={{ padding: '10px 20px', fontSize: '13px' }}
                    >
                      + Simulate Web Enquiry
                    </button>
                  )}
                </div>

                {leads.filter(l => l.status === 'ENQUIRY').length === 0 ? (
                  <div style={{ textAlign: 'center', padding: '60px 20px', border: '1px dashed var(--border-color)', borderRadius: '8px' }}>
                    <p className="text-muted">No pending web enquiries.</p>
                  </div>
                ) : (
                  <div className="card">
                    <div style={{ overflowX: 'auto' }}>
                      <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
                        <thead>
                          <tr style={{ borderBottom: '1px solid var(--border-color)', color: 'var(--text-muted)', fontSize: '12px', textTransform: 'uppercase' }}>
                            <th style={{ padding: '12px' }}>Client Name</th>
                            <th style={{ padding: '12px' }}>Email Address</th>
                            <th style={{ padding: '12px' }}>Contact Phone</th>
                            <th style={{ padding: '12px' }}>Event Type</th>
                            <th style={{ padding: '12px' }}>Proposed Budget</th>
                            <th style={{ padding: '12px' }}>Source</th>
                            <th style={{ padding: '12px' }}>Brief Notes</th>
                            <th style={{ padding: '12px' }}>Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {leads.filter(l => l.status === 'ENQUIRY').map(lead => (
                            <tr key={lead.leadId} style={{ borderBottom: '1px solid var(--border-color)', fontSize: '14px' }}>
                              <td style={{ padding: '16px 12px', fontWeight: 600 }}>{lead.clientName}</td>
                              <td style={{ padding: '16px 12px', color: 'var(--text-secondary)' }}>{lead.clientEmail}</td>
                              <td style={{ padding: '16px 12px' }}>{lead.clientPhone}</td>
                              <td style={{ padding: '16px 12px', fontWeight: 500 }}>{lead.eventType}</td>
                              <td style={{ padding: '16px 12px', fontWeight: 600 }} className="text-gold">
                                {user.role === 'SUPER_ADMIN' ? `₹${lead.budget.toLocaleString()}` : '***'}
                              </td>
                              <td style={{ padding: '16px 12px' }}>
                                <span className="badge badge-completed" style={{ fontSize: '9px' }}>{lead.source}</span>
                              </td>
                              <td style={{ padding: '16px 12px', color: 'var(--text-secondary)', fontSize: '12px' }}>{lead.notes}</td>
                              <td style={{ padding: '16px 12px' }}>
                                <button
                                  onClick={async () => {
                                    await apiService.updateLeadStatus(lead.leadId, 'LEAD');
                                    loadData();
                                    alert("Qualified enquiry to active Lead.");
                                  }}
                                  className="btn btn-primary"
                                  style={{ padding: '6px 12px', fontSize: '11px', whiteSpace: 'nowrap' }}
                                >
                                  ✓ Qualify
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* 7. PHOTOGRAPHY LEADS VIEW */}
            {currentTab === 'leads' && (
              <div>
                <div className="flex-between" style={{ marginBottom: '30px', alignItems: 'center', flexWrap: 'wrap', gap: '15px' }}>
                  <div>
                    <h1 style={{ fontSize: '36px', fontWeight: 200 }}>Photography Sales Leads</h1>
                    <p className="text-muted" style={{ margin: 0 }}>Manage qualified sales opportunities, client call logs, and photoshoot budget metrics.</p>
                  </div>
                  {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') && (
                    <button
                      onClick={() => {
                        setNewLeadStatus('LEAD');
                        setNewLeadEventType('Wedding');
                        setNewLeadEventDate('');
                        setNewLeadBudget(50000);
                        setShowNewLeadModal(true);
                      }}
                      className="btn btn-primary"
                      style={{ padding: '10px 20px', fontSize: '13px' }}
                    >
                      + Add Lead
                    </button>
                  )}
                </div>

                {leads.filter(l => l.status === 'LEAD').length === 0 ? (
                  <div style={{ textAlign: 'center', padding: '60px 20px', border: '1px dashed var(--border-color)', borderRadius: '8px' }}>
                    <p className="text-muted">No qualified photography leads at present.</p>
                  </div>
                ) : (
                  <div className="card">
                    <div style={{ overflowX: 'auto' }}>
                      <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
                        <thead>
                          <tr style={{ borderBottom: '1px solid var(--border-color)', color: 'var(--text-muted)', fontSize: '12px', textTransform: 'uppercase' }}>
                            <th style={{ padding: '12px' }}>Client Name</th>
                            <th style={{ padding: '12px' }}>Email Address</th>
                            <th style={{ padding: '12px' }}>Contact Phone</th>
                            <th style={{ padding: '12px' }}>Event Type</th>
                            <th style={{ padding: '12px' }}>Target Date</th>
                            <th style={{ padding: '12px' }}>Budget</th>
                            <th style={{ padding: '12px' }}>Description Notes</th>
                            <th style={{ padding: '12px' }}>Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {leads.filter(l => l.status === 'LEAD').map(lead => (
                            <tr key={lead.leadId} style={{ borderBottom: '1px solid var(--border-color)', fontSize: '14px' }}>
                              <td style={{ padding: '16px 12px', fontWeight: 600 }}>{lead.clientName}</td>
                              <td style={{ padding: '16px 12px', color: 'var(--text-secondary)' }}>{lead.clientEmail}</td>
                              <td style={{ padding: '16px 12px' }}>{lead.clientPhone}</td>
                              <td style={{ padding: '16px 12px', fontWeight: 500 }}>{lead.eventType}</td>
                              <td style={{ padding: '16px 12px' }}>{new Date(lead.eventDate).toLocaleDateString()}</td>
                              <td style={{ padding: '16px 12px', fontWeight: 600 }} className="text-gold">
                                {user.role === 'SUPER_ADMIN' ? `₹${lead.budget.toLocaleString()}` : '***'}
                              </td>
                              <td style={{ padding: '16px 12px', color: 'var(--text-secondary)', fontSize: '12px' }}>{lead.notes}</td>
                              <td style={{ padding: '16px 12px' }}>
                                <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                                  <button
                                    onClick={async () => {
                                      await apiService.updateLeadStatus(lead.leadId, 'CONVERTED');
                                      loadData();
                                      alert(`Lead converted successfully. Generated client account for ${lead.clientName} and scheduled shoot!`);
                                    }}
                                    className="btn btn-primary"
                                    style={{ padding: '6px 12px', fontSize: '11px', whiteSpace: 'nowrap' }}
                                  >
                                    ⭐ Convert
                                  </button>
                                  {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') && (
                                    <button
                                      onClick={() => {
                                        setSelectedLead(lead);
                                        setEditLeadClientName(lead.clientName);
                                        setEditLeadClientEmail(lead.clientEmail);
                                        setEditLeadClientPhone(lead.clientPhone);
                                        setEditLeadEventType(lead.eventType);
                                        setEditLeadEventDate(lead.eventDate);
                                        setEditLeadBudget(lead.budget);
                                        setEditLeadNotes(lead.notes || '');
                                        setEditLeadStatus(lead.status);
                                        setShowEditLeadModal(true);
                                      }}
                                      className="btn btn-gold-outline"
                                      style={{ padding: '6px 10px', fontSize: '11px', whiteSpace: 'nowrap' }}
                                      title="Edit Lead"
                                    >
                                      ✏️ Edit
                                    </button>
                                  )}
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* 8. CONVERSIONS PIPE VIEW */}
            {currentTab === 'conversions' && (
              <div>
                <div style={{ marginBottom: '30px' }}>
                  <h1 style={{ fontSize: '36px', fontWeight: 200 }}>Sales Conversions Pipeline</h1>
                  <p className="text-muted">Track completed pipeline entries, won photoshoots, and revenue generation rates.</p>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '30px', alignItems: 'start' }}>
                  <div className="card">
                    <h3 style={{ fontSize: '20px', fontWeight: 300, marginBottom: '20px' }}>Successfully Converted Shoots</h3>
                    {leads.filter(l => l.status === 'CONVERTED').length === 0 ? (
                      <p className="text-muted">No converted projects recorded in pipeline.</p>
                    ) : (
                      <div style={{ overflowX: 'auto' }}>
                        <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
                          <thead>
                            <tr style={{ borderBottom: '1px solid var(--border-color)', color: 'var(--text-muted)', fontSize: '12px', textTransform: 'uppercase' }}>
                              <th style={{ padding: '12px' }}>Client Name</th>
                              <th style={{ padding: '12px' }}>Email Address</th>
                              <th style={{ padding: '12px' }}>Contact Phone</th>
                              <th style={{ padding: '12px' }}>Event Type</th>
                              <th style={{ padding: '12px' }}>Shoot Date</th>
                              <th style={{ padding: '12px' }}>Package Value</th>
                              {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') && (
                                <th style={{ padding: '12px' }}>Actions</th>
                              )}
                            </tr>
                          </thead>
                          <tbody>
                            {leads.filter(l => l.status === 'CONVERTED').map(lead => (
                              <tr key={lead.leadId} style={{ borderBottom: '1px solid var(--border-color)', fontSize: '14px' }}>
                                <td style={{ padding: '16px 12px', fontWeight: 600 }}>{lead.clientName}</td>
                                <td style={{ padding: '16px 12px', color: 'var(--text-secondary)' }}>{lead.clientEmail}</td>
                                <td style={{ padding: '16px 12px' }}>{lead.clientPhone}</td>
                                <td style={{ padding: '16px 12px', fontWeight: 500 }}>{lead.eventType}</td>
                                <td style={{ padding: '16px 12px' }}>{new Date(lead.eventDate).toLocaleDateString()}</td>
                                <td style={{ padding: '16px 12px', fontWeight: 600 }} className="text-gold">
                                  {user.role === 'SUPER_ADMIN' ? `₹${lead.budget.toLocaleString()}` : '***'}
                                </td>
                                {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') && (
                                  <td style={{ padding: '16px 12px' }}>
                                    <button
                                      onClick={() => {
                                        setSelectedLead(lead);
                                        setEditLeadClientName(lead.clientName);
                                        setEditLeadClientEmail(lead.clientEmail);
                                        setEditLeadClientPhone(lead.clientPhone);
                                        setEditLeadEventType(lead.eventType);
                                        setEditLeadEventDate(lead.eventDate);
                                        setEditLeadBudget(lead.budget);
                                        setEditLeadNotes(lead.notes || '');
                                        setEditLeadStatus(lead.status);
                                        setShowEditLeadModal(true);
                                      }}
                                      className="btn btn-gold-outline"
                                      style={{ padding: '4px 10px', fontSize: '11px', whiteSpace: 'nowrap' }}
                                      title="Edit Conversion Record"
                                    >
                                      ✏️ Edit
                                    </button>
                                  </td>
                                )}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>

                  <div className="card" style={{ border: '1px solid var(--accent-gold-border)' }}>
                    <h3 className="text-gold" style={{ fontSize: '18px', marginBottom: '15px' }}>Conversion Metrics</h3>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
                      <div className="flex-center" style={{ flexDirection: 'column', padding: '20px', borderRadius: '8px', backgroundColor: 'rgba(0,0,0,0.1)' }}>
                        <span className="text-muted" style={{ fontSize: '11px', textTransform: 'uppercase' }}>Conversion Success Rate</span>
                        <h2 style={{ fontSize: '48px', color: 'var(--accent-gold)', marginTop: '5px', fontFamily: 'var(--font-display)' }}>
                          {leads.length > 0 ? Math.round((leads.filter(l => l.status === 'CONVERTED').length / leads.length) * 100) : 0}%
                        </h2>
                      </div>

                      <div className="flex-between" style={{ borderBottom: '1px solid var(--border-color)', paddingBottom: '8px' }}>
                        <span style={{ fontSize: '13px' }}>Total Funnel Opportunities:</span>
                        <strong>{leads.length} leads</strong>
                      </div>
                      <div className="flex-between" style={{ borderBottom: '1px solid var(--border-color)', paddingBottom: '8px' }}>
                        <span style={{ fontSize: '13px' }}>Converted Shoots:</span>
                        <strong>{leads.filter(l => l.status === 'CONVERTED').length}</strong>
                      </div>
                      <div className="flex-between">
                        <span style={{ fontSize: '13px' }}>Pipeline Inbound Value:</span>
                        <strong>{user.role === 'SUPER_ADMIN' ? `₹${leads.reduce((sum, l) => sum + l.budget, 0).toLocaleString()}` : '***'}</strong>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 9. GEAR INVENTORY VIEW */}
            {currentTab === 'inventory' && (
              <div>
                <div className="flex-between" style={{ marginBottom: '30px', flexWrap: 'wrap', gap: '15px' }}>
                  <div>
                    <h1 style={{ fontSize: '36px', fontWeight: 200 }}>Camera & Gear Inventory</h1>
                    <p className="text-muted">Track camera bodies, high-end lenses, cinematic drone kits, and lighting system allocations.</p>
                  </div>
                  {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') && (
                    <button onClick={() => setShowNewGearModal(true)} className="btn btn-primary" style={{ padding: '8px 16px', fontSize: '13px' }}>
                      + Add Gear
                    </button>
                  )}
                </div>

                <div className="card">
                  <div style={{ overflowX: 'auto' }}>
                    <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
                      <thead>
                        <tr style={{ borderBottom: '1px solid var(--border-color)', color: 'var(--text-muted)', fontSize: '12px', textTransform: 'uppercase' }}>
                          <th style={{ padding: '12px' }}>Equipment Name</th>
                          <th style={{ padding: '12px' }}>Category</th>
                          <th style={{ padding: '12px' }}>Serial Identifier</th>
                          <th style={{ padding: '12px' }}>Allocation Status</th>
                          <th style={{ padding: '12px' }}>Assigned Crew</th>
                          <th style={{ padding: '12px' }}>Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {inventory.map(item => (
                          <tr key={item.itemId} style={{ borderBottom: '1px solid var(--border-color)', fontSize: '14px' }}>
                            <td style={{ padding: '16px 12px', fontWeight: 500 }}>{item.name}</td>
                            <td style={{ padding: '16px 12px' }}>
                              <span className="badge badge-planning" style={{ fontSize: '9px' }}>{item.category}</span>
                            </td>
                            <td style={{ padding: '16px 12px', color: 'var(--text-secondary)', fontFamily: 'monospace' }}>{item.serialNumber}</td>
                            <td style={{ padding: '16px 12px' }}>
                              <span className={`badge ${
                                item.status === 'IN_STUDIO' ? 'badge-completed' :
                                item.status === 'ON_LOCATION' ? 'badge-proofing' : 'badge-progress'
                              }`} style={{ fontSize: '9px' }}>
                                {item.status.replace('_', ' ')}
                              </span>
                            </td>
                            <td style={{ padding: '16px 12px', fontWeight: 500 }}>{item.assignedTo || '—'}</td>
                            <td style={{ padding: '16px 12px' }}>
                              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                                <select
                                  className="form-control"
                                  value={item.status}
                                  onChange={async (e) => {
                                    const nextStatus = e.target.value as any;
                                    const crew = nextStatus === 'ON_LOCATION' ? 'Siddharth Sen' : '';
                                    await apiService.updateInventoryStatus(item.itemId, nextStatus, crew);
                                    loadData();
                                  }}
                                  style={{ padding: '4px 10px', fontSize: '12px', width: 'auto' }}
                                >
                                  <option value="IN_STUDIO">Check In Studio</option>
                                  <option value="ON_LOCATION">Check Out (Shoot)</option>
                                  <option value="MAINTENANCE">Send to Repair</option>
                                </select>
                                {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') && (
                                  <>
                                    <button
                                      onClick={() => {
                                        setSelectedGear(item);
                                        setEditGearName(item.name);
                                        setEditGearCategory(item.category);
                                        setEditGearSerial(item.serialNumber);
                                        setEditGearStatus(item.status);
                                        setEditGearAssignedTo(item.assignedTo || '');
                                        setShowEditGearModal(true);
                                      }}
                                      className="btn btn-gold-outline"
                                      style={{ padding: '6px 10px', fontSize: '11px', border: 'none', cursor: 'pointer' }}
                                      title="Edit Gear Details"
                                    >
                                      ✏️ Edit
                                    </button>
                                    <button
                                      onClick={async () => {
                                        if (confirm(`Are you sure you want to remove ${item.name}?`)) {
                                          await apiService.deleteInventoryItem(item.itemId);
                                          loadData();
                                        }
                                      }}
                                      className="btn btn-danger"
                                      style={{ padding: '6px 10px', fontSize: '11px', border: 'none' }}
                                      title="Remove Equipment"
                                    >
                                      🗑️ Remove
                                    </button>
                                  </>
                                )}
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* 10. CLIENT SUBSCRIPTIONS VIEW */}
            {currentTab === 'subscriptions' && (
              <div>
                <div className="flex-between" style={{ marginBottom: '30px', flexWrap: 'wrap', gap: '15px' }}>
                  <div>
                    <h1 style={{ fontSize: '36px', fontWeight: 200 }}>Software & Gallery Subscriptions</h1>
                    <p className="text-muted">Track software subscription fees, hosting plans, billing cycles, and tool vendor payments.</p>
                  </div>
                  {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') && (
                    <button onClick={() => setShowNewSubscriptionModal(true)} className="btn btn-primary" style={{ padding: '8px 16px', fontSize: '13px' }}>
                      + Add Subscription
                    </button>
                  )}
                </div>

                <div className="card">
                  <div style={{ overflowX: 'auto' }}>
                    <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
                      <thead>
                        <tr style={{ borderBottom: '1px solid var(--border-color)', color: 'var(--text-muted)', fontSize: '12px', textTransform: 'uppercase' }}>
                          <th style={{ padding: '12px' }}>Plan / Service Name</th>
                          <th style={{ padding: '12px' }}>Client / Vendor Name</th>
                          <th style={{ padding: '12px' }}>Pricing Rate</th>
                          <th style={{ padding: '12px' }}>Billing Cycle</th>
                          <th style={{ padding: '12px' }}>Start Date</th>
                          <th style={{ padding: '12px' }}>Status</th>
                          <th style={{ padding: '12px' }}>Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {subscriptions.map(sub => (
                          <tr key={sub.subscriptionId} style={{ borderBottom: '1px solid var(--border-color)', fontSize: '14px' }}>
                            <td style={{ padding: '16px 12px', fontWeight: 600 }}>{sub.planName}</td>
                            <td style={{ padding: '16px 12px', color: 'var(--text-secondary)' }}>{sub.clientName}</td>
                            <td style={{ padding: '16px 12px', fontWeight: 600 }} className="text-gold">₹{sub.price.toLocaleString()}</td>
                            <td style={{ padding: '16px 12px' }}>
                              <span className="badge badge-planning" style={{ fontSize: '9px' }}>{sub.billingCycle}</span>
                            </td>
                            <td style={{ padding: '16px 12px' }}>{new Date(sub.startDate).toLocaleDateString()}</td>
                            <td style={{ padding: '16px 12px' }}>
                              <span className={`badge ${sub.status === 'ACTIVE' ? 'badge-completed' : 'badge-progress'}`} style={{ fontSize: '9px' }}>
                                {sub.status}
                              </span>
                            </td>
                            <td style={{ padding: '16px 12px' }}>
                              <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                                {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') && (
                                  <>
                                    <button
                                      onClick={() => {
                                        setSelectedSubscription(sub);
                                        setEditSubClientName(sub.clientName);
                                        setEditSubPlanName(sub.planName);
                                        setEditSubPrice(sub.price);
                                        setEditSubBillingCycle(sub.billingCycle);
                                        setEditSubStartDate(sub.startDate);
                                        setEditSubStatus(sub.status);
                                        setShowEditSubscriptionModal(true);
                                      }}
                                      className="btn btn-gold-outline"
                                      style={{ padding: '6px 10px', fontSize: '11px', border: 'none', cursor: 'pointer' }}
                                      title="Edit Subscription Plan"
                                    >
                                      ✏️ Edit
                                    </button>
                                    <button
                                      onClick={async () => {
                                        if (confirm(`Are you sure you want to delete the subscription for ${sub.planName}?`)) {
                                          await apiService.deleteSubscription(sub.subscriptionId);
                                          loadData();
                                        }
                                      }}
                                      className="btn btn-danger"
                                      style={{ padding: '6px 10px', fontSize: '11px', border: 'none', cursor: 'pointer' }}
                                      title="Delete Subscription"
                                    >
                                      🗑️ Delete
                                    </button>
                                  </>
                                )}
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {currentTab === 'proposals' && (
              <div>
                <div className="flex-between" style={{ marginBottom: '30px', flexWrap: 'wrap', gap: '15px' }}>
                  <div>
                    <h1 style={{ fontSize: '36px', fontWeight: 200 }}>Photography & Wedding Proposals</h1>
                    <p className="text-muted">Draft proposals, customize packaging details, coordinate add-ons, and review version histories.</p>
                  </div>
                  {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') && (
                    <button 
                      onClick={() => {
                        setPropClientEmail('rohan@gmail.com');
                        setPropClientName('Rohan Sharma');
                        setPropClientPhone('+91 9123456789');
                        setPropTitle('A Celebration Proposal');
                        setPropDescription('For you, and the years to come. Weddings, remembered as the stories they actually are.');
                        setPropBudget(360000);
                        setPropDeliverables('1 photographer + 1 cinematographer at all events\nFull team (2 + 2) at your Wedding\n6–8 hours of coverage per event\n500 edited photographs + all raw images\n5-minute highlight film\n1-minute teaser film');
                        setPropTerms('An advance payment of 50% confirms the booking and reserves your dates exclusively on our calendar.');
                        setShowNewProposalModal(true);
                      }} 
                      className="btn btn-primary" 
                      style={{ padding: '8px 16px', fontSize: '13px' }}
                    >
                      + Create Proposal
                    </button>
                  )}
                </div>

                <div className="grid-grid" style={{ display: 'grid', gridTemplateColumns: proposals.length > 0 ? '1.5fr 2.5fr' : '1fr', gap: '30px', alignItems: 'start' }}>
                  {/* List of Proposals */}
                  <div className="card">
                    <h3 style={{ fontSize: '20px', fontWeight: 300, marginBottom: '20px' }}>Active Proposal Sheets</h3>
                    {proposals.length === 0 ? (
                      <p className="text-muted">No photography proposals drafted yet.</p>
                    ) : (
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
                        {proposals.map(prop => (
                          <div 
                            key={prop.proposalId} 
                            onClick={() => {
                              setSelectedProposal(prop);
                              const latestV = prop.versions[prop.versions.length - 1];
                              if (latestV) {
                                setSelectedPropVersionNum(latestV.version);
                              }
                            }}
                            style={{ 
                              padding: '16px 20px', 
                              border: selectedProposal?.proposalId === prop.proposalId ? '2px solid var(--accent-gold)' : '1px solid var(--border-color)', 
                              borderRadius: '8px', 
                              backgroundColor: 'var(--bg-secondary)',
                              cursor: 'pointer',
                              transition: 'all 0.2s'
                            }}
                          >
                            <div className="flex-between" style={{ marginBottom: '6px' }}>
                              <h4 className="text-gold" style={{ fontWeight: 400 }}>{prop.clientName}</h4>
                              <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                                <span className={`badge ${
                                  prop.status === 'ACCEPTED' ? 'badge-completed' :
                                  prop.status === 'SENT' ? 'badge-proofing' : 'badge-progress'
                                }`} style={{ fontSize: '8px' }}>
                                  {prop.status}
                                </span>
                                {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') && (
                                  <button
                                    onClick={async (e) => {
                                      e.stopPropagation();
                                      if (confirm("Are you sure you want to delete this proposal?")) {
                                        await apiService.deleteProposal(prop.proposalId);
                                        loadData();
                                      }
                                    }}
                                    style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px' }}
                                    title="Delete Proposal"
                                  >
                                    🗑️
                                  </button>
                                )}
                              </div>
                            </div>
                            <p style={{ fontSize: '13px' }}><strong>{prop.versions[prop.versions.length - 1]?.title || 'Celebration Proposal'}</strong></p>
                            <p className="text-muted" style={{ fontSize: '11px', marginTop: '4px' }}>Versions: {prop.versions.length} | Current: v{prop.currentVersion}</p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Active Proposal View Details */}
                  {selectedProposal && (
                    <div className="card" style={{ border: '1px solid var(--accent-gold-border)' }}>
                      <div className="flex-between" style={{ borderBottom: '1px solid var(--border-color)', paddingBottom: '15px', marginBottom: '20px', flexWrap: 'wrap', gap: '15px' }}>
                        <div>
                          <span className="text-muted" style={{ fontSize: '10px', textTransform: 'uppercase', letterSpacing: '1px' }}>Proposal Sheet Detail</span>
                          <h2 className="text-gold" style={{ fontSize: '26px', fontWeight: 300, margin: '5px 0' }}>{selectedProposal.clientName}</h2>
                          <p style={{ fontSize: '12px', color: 'var(--text-secondary)', margin: 0 }}>Email: {selectedProposal.clientEmail} | Phone: {selectedProposal.clientPhone}</p>
                        </div>
                        <div style={{ display: 'flex', gap: '15px', alignItems: 'center', flexWrap: 'wrap' }}>
                          <span className={`badge ${
                            selectedProposal.status === 'ACCEPTED' ? 'badge-completed' :
                            selectedProposal.status === 'SENT' ? 'badge-proofing' : 'badge-progress'
                          }`} style={{ fontSize: '10px', padding: '6px 12px' }}>
                            {selectedProposal.status}
                          </span>
                          
                          {/* Version Select Revision History Dropdown */}
                          <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                            <label style={{ fontSize: '11px', fontWeight: 600, color: 'var(--text-secondary)' }}>VERSION:</label>
                            <select
                              className="form-control"
                              value={selectedPropVersionNum}
                              onChange={(e) => setSelectedPropVersionNum(Number(e.target.value))}
                              style={{ padding: '4px 8px', fontSize: '12px', width: 'auto', display: 'inline-block' }}
                            >
                              {selectedProposal.versions.map(v => (
                                <option key={v.version} value={v.version}>v{v.version} ({new Date(v.createdAt).toLocaleDateString()})</option>
                              ))}
                            </select>
                          </div>
                        </div>
                      </div>

                      {/* Version Content Display */}
                      {(() => {
                        const activeVer = selectedProposal.versions.find(v => v.version === selectedPropVersionNum) || selectedProposal.versions[selectedProposal.versions.length - 1];
                        if (!activeVer) return null;
                        return (
                          <div>
                            <div className="flex-between" style={{ marginBottom: '20px' }}>
                              <h3 style={{ fontSize: '22px', fontWeight: 300, color: 'var(--text-primary)', margin: 0 }}>{activeVer.title}</h3>
                              <h2 className="text-gold" style={{ fontSize: '28px', fontFamily: 'var(--font-display)', fontWeight: 400, margin: 0 }}>
                                {user.role === 'SUPER_ADMIN' ? `₹${activeVer.budget.toLocaleString()}` : '***'}
                              </h2>
                            </div>
                            
                            <p style={{ fontSize: '14px', fontStyle: 'italic', color: 'var(--text-secondary)', marginBottom: '20px', lineHeight: 1.5 }}>
                              "{activeVer.description}"
                            </p>

                            <div style={{ marginBottom: '25px' }}>
                              <h4 className="form-label" style={{ marginBottom: '10px', color: 'var(--accent-gold)' }}>What You'll Receive / Inclusions</h4>
                              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                                {(Array.isArray(activeVer.deliverables) ? activeVer.deliverables : String(activeVer.deliverables).split('\n')).map((del, index) => (
                                  <div key={index} className="flex-center" style={{ justifyContent: 'flex-start', gap: '8px', fontSize: '13px' }}>
                                    <span style={{ color: 'var(--accent-gold)' }}>✦</span>
                                    <span>{del}</span>
                                  </div>
                                ))}
                              </div>
                            </div>

                            <div style={{ marginBottom: '25px', borderTop: '1px solid var(--border-color)', paddingTop: '15px' }}>
                              <h4 className="form-label" style={{ marginBottom: '6px', color: 'var(--accent-gold)' }}>Terms & Process</h4>
                              <p style={{ fontSize: '12px', color: 'var(--text-secondary)', lineHeight: 1.6 }}>{activeVer.terms}</p>
                            </div>

                            {/* Actions bar for Proposal */}
                            <div style={{ display: 'flex', gap: '10px', marginTop: '30px', flexWrap: 'wrap' }}>
                              {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') && (
                                <button
                                  onClick={() => {
                                    setPropTitle(activeVer.title);
                                    setPropDescription(activeVer.description);
                                    setPropBudget(activeVer.budget);
                                    setPropDeliverables(Array.isArray(activeVer.deliverables) ? activeVer.deliverables.join('\n') : String(activeVer.deliverables));
                                    setPropTerms(activeVer.terms);
                                    setShowEditProposalModal(true);
                                  }}
                                  className="btn btn-gold-outline"
                                  style={{ padding: '8px 16px', fontSize: '12px' }}
                                >
                                  ✏️ Draft New Version (v{selectedProposal.currentVersion + 1})
                                </button>
                              )}

                              <button
                                onClick={() => handlePrintProposal(selectedProposal, activeVer)}
                                className="btn btn-primary"
                                style={{ padding: '8px 16px', fontSize: '12px' }}
                              >
                                🖨️ Download PDF Proposal
                              </button>

                              {(() => {
                                let pdfFileName = "TheStoryBox_Proposal.pdf";
                                const lowerTitle = activeVer.title.toLowerCase();
                                if (lowerTitle.includes('essence')) {
                                  pdfFileName = "TheStoryBox_Essence.pdf";
                                } else if (lowerTitle.includes('heritage')) {
                                  pdfFileName = "TheStoryBox_Heritage.pdf";
                                } else if (lowerTitle.includes('legacy')) {
                                  pdfFileName = "TheStoryBox_Legacy.pdf";
                                }
                                
                                return (
                                  <a 
                                    href={`/${pdfFileName}`} 
                                    download={pdfFileName} 
                                    className="btn btn-secondary" 
                                    style={{ padding: '8px 16px', fontSize: '12px', display: 'inline-flex', alignItems: 'center' }}
                                  >
                                    📥 Original Catalog
                                  </a>
                                );
                              })()}

                              {(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') && (
                                <>
                                  {selectedProposal.status === 'DRAFT' && (
                                    <button
                                      onClick={async () => {
                                        await apiService.updateProposal(selectedProposal.proposalId, { status: 'SENT', statusOnly: true } as any);
                                        loadData();
                                      }}
                                      className="btn btn-primary"
                                      style={{ padding: '8px 16px', fontSize: '12px' }}
                                    >
                                      ✉️ Mark as Sent
                                    </button>
                                  )}
                                  {selectedProposal.status !== 'ACCEPTED' && selectedProposal.status !== 'REJECTED' && (
                                    <>
                                      <button
                                        onClick={async () => {
                                          await apiService.updateProposal(selectedProposal.proposalId, { status: 'ACCEPTED', statusOnly: true } as any);
                                          loadData();
                                        }}
                                        className="btn btn-success"
                                        style={{ padding: '8px 16px', fontSize: '12px', backgroundColor: 'var(--success)', border: 'none', color: '#fff' }}
                                      >
                                        ✅ Accept Proposal
                                      </button>
                                      <button
                                        onClick={async () => {
                                          await apiService.updateProposal(selectedProposal.proposalId, { status: 'REJECTED', statusOnly: true } as any);
                                          loadData();
                                        }}
                                        className="btn btn-danger"
                                        style={{ padding: '8px 16px', fontSize: '12px' }}
                                      >
                                        ❌ Reject
                                      </button>
                                    </>
                                  )}
                                  <button
                                    onClick={async () => {
                                      if (confirm("Are you sure you want to delete this entire proposal sheet? This will wipe all its version revisions.")) {
                                        await apiService.deleteProposal(selectedProposal.proposalId);
                                        setSelectedProposal(null);
                                        loadData();
                                      }
                                    }}
                                    className="btn btn-danger"
                                    style={{ padding: '8px 16px', fontSize: '12px' }}
                                  >
                                    🗑️ Delete Completely
                                  </button>
                                </>
                              )}
                            </div>
                          </div>
                        );
                      })()}
                    </div>
                  )}
                </div>
              </div>
            )}

            {currentTab === 'hoa-tracker' && (
              <div>
                <div className="flex-between" style={{ marginBottom: '30px', flexWrap: 'wrap', gap: '15px' }}>
                  <div>
                    <h1 style={{ fontSize: '36px', fontWeight: 200 }}>House of Aliveni Tracker</h1>
                    <p className="text-muted">Manage jewelry manufacturers, smiths, and importers, monitor purchase orders, and track sourcing cycles.</p>
                  </div>
                  <div style={{ display: 'flex', gap: '10px' }}>
                    <button 
                      onClick={() => setHoaTrackerTab('vendors')}
                      className={`btn ${hoaTrackerTab === 'vendors' ? 'btn-primary' : 'btn-secondary'}`}
                      style={{ padding: '8px 16px', fontSize: '13px' }}
                    >
                      Vendors List
                    </button>
                    <button 
                      onClick={() => setHoaTrackerTab('purchase_orders')}
                      className={`btn ${hoaTrackerTab === 'purchase_orders' ? 'btn-primary' : 'btn-secondary'}`}
                      style={{ padding: '8px 16px', fontSize: '13px' }}
                    >
                      Purchase Orders
                    </button>
                  </div>
                </div>

                {/* VENDORS PANEL */}
                {hoaTrackerTab === 'vendors' && (
                  <div className="card">
                    <div className="flex-between" style={{ marginBottom: '20px', flexWrap: 'wrap', gap: '15px' }}>
                      <h3 style={{ fontSize: '20px', fontWeight: 300 }}>Jewellery & Sourcing Vendors</h3>
                      <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                        <input
                          type="text"
                          placeholder="Search vendors..."
                          className="form-control"
                          style={{ padding: '6px 12px', fontSize: '13px', width: '200px' }}
                          value={hoaSearchQuery}
                          onChange={(e) => setHoaSearchQuery(e.target.value)}
                        />
                        <button
                          onClick={() => {
                            setNewVendorName('');
                            setNewVendorContact('');
                            setNewVendorEmail('');
                            setNewVendorPhone('');
                            setNewVendorAddress('');
                            setNewVendorCategory('Manufacturer');
                            setNewVendorScore(5);
                            setNewVendorShopImage('');
                            setNewVendorLocation('Chennai');
                            setNewVendorCustomLocation('');
                            setNewVendorSuppliedItems('');
                            setShowNewVendorModal(true);
                          }}
                          className="btn btn-primary"
                          style={{ padding: '8px 16px', fontSize: '13px' }}
                        >
                          + Add Vendor
                        </button>
                      </div>
                    </div>

                    <div style={{ overflowX: 'auto' }}>
                      <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
                        <thead>
                          <tr style={{ borderBottom: '2px solid var(--border-color)', color: 'var(--text-secondary)', fontSize: '13px' }}>
                            <th style={{ padding: '12px 8px', width: '60px' }}>Shop</th>
                            <th style={{ padding: '12px 8px' }}>Vendor Name</th>
                            <th style={{ padding: '12px 8px' }}>Location</th>
                            <th style={{ padding: '12px 8px' }}>Category</th>
                            <th style={{ padding: '12px 8px' }}>Contact Person</th>
                            <th style={{ padding: '12px 8px' }}>Supplied Items</th>
                            <th style={{ padding: '12px 8px' }}>Score</th>
                            <th style={{ padding: '12px 8px' }}>Status</th>
                            <th style={{ padding: '12px 8px', textAlign: 'right' }}>Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {hoaVendors
                            .filter(v => v.name.toLowerCase().includes(hoaSearchQuery.toLowerCase()) || v.contactPerson.toLowerCase().includes(hoaSearchQuery.toLowerCase()))
                            .map(v => (
                              <tr key={v.vendorId} style={{ borderBottom: '1px solid var(--border-color)', fontSize: '14px' }}>
                                <td style={{ padding: '12px 8px' }}>
                                  {v.shopImage ? (
                                    <img 
                                      src={v.shopImage} 
                                      alt={v.name} 
                                      style={{ width: '40px', height: '40px', borderRadius: '50%', objectFit: 'cover', border: '1px solid var(--border-color)' }} 
                                    />
                                  ) : (
                                    <div style={{ width: '40px', height: '40px', borderRadius: '50%', backgroundColor: 'rgba(212,175,55,0.1)', border: '1px dashed #d4af37', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '18px' }}>
                                      💎
                                    </div>
                                  )}
                                </td>
                                <td style={{ padding: '12px 8px', fontWeight: 500 }} className="text-gold">{v.name}</td>
                                <td style={{ padding: '12px 8px' }}>
                                  <span className={`badge ${
                                    v.location === 'China' ? 'badge-planning' :
                                    v.location === 'Chennai' ? 'badge-proofing' :
                                    'badge-progress'
                                  }`} style={{ fontSize: '11px', textTransform: 'none', padding: '3px 8px' }}>
                                    📍 {v.location || 'N/A'}
                                  </span>
                                </td>
                                <td style={{ padding: '12px 8px' }}>{v.category}</td>
                                <td style={{ padding: '12px 8px' }}>
                                  <div>{v.contactPerson}</div>
                                  <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>{v.phone}</div>
                                  <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>{v.email}</div>
                                </td>
                                <td style={{ padding: '12px 8px' }}>
                                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px', maxWidth: '220px' }}>
                                    {v.suppliedItems && v.suppliedItems.length > 0 ? (
                                      v.suppliedItems.map((item, idx) => (
                                        <span 
                                          key={idx} 
                                          style={{ 
                                            fontSize: '10px', 
                                            backgroundColor: 'rgba(212, 175, 55, 0.1)', 
                                            color: '#d4af37', 
                                            border: '1px solid rgba(212, 175, 55, 0.2)',
                                            padding: '1px 5px', 
                                            borderRadius: '3px',
                                            whiteSpace: 'nowrap'
                                          }}
                                        >
                                          {item}
                                        </span>
                                      ))
                                    ) : (
                                      <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}>None</span>
                                    )}
                                  </div>
                                </td>
                                <td style={{ padding: '12px 8px', color: '#eab308', whiteSpace: 'nowrap' }}>
                                  {'★'.repeat(v.performanceScore || 5)}{'☆'.repeat(5 - (v.performanceScore || 5))}
                                </td>
                                <td style={{ padding: '12px 8px' }}>
                                  <span className={`badge ${v.status === 'ACTIVE' ? 'badge-completed' : 'badge-planning'}`} style={{ fontSize: '9px' }}>
                                    {v.status}
                                  </span>
                                </td>
                                <td style={{ padding: '12px 8px', textAlign: 'right', whiteSpace: 'nowrap' }}>
                                  <button
                                    onClick={() => {
                                      setSelectedVendor(v);
                                      setEditVendorName(v.name);
                                      setEditVendorContact(v.contactPerson);
                                      setEditVendorEmail(v.email);
                                      setEditVendorPhone(v.phone);
                                      setEditVendorAddress(v.address);
                                      setEditVendorCategory(v.category);
                                      setEditVendorScore(v.performanceScore);
                                      setEditVendorShopImage(v.shopImage || '');
                                      const isPresetLoc = ['Chennai', 'China'].includes(v.location);
                                      setEditVendorLocation(isPresetLoc ? v.location : 'Other');
                                      setEditVendorCustomLocation(isPresetLoc ? '' : v.location);
                                      setEditVendorSuppliedItems(v.suppliedItems ? v.suppliedItems.join(', ') : '');
                                      setShowEditVendorModal(true);
                                    }}
                                    className="btn btn-secondary"
                                    style={{ padding: '4px 8px', fontSize: '12px', marginRight: '5px' }}
                                  >
                                    Edit
                                  </button>
                                  <button
                                    onClick={async () => {
                                      if (confirm(`Are you sure you want to delete vendor "${v.name}"?`)) {
                                        await apiService.deleteHoaVendor(v.vendorId);
                                        loadData();
                                      }
                                    }}
                                    className="btn btn-danger"
                                    style={{ padding: '4px 8px', fontSize: '12px' }}
                                  >
                                    Delete
                                  </button>
                                </td>
                              </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* PURCHASE ORDERS PANEL */}
                {hoaTrackerTab === 'purchase_orders' && (
                  <div className="card">
                    <div className="flex-between" style={{ marginBottom: '20px', flexWrap: 'wrap', gap: '15px' }}>
                      <h3 style={{ fontSize: '20px', fontWeight: 300 }}>Vendor Purchase Orders</h3>
                      <button
                        onClick={() => {
                          setNewPoVendorId('');
                          setNewPoDeliveryDate('');
                          setNewPoItems([]);
                          setNewPoItemName('');
                          setNewPoItemSku('');
                          setNewPoItemQuantity(1);
                          setNewPoItemUnitPrice(0);
                          setShowNewPoModal(true);
                        }}
                        className="btn btn-primary"
                        style={{ padding: '8px 16px', fontSize: '13px' }}
                      >
                        + Create Purchase Order
                      </button>
                    </div>

                    <div style={{ overflowX: 'auto' }}>
                      <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
                        <thead>
                          <tr style={{ borderBottom: '2px solid var(--border-color)', color: 'var(--text-secondary)', fontSize: '13px' }}>
                            <th style={{ padding: '12px 8px' }}>PO ID</th>
                            <th style={{ padding: '12px 8px' }}>Vendor</th>
                            <th style={{ padding: '12px 8px' }}>Order Date</th>
                            <th style={{ padding: '12px 8px' }}>Delivery Date</th>
                            <th style={{ padding: '12px 8px' }}>Items Summary</th>
                            <th style={{ padding: '12px 8px' }}>Total Amount</th>
                            <th style={{ padding: '12px 8px' }}>Receipt</th>
                            <th style={{ padding: '12px 8px' }}>Fulfillment</th>
                            <th style={{ padding: '12px 8px' }}>Payment</th>
                            <th style={{ padding: '12px 8px', textAlign: 'right' }}>Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {hoaPurchaseOrders.map(po => (
                            <tr key={po.poId} style={{ borderBottom: '1px solid var(--border-color)', fontSize: '14px' }}>
                              <td style={{ padding: '12px 8px', fontFamily: 'monospace', fontSize: '12px' }}>{po.poId.slice(0, 8).toUpperCase()}</td>
                              <td style={{ padding: '12px 8px', fontWeight: 500 }}>{po.vendorName}</td>
                              <td style={{ padding: '12px 8px' }}>{po.orderDate}</td>
                              <td style={{ padding: '12px 8px' }}>{po.deliveryDate || 'Pending'}</td>
                              <td style={{ padding: '12px 8px' }}>
                                <div style={{ fontSize: '12px', whiteSpace: 'pre-line' }}>
                                  {po.items.map(it => `• ${it.name} (${it.quantity}x)`).join('\n')}
                                </div>
                              </td>
                              <td style={{ padding: '12px 8px', fontWeight: 500 }}>₹{po.totalAmount.toLocaleString()}</td>
                              <td style={{ padding: '12px 8px' }}>
                                {po.poImage ? (
                                  <a 
                                    href={po.poImage} 
                                    target="_blank" 
                                    rel="noopener noreferrer"
                                    style={{ fontSize: '12px', display: 'flex', alignItems: 'center', gap: '3px', textDecoration: 'none' }}
                                    className="text-gold"
                                  >
                                    🖼️ View
                                  </a>
                                ) : (
                                  <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}>None</span>
                                )}
                              </td>
                              <td style={{ padding: '12px 8px' }}>
                                <span className={`badge ${
                                  po.status === 'DELIVERED' ? 'badge-completed' :
                                  po.status === 'SENT' ? 'badge-proofing' :
                                  po.status === 'CANCELLED' ? 'badge-planning' : 'badge-progress'
                                }`} style={{ fontSize: '9px' }}>
                                  {po.status}
                                </span>
                              </td>
                              <td style={{ padding: '12px 8px' }}>
                                <span className={`badge ${
                                  po.paymentStatus === 'PAID' ? 'badge-completed' :
                                  po.paymentStatus === 'PARTIALLY_PAID' ? 'badge-progress' : 'badge-planning'
                                }`} style={{ fontSize: '9px' }}>
                                  {po.paymentStatus}
                                </span>
                              </td>
                              <td style={{ padding: '12px 8px', textAlign: 'right', whiteSpace: 'nowrap' }}>
                                <button
                                  onClick={() => {
                                    setSelectedPo(po);
                                    setEditPoVendorId(po.vendorId);
                                    setEditPoDeliveryDate(po.deliveryDate || '');
                                    setEditPoStatus(po.status);
                                    setEditPoPaymentStatus(po.paymentStatus);
                                    setEditPoImage(po.poImage || '');
                                    setEditPoItems(po.items || []);
                                    setShowEditPoModal(true);
                                  }}
                                  className="btn btn-secondary"
                                  style={{ padding: '4px 8px', fontSize: '12px', marginRight: '5px' }}
                                >
                                  Edit
                                </button>
                                {po.status !== 'DELIVERED' && po.status !== 'CANCELLED' && (
                                  <button
                                    onClick={async () => {
                                      if (confirm("Mark this Purchase Order as Delivered? This will automatically increment stock levels for matching items in the HOA Inventory.")) {
                                        await apiService.updateHoaPurchaseOrder(po.poId, { status: 'DELIVERED', deliveryDate: new Date().toISOString().split('T')[0] });
                                        loadData();
                                      }
                                    }}
                                    className="btn btn-primary"
                                    style={{ padding: '4px 8px', fontSize: '11px', marginRight: '5px', backgroundColor: 'var(--success)' }}
                                  >
                                    ✓ Deliver
                                  </button>
                                )}
                                <button
                                  onClick={async () => {
                                    if (confirm("Are you sure you want to delete this purchase order?")) {
                                      await apiService.deleteHoaPurchaseOrder(po.poId);
                                      loadData();
                                    }
                                  }}
                                  className="btn btn-danger"
                                  style={{ padding: '4px 8px', fontSize: '12px' }}
                                >
                                  Delete
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            )}

            {currentTab === 'hoa-inventory' && (
              <div>
                <div className="flex-between" style={{ marginBottom: '30px', flexWrap: 'wrap', gap: '15px' }}>
                  <div>
                    <h1 style={{ fontSize: '36px', fontWeight: 200 }}>House of Aliveni Inventory</h1>
                    <p className="text-muted">Track jewelry stock levels, SKU identifiers, material unit prices, and replenishment indicators.</p>
                  </div>
                  <button
                    onClick={() => {
                      setNewHoaItemName('');
                      setNewHoaItemSku('');
                      setNewHoaItemCategory('Necklace');
                      setNewHoaItemStock(10);
                      setNewHoaItemReorder(5);
                      setNewHoaItemUnitPrice(5000);
                      setNewHoaItemVendorId(hoaVendors[0]?.vendorId || '');
                      setNewHoaItemImage('');
                      setShowNewHoaItemModal(true);
                    }}
                    className="btn btn-primary"
                    style={{ padding: '8px 16px', fontSize: '13px' }}
                  >
                    + Add Inventory Item
                  </button>
                </div>

                <div className="card">
                  <div className="flex-between" style={{ marginBottom: '20px', flexWrap: 'wrap', gap: '15px' }}>
                    <h3 style={{ fontSize: '20px', fontWeight: 300 }}>Stock Details</h3>
                    <div style={{ display: 'flex', gap: '10px' }}>
                      <select
                        className="form-control"
                        style={{ padding: '6px 12px', fontSize: '13px' }}
                        value={hoaFilterCategory}
                        onChange={(e) => setHoaFilterCategory(e.target.value)}
                      >
                        <option value="">All Categories</option>
                        <option value="Anklet">Anklet</option>
                        <option value="Anklets">Anklets</option>
                        <option value="Bracelet">Bracelet</option>
                        <option value="Bracelets">Bracelets</option>
                        <option value="Dual Layer Chains">Dual Layer Chains</option>
                        <option value="Dual Layer Necklace">Dual Layer Necklace</option>
                        <option value="Earrings">Earrings</option>
                        <option value="Kada Bangle">Kada Bangle</option>
                        <option value="Kada Bangles">Kada Bangles</option>
                        <option value="Long Chain">Long Chain</option>
                        <option value="Long Chains">Long Chains</option>
                        <option value="Neckalces">Neckalces</option>
                        <option value="Necklace">Necklace</option>
                        <option value="Necklace with Earrings">Necklace with Earrings</option>
                        <option value="Necklaces">Necklaces</option>
                        <option value="Rings">Rings</option>
                        <option value="Short Earrings">Short Earrings</option>
                        <option value="Small Earrings">Small Earrings</option>
                        <option value="Studs Earrings">Studs Earrings</option>
                        <option value="Trendy Necklace">Trendy Necklace</option>
                      </select>
                      <select
                        className="form-control"
                        style={{ padding: '6px 12px', fontSize: '13px' }}
                        value={hoaFilterStatus}
                        onChange={(e) => setHoaFilterStatus(e.target.value)}
                      >
                        <option value="">All Statuses</option>
                        <option value="IN_STOCK">In Stock</option>
                        <option value="LOW_STOCK">Low Stock</option>
                        <option value="OUT_OF_STOCK">Out of Stock</option>
                      </select>
                    </div>
                  </div>

                  <div style={{ overflowX: 'auto' }}>
                    <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
                      <thead>
                        <tr style={{ borderBottom: '2px solid var(--border-color)', color: 'var(--text-secondary)', fontSize: '13px' }}>
                          <th style={{ padding: '12px 8px', width: '50px' }}>Image</th>
                          <th style={{ padding: '12px 8px' }}>SKU</th>
                          <th style={{ padding: '12px 8px' }}>Item Name</th>
                          <th style={{ padding: '12px 8px' }}>Category</th>
                          <th style={{ padding: '12px 8px' }}>Stock Level</th>
                          <th style={{ padding: '12px 8px' }}>Unit Price</th>
                          <th style={{ padding: '12px 8px' }}>Vendor</th>
                          <th style={{ padding: '12px 8px' }}>Status</th>
                          <th style={{ padding: '12px 8px', textAlign: 'right' }}>Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {hoaInventory
                          .filter(item => !hoaFilterCategory || item.category === hoaFilterCategory)
                          .filter(item => !hoaFilterStatus || item.status === hoaFilterStatus)
                          .map(item => {
                            const matchedVendor = hoaVendors.find(v => v.vendorId === item.vendorId);
                            const isLowStock = item.stockLevel <= item.reorderPoint;
                            return (
                              <tr key={item.itemId} style={{ borderBottom: '1px solid var(--border-color)', fontSize: '14px' }}>
                                <td style={{ padding: '12px 8px' }}>
                                  {item.itemImage ? (
                                    <a href={item.itemImage} target="_blank" rel="noopener noreferrer">
                                      <img 
                                        src={item.itemImage} 
                                        alt={item.name} 
                                        style={{ width: '36px', height: '36px', borderRadius: '50%', objectFit: 'cover', border: '1px solid var(--gold)', cursor: 'pointer' }} 
                                      />
                                    </a>
                                  ) : (
                                    <div style={{ width: '36px', height: '36px', borderRadius: '50%', border: '1px solid var(--border-color)', backgroundColor: 'var(--bg-secondary)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '16px' }}>
                                      💍
                                    </div>
                                  )}
                                </td>
                                <td style={{ padding: '12px 8px', fontFamily: 'monospace', fontSize: '12px', fontWeight: 600 }}>{item.sku}</td>
                                <td style={{ padding: '12px 8px', fontWeight: 500 }}>{item.name}</td>
                                <td style={{ padding: '12px 8px' }}>{item.category}</td>
                                <td style={{ padding: '12px 8px' }}>
                                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                    <span style={{ 
                                      fontWeight: 600,
                                      color: item.stockLevel <= 0 ? 'var(--danger)' : (isLowStock ? 'var(--warning)' : 'inherit'),
                                      backgroundColor: item.stockLevel <= 0 ? 'rgba(220,38,38,0.1)' : (isLowStock ? 'rgba(217,119,6,0.1)' : 'transparent'),
                                      padding: '2px 8px',
                                      borderRadius: '4px'
                                    }}>
                                      {item.stockLevel}
                                    </span>
                                    <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}>/ min: {item.reorderPoint}</span>
                                    
                                    {/* Quick Stock Adjustments */}
                                    <button 
                                      onClick={async () => {
                                        const newQty = Math.max(0, item.stockLevel - 1);
                                        await apiService.updateHoaInventoryItem(item.itemId, { stockLevel: newQty });
                                        loadData();
                                      }}
                                      className="btn btn-secondary" 
                                      style={{ padding: '2px 6px', fontSize: '10px', minWidth: '20px' }}
                                      title="Quick Decrement"
                                    >
                                      -
                                    </button>
                                    <button 
                                      onClick={async () => {
                                        const newQty = item.stockLevel + 1;
                                        await apiService.updateHoaInventoryItem(item.itemId, { stockLevel: newQty });
                                        loadData();
                                      }}
                                      className="btn btn-secondary" 
                                      style={{ padding: '2px 6px', fontSize: '10px', minWidth: '20px' }}
                                      title="Quick Increment"
                                    >
                                      +
                                    </button>
                                  </div>
                                </td>
                                <td style={{ padding: '12px 8px', fontWeight: 500 }}>₹{item.unitPrice.toLocaleString()}</td>
                                <td style={{ padding: '12px 8px' }}>{matchedVendor ? matchedVendor.name : 'Unknown Vendor'}</td>
                                <td style={{ padding: '12px 8px' }}>
                                  <span className={`badge ${
                                    item.status === 'IN_STOCK' ? 'badge-completed' :
                                    item.status === 'LOW_STOCK' ? 'badge-progress' : 'badge-planning'
                                  }`} style={{ fontSize: '9px' }}>
                                    {item.status.replace('_', ' ')}
                                  </span>
                                </td>
                                <td style={{ padding: '12px 8px', textAlign: 'right' }}>
                                  <button
                                    onClick={() => {
                                      setSelectedHoaItem(item);
                                      setEditHoaItemName(item.name);
                                      setEditHoaItemSku(item.sku);
                                      setEditHoaItemCategory(item.category);
                                      setEditHoaItemStock(item.stockLevel);
                                      setEditHoaItemReorder(item.reorderPoint);
                                      setEditHoaItemUnitPrice(item.unitPrice);
                                      setEditHoaItemVendorId(item.vendorId);
                                      setEditHoaItemImage(item.itemImage || '');
                                      setShowEditHoaItemModal(true);
                                    }}
                                    className="btn btn-secondary"
                                    style={{ padding: '4px 8px', fontSize: '12px', marginRight: '5px' }}
                                  >
                                    Edit
                                  </button>
                                  <button
                                    onClick={async () => {
                                      if (confirm(`Are you sure you want to delete item "${item.name}"?`)) {
                                        await apiService.deleteHoaInventoryItem(item.itemId);
                                        loadData();
                                      }
                                    }}
                                    className="btn btn-danger"
                                    style={{ padding: '4px 8px', fontSize: '12px' }}
                                  >
                                    Delete
                                  </button>
                                </td>
                              </tr>
                            );
                          })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </main>

      {/* --- LIGHTBOX FULLSCREEN ZOOM PROOFING MODAL --- */}
      {lightboxImage && (
        <div className="flex-center" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.95)', zIndex: 1000, padding: '20px' }}>
          
          {/* Close lightbox */}
          <button 
            onClick={() => setLightboxImage(null)} 
            style={{ position: 'absolute', top: '20px', right: '20px', background: 'rgba(255,255,255,0.1)', color: '#fff', border: 'none', width: '40px', height: '40px', borderRadius: '50%', cursor: 'pointer', fontSize: '20px' }}
          >
            ✕
          </button>

          {/* Navigation Arrows */}
          <button 
            onClick={() => navigateLightbox('prev')}
            style={{ position: 'absolute', left: '20px', background: 'rgba(255,255,255,0.1)', color: '#fff', border: 'none', width: '50px', height: '50px', borderRadius: '50%', cursor: 'pointer', fontSize: '24px' }}
          >
            ‹
          </button>
          
          <button 
            onClick={() => navigateLightbox('next')}
            style={{ position: 'absolute', right: '20px', background: 'rgba(255,255,255,0.1)', color: '#fff', border: 'none', width: '50px', height: '50px', borderRadius: '50%', cursor: 'pointer', fontSize: '24px' }}
          >
            ›
          </button>

          {/* Lightbox Content Container */}
          <div style={{ display: 'grid', gridTemplateColumns: '3fr 1fr', width: '100%', maxWidth: '1200px', height: '80vh', backgroundColor: 'var(--bg-card)', borderRadius: '12px', border: '1px solid var(--border-color)', overflow: 'hidden' }}>
            
            {/* Left: Huge image display */}
            <div className="flex-center" style={{ backgroundColor: '#000', padding: '20px', position: 'relative' }}>
              <img src={lightboxImage.url} style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }} alt="Lightbox photo" />
              
              {/* Proof Overlay Watermark */}
              <div style={{ position: 'absolute', color: 'rgba(255,255,255,0.15)', fontSize: '48px', fontWeight: 900, pointerEvents: 'none', transform: 'rotate(-30deg)', textTransform: 'uppercase', letterSpacing: '4px' }}>
                STORYBOX PROOF
              </div>
            </div>

            {/* Right: Selections & feedback comments */}
            <div style={{ padding: '30px', borderLeft: '1px solid var(--border-color)', display: 'flex', flexDirection: 'column', gap: '20px', backgroundColor: 'var(--bg-secondary)' }}>
              <div>
                <h3 style={{ fontSize: '18px', marginBottom: '6px' }}>Photo proof details</h3>
                <span className="text-muted" style={{ fontSize: '11px' }}>Image Index: {lightboxIndex + 1} of {galleryImages.length}</span>
              </div>

              <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '20px' }}>
                <p className="form-label" style={{ marginBottom: '10px' }}>Image Status</p>
                
                <button
                  onClick={() => {
                    if (user.role === 'CLIENT') toggleProofImage(lightboxImage.key);
                  }}
                  className={`btn ${lightboxImage.selected ? 'btn-primary' : 'btn-secondary'}`}
                  style={{ width: '100%', gap: '8px' }}
                  disabled={user.role !== 'CLIENT'}
                >
                  ★ {lightboxImage.selected ? 'Selected for Editing' : 'Select this Photo'}
                </button>
              </div>

              <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '8px' }}>
                <label className="form-label">Photographer Feedback Notes</label>
                <textarea
                  className="form-control"
                  style={{ flex: 1, resize: 'none', fontSize: '13px' }}
                  placeholder={user.role === 'CLIENT' ? "e.g., 'Touch up the warm lighting here' or 'Make black and white'" : "No feedback left by client yet."}
                  value={lightboxImage.comment}
                  onChange={(e) => {
                    if (user.role === 'CLIENT') updateComment(lightboxImage.key, e.target.value);
                  }}
                  disabled={user.role !== 'CLIENT'}
                />
              </div>

              {user.role === 'CLIENT' && (
                <button onClick={handleSaveProofing} className="btn btn-gold-outline" style={{ width: '100%' }}>
                  Save Selections
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* --- MODAL: CREATE NEW PROJECT --- */}
      {showNewProjectModal && (
        <div className="flex-center" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.85)', zIndex: 500, padding: '20px' }}>
          <div className="card" style={{ maxWidth: '500px', width: '100%' }}>
            <div className="flex-between" style={{ marginBottom: '20px' }}>
              <h2 style={{ fontSize: '24px' }}>Schedule New Photography Project</h2>
              <button onClick={() => setShowNewProjectModal(false)} style={{ background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer' }}>✕</button>
            </div>

            <form onSubmit={handleCreateProject}>
              <div className="form-group">
                <label className="form-label">Client Name/Email</label>
                <input
                  type="email"
                  className="form-control"
                  required
                  value={newProjClientEmail}
                  onChange={(e) => setNewProjClientEmail(e.target.value)}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Shoot Title Name</label>
                <input
                  type="text"
                  className="form-control"
                  required
                  placeholder="e.g. Meera Bridal Portrait"
                  value={newProjTitle}
                  onChange={(e) => setNewProjTitle(e.target.value)}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Shoot Category</label>
                  <select className="form-control" value={newProjType} onChange={(e) => setNewProjType(e.target.value)}>
                    <option value="Wedding">Wedding</option>
                    <option value="Commercial">Commercial</option>
                    <option value="Portfolio">Portfolio</option>
                    <option value="Pre-Wedding">Pre-Wedding</option>
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Event Date</label>
                  <input
                    type="date"
                    className="form-control"
                    required
                    value={newProjDate}
                    onChange={(e) => setNewProjDate(e.target.value)}
                  />
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Total Contract Value (₹)</label>
                <input
                  type="number"
                  className="form-control"
                  required
                  value={newProjAmount}
                  onChange={(e) => setNewProjAmount(Number(e.target.value))}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Shoot Setup Notes</label>
                <textarea
                  className="form-control"
                  style={{ height: '80px', resize: 'none' }}
                  placeholder="Describe lighting preferences, location setups..."
                  value={newProjNotes}
                  onChange={(e) => setNewProjNotes(e.target.value)}
                />
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '10px' }}>
                Schedule & Create Deliverables
              </button>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL: CREATE SCHEDULER BOOKING --- */}
      {showNewBookingModal && (
        <div className="flex-center" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.85)', zIndex: 500, padding: '20px' }}>
          <div className="card" style={{ maxWidth: '450px', width: '100%' }}>
            <div className="flex-between" style={{ marginBottom: '20px' }}>
              <h2 style={{ fontSize: '22px' }}>Book Photography Session</h2>
              <button onClick={() => setShowNewBookingModal(false)} style={{ background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer' }}>✕</button>
            </div>

            <form onSubmit={handleAddBooking}>
              <div className="form-group">
                <label className="form-label">Shoot Location / Venue</label>
                <input
                  type="text"
                  className="form-control"
                  required
                  placeholder="e.g. Studio A / Taj Krishna Grounds"
                  value={newBookLocation}
                  onChange={(e) => setNewBookLocation(e.target.value)}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Start Time</label>
                  <input
                    type="datetime-local"
                    className="form-control"
                    required
                    value={newBookStart}
                    onChange={(e) => setNewBookStart(e.target.value)}
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">End Time</label>
                  <input
                    type="datetime-local"
                    className="form-control"
                    required
                    value={newBookEnd}
                    onChange={(e) => setNewBookEnd(e.target.value)}
                  />
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Photographers Assigned</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Kesav TSB, Siddharth Sen (Comma separated)"
                  value={newBookPhotographers}
                  onChange={(e) => setNewBookPhotographers(e.target.value)}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Specific Crew Notes</label>
                <textarea
                  className="form-control"
                  style={{ height: '70px', resize: 'none' }}
                  placeholder="e.g. Pack backup prime lenses, gimbal setup..."
                  value={newBookNotes}
                  onChange={(e) => setNewBookNotes(e.target.value)}
                />
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '10px' }}>
                Confirm Session Booking
              </button>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL: CREATE MEDIA GALLERY CONTAINER --- */}
      {showNewGalleryModal && (
        <div className="flex-center" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.85)', zIndex: 500, padding: '20px' }}>
          <div className="card" style={{ maxWidth: '400px', width: '100%' }}>
            <div className="flex-between" style={{ marginBottom: '20px' }}>
              <h2 style={{ fontSize: '22px' }}>Add Photo Gallery</h2>
              <button onClick={() => setShowNewGalleryModal(false)} style={{ background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer' }}>✕</button>
            </div>

            <form onSubmit={handleCreateGallery}>
              <div className="form-group">
                <label className="form-label">Gallery Collection Name</label>
                <input
                  type="text"
                  className="form-control"
                  required
                  placeholder="e.g. Reception Portrait Edits"
                  value={newGalleryName}
                  onChange={(e) => setNewGalleryName(e.target.value)}
                />
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '10px' }}>
                Generate Gallery
              </button>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL: EDIT USER PROFILE & ACCESS --- */}
      {showPermissionsModal && permissionUser && (
        <div className="flex-center" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.85)', zIndex: 600, padding: '20px' }}>
          <div className="card" style={{ maxWidth: '480px', width: '100%', maxHeight: '90vh', overflowY: 'auto' }}>
            <div className="flex-between" style={{ marginBottom: '20px' }}>
              <h2 style={{ fontSize: '22px', fontWeight: 300 }}>Edit Profile & Access</h2>
              <button onClick={() => { setShowPermissionsModal(false); setPermissionUser(null); }} style={{ background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer' }}>✕</button>
            </div>

            <p style={{ fontSize: '13px', color: 'var(--text-secondary)', marginBottom: '20px' }}>
              Modify profile details, contact information, and security permissions for <strong>{permissionUser.name}</strong>.
            </p>

            <form onSubmit={async (e) => {
              e.preventDefault();
              try {
                await apiService.updateUser(permissionUser.userId, {
                  name: editName,
                  email: editEmail,
                  phone: editPhone,
                  role: editRole,
                  status: editStatus,
                  permissions: {
                    canProof: editCanProof,
                    canPay: editCanPay,
                    canViewDetails: editCanViewDetails
                  }
                });
                
                setShowPermissionsModal(false);
                setPermissionUser(null);
                loadData();
                alert(`User profile and access configuration updated for ${editName}.`);
              } catch (err) {
                console.error(err);
              }
            }}>
              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Full Name</label>
                <input
                  type="text"
                  className="form-control"
                  required
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Email Address</label>
                  <input
                    type="email"
                    className="form-control"
                    required
                    value={editEmail}
                    onChange={(e) => setEditEmail(e.target.value)}
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Phone Number</label>
                  <input
                    type="text"
                    className="form-control"
                    required
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value)}
                  />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Account Role</label>
                  <select
                    className="form-control"
                    value={editRole}
                    onChange={(e) => setEditRole(e.target.value as any)}
                  >
                    <option value="CLIENT">Client Portal</option>
                    <option value="READ_ONLY">ReadOnly Crew</option>
                    <option value="HOA_STAFF">HOA Staff (Tracker & Inventory)</option>
                    <option value="ADMIN">Studio Admin</option>
                    {user.role === 'SUPER_ADMIN' && <option value="SUPER_ADMIN">Super Administrator</option>}
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Account Status</label>
                  <select
                    className="form-control"
                    value={editStatus}
                    onChange={(e) => setEditStatus(e.target.value as any)}
                  >
                    <option value="ACTIVE">ACTIVE (Enabled)</option>
                    <option value="INACTIVE">INACTIVE (Suspended)</option>
                  </select>
                </div>
              </div>

              {editRole === 'CLIENT' && (
                <div style={{ marginTop: '20px', borderTop: '1px solid var(--border-color)', paddingTop: '15px' }}>
                  <h4 className="text-gold" style={{ fontSize: '16px', marginBottom: '12px' }}>Dynamic Client Portal Permissions</h4>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                    <label style={{ display: 'flex', alignItems: 'center', gap: '10px', fontSize: '14px', cursor: 'pointer' }}>
                      <input
                        type="checkbox"
                        checked={editCanProof}
                        onChange={(e) => setEditCanProof(e.target.checked)}
                        style={{ accentColor: 'var(--accent-gold)' }}
                      />
                      <span>Allow Photo Proof Selections (canProof)</span>
                    </label>

                    <label style={{ display: 'flex', alignItems: 'center', gap: '10px', fontSize: '14px', cursor: 'pointer' }}>
                      <input
                        type="checkbox"
                        checked={editCanPay}
                        onChange={(e) => setEditCanPay(e.target.checked)}
                        style={{ accentColor: 'var(--accent-gold)' }}
                      />
                      <span>Allow Invoice Payments (canPay)</span>
                    </label>

                    <label style={{ display: 'flex', alignItems: 'center', gap: '10px', fontSize: '14px', cursor: 'pointer' }}>
                      <input
                        type="checkbox"
                        checked={editCanViewDetails}
                        onChange={(e) => setEditCanViewDetails(e.target.checked)}
                        style={{ accentColor: 'var(--accent-gold)' }}
                      />
                      <span>Allow Project Details Viewing (canViewDetails)</span>
                    </label>
                  </div>
                </div>
              )}

              <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '25px' }}>
                Save Access Rules
              </button>
            </form>
          </div>
        </div>
      )}
      {/* --- MODAL: CREATE NEW GEAR ITEM --- */}
      {showNewGearModal && (
        <div className="flex-center" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.85)', zIndex: 600, padding: '20px' }}>
          <div className="card" style={{ maxWidth: '420px', width: '100%' }}>
            <div className="flex-between" style={{ marginBottom: '20px' }}>
              <h2 style={{ fontSize: '22px', fontWeight: 300 }}>Add Equipment Gear</h2>
              <button onClick={() => setShowNewGearModal(false)} style={{ background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer' }}>✕</button>
            </div>

            <form onSubmit={handleCreateGear}>
              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Equipment/Model Name</label>
                <input
                  type="text"
                  className="form-control"
                  required
                  placeholder="e.g. Sony A7 IV Body"
                  value={newGearName}
                  onChange={(e) => setNewGearName(e.target.value)}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Gear Category</label>
                  <select
                    className="form-control"
                    value={newGearCategory}
                    onChange={(e) => setNewGearCategory(e.target.value as any)}
                  >
                    <option value="CAMERA">Camera Body</option>
                    <option value="LENS">Prime/Zoom Lens</option>
                    <option value="DRONE">Drone Kit</option>
                    <option value="LIGHTING">Studio Lighting</option>
                    <option value="ACCESSORY">Accessory/Grip</option>
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Serial Identifier</label>
                  <input
                    type="text"
                    className="form-control"
                    required
                    placeholder="S/N: 12345678"
                    value={newGearSerial}
                    onChange={(e) => setNewGearSerial(e.target.value)}
                  />
                </div>
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '10px' }}>
                Register Equipment
              </button>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL: TEAM EMPLOYEE PROFILE FORM --- */}
      {showEmployeeFormModal && (
        <div className="flex-center" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.85)', zIndex: 600, padding: '20px' }}>
          <div className="card" style={{ maxWidth: '850px', width: '100%', display: 'flex', flexDirection: 'column' }}>
            <div className="flex-between" style={{ marginBottom: '20px' }}>
              <h2 style={{ fontSize: '24px', fontWeight: 300 }}>
                {isEditingEmployee ? 'Edit Employee Profile' : 'Add Employee Profile'}
              </h2>
              <button 
                onClick={() => {
                  setShowEmployeeFormModal(false);
                  resetEmployeeForm();
                }} 
                style={{ background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer' }}
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveEmployee} style={{ maxHeight: '75vh', overflowY: 'auto', paddingRight: '10px' }}>
              
              {/* Section 1: Personal Details */}
              <h3 style={{ fontSize: '16px', color: 'var(--accent-gold)', marginBottom: '15px', borderBottom: '1px solid var(--border-color)', paddingBottom: '5px' }}>
                1. Personal & Contact Details
              </h3>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Full Name</label>
                  <input
                    type="text"
                    className="form-control"
                    required
                    placeholder="e.g. Vikramaditya Sen"
                    value={empName}
                    onChange={(e) => setEmpName(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Corporate Email</label>
                  <input
                    type="email"
                    className="form-control"
                    required
                    placeholder="e.g. vikram@thestorybox.in"
                    value={empEmail}
                    onChange={(e) => setEmpEmail(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Contact Phone</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="e.g. +91 9876543210"
                    value={empPhone}
                    onChange={(e) => setEmpPhone(e.target.value)}
                  />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Designation / Role</label>
                  <input
                    type="text"
                    className="form-control"
                    required
                    placeholder="e.g. Lead Cinematographer"
                    value={empDesignation}
                    onChange={(e) => setEmpDesignation(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Department</label>
                  <select
                    className="form-control"
                    value={empDepartment}
                    onChange={(e) => setEmpDepartment(e.target.value)}
                  >
                    <option value="Production">Production</option>
                    <option value="Editing & Post">Editing & Post</option>
                    <option value="Sales & CRM">Sales & CRM</option>
                    <option value="Administration">Administration</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Date of Joining</label>
                  <input
                    type="date"
                    className="form-control"
                    value={empDateOfJoining}
                    onChange={(e) => setEmpDateOfJoining(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Blood Group</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="e.g. O+"
                    value={empBloodGroup}
                    onChange={(e) => setEmpBloodGroup(e.target.value)}
                  />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '15px', marginBottom: '20px' }}>
                <div className="form-group">
                  <label className="form-label">Personal Email</label>
                  <input
                    type="email"
                    className="form-control"
                    placeholder="e.g. vikram@gmail.com"
                    value={empPersonalEmail}
                    onChange={(e) => setEmpPersonalEmail(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Permanent Address</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Enter full address details"
                    value={empAddress}
                    onChange={(e) => setEmpAddress(e.target.value)}
                  />
                </div>
              </div>

              {/* Section 2: Financials & Govt IDs */}
              <h3 style={{ fontSize: '16px', color: 'var(--accent-gold)', marginBottom: '15px', borderBottom: '1px solid var(--border-color)', paddingBottom: '5px' }}>
                2. Salary & Identity Documentation
              </h3>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: '15px', marginBottom: '20px' }}>
                <div className="form-group">
                  <label className="form-label">Annual CTC Package (₹)</label>
                  <input
                    type="number"
                    className="form-control"
                    placeholder="CTC in INR"
                    value={empCtc}
                    onChange={(e) => setEmpCtc(Number(e.target.value))}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Monthly Basic Salary (₹)</label>
                  <input
                    type="number"
                    className="form-control"
                    placeholder="Monthly basic in INR"
                    value={empMonthlySalary}
                    onChange={(e) => setEmpMonthlySalary(Number(e.target.value))}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">PAN Card Number</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="e.g. ABCDE1234F"
                    value={empPanCard}
                    onChange={(e) => setEmpPanCard(e.target.value.toUpperCase())}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Aadhar Card Number</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="12-digit UID"
                    value={empAadharCard}
                    onChange={(e) => setEmpAadharCard(e.target.value)}
                  />
                </div>
              </div>

              {/* Section 3: Bank Details */}
              <h3 style={{ fontSize: '16px', color: 'var(--accent-gold)', marginBottom: '15px', borderBottom: '1px solid var(--border-color)', paddingBottom: '5px' }}>
                3. Corporate Bank Account details
              </h3>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr 1fr', gap: '10px', marginBottom: '20px' }}>
                <div className="form-group">
                  <label className="form-label">Bank Name</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="HDFC Bank"
                    value={empBankName}
                    onChange={(e) => setEmpBankName(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Account Holder</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Account Name"
                    value={empBankAccountName}
                    onChange={(e) => setEmpBankAccountName(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Account Number</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Account Number"
                    value={empBankAccountNumber}
                    onChange={(e) => setEmpBankAccountNumber(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">IFSC Code</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="HDFC0000001"
                    value={empBankIfscCode}
                    onChange={(e) => setEmpBankIfscCode(e.target.value.toUpperCase())}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Branch</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Branch name"
                    value={empBankBranch}
                    onChange={(e) => setEmpBankBranch(e.target.value)}
                  />
                </div>
              </div>

              {/* Section 4: Health Insurance */}
              <h3 style={{ fontSize: '16px', color: 'var(--accent-gold)', marginBottom: '15px', borderBottom: '1px solid var(--border-color)', paddingBottom: '5px' }}>
                4. Health Insurance Policy Details
              </h3>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr 1fr', gap: '10px', marginBottom: '20px' }}>
                <div className="form-group">
                  <label className="form-label">Policy Number</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Policy No."
                    value={empInsurancePolicyNumber}
                    onChange={(e) => setEmpInsurancePolicyNumber(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Provider Name</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Star Health"
                    value={empInsuranceProvider}
                    onChange={(e) => setEmpInsuranceProvider(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Sum Insured (₹)</label>
                  <input
                    type="number"
                    className="form-control"
                    placeholder="500000"
                    value={empInsuranceSumInsured}
                    onChange={(e) => setEmpInsuranceSumInsured(Number(e.target.value))}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">TPA Administrator</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Medi Assist"
                    value={empInsuranceTpaName}
                    onChange={(e) => setEmpInsuranceTpaName(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Expiry Date</label>
                  <input
                    type="date"
                    className="form-control"
                    value={empInsuranceExpiryDate}
                    onChange={(e) => setEmpInsuranceExpiryDate(e.target.value)}
                  />
                </div>
              </div>

              {/* Section 5: List Managers */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '30px', borderTop: '1px solid var(--border-color)', paddingTop: '20px', marginBottom: '20px' }}>
                
                {/* Emergency Contacts Manager */}
                <div>
                  <h4 style={{ fontSize: '15px', color: 'var(--accent-gold)', marginBottom: '12px' }}>Emergency Contacts List</h4>
                  <div style={{ display: 'flex', gap: '8px', marginBottom: '10px', flexWrap: 'wrap' }}>
                    <input type="text" placeholder="Name" className="form-control" style={{ flex: 1, height: '36px', fontSize: '12px', padding: '6px' }} value={newContactName} onChange={(e) => setNewContactName(e.target.value)} />
                    <input type="text" placeholder="Relation" className="form-control" style={{ flex: 1, height: '36px', fontSize: '12px', padding: '6px' }} value={newContactRelation} onChange={(e) => setNewContactRelation(e.target.value)} />
                    <input type="text" placeholder="Phone" className="form-control" style={{ flex: 1, height: '36px', fontSize: '12px', padding: '6px' }} value={newContactPhone} onChange={(e) => setNewContactPhone(e.target.value)} />
                    <button type="button" onClick={handleAddContact} className="btn btn-gold-outline" style={{ height: '36px', padding: '6px 12px', fontSize: '12px' }}>+ Add</button>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', maxHeight: '150px', overflowY: 'auto' }}>
                    {empEmergencyContacts.map((c: EmergencyContact, idx: number) => (
                      <div key={idx} className="flex-between" style={{ padding: '8px', border: '1px solid var(--border-color)', borderRadius: '4px', backgroundColor: 'var(--bg-secondary)', fontSize: '12px' }}>
                        <span><strong>{c.name}</strong> ({c.relationship}) &mdash; {c.phone}</span>
                        <button type="button" onClick={() => setEmpEmergencyContacts(empEmergencyContacts.filter((_, i) => i !== idx))} style={{ background: 'none', border: 'none', color: 'var(--danger)', cursor: 'pointer' }}>✕</button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Onsite Travel Log Manager */}
                <div>
                  <h4 style={{ fontSize: '15px', color: 'var(--accent-gold)', marginBottom: '12px' }}>Onsite Travel Logs</h4>
                  <div style={{ display: 'flex', gap: '8px', marginBottom: '10px', flexWrap: 'wrap' }}>
                    <input type="text" placeholder="Country" className="form-control" style={{ width: '80px', height: '36px', fontSize: '12px', padding: '6px' }} value={newTravelCountry} onChange={(e) => setNewTravelCountry(e.target.value)} />
                    <input type="text" placeholder="Purpose" className="form-control" style={{ flex: 1, height: '36px', fontSize: '12px', padding: '6px' }} value={newTravelPurpose} onChange={(e) => setNewTravelPurpose(e.target.value)} />
                    <input type="date" className="form-control" style={{ width: '105px', height: '36px', fontSize: '12px', padding: '6px' }} value={newTravelStartDate} onChange={(e) => setNewTravelStartDate(e.target.value)} />
                    <input type="date" className="form-control" style={{ width: '105px', height: '36px', fontSize: '12px', padding: '6px' }} value={newTravelEndDate} onChange={(e) => setNewTravelEndDate(e.target.value)} />
                    <button type="button" onClick={handleAddTravel} className="btn btn-gold-outline" style={{ height: '36px', padding: '6px 12px', fontSize: '12px' }}>+ Add</button>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', maxHeight: '150px', overflowY: 'auto' }}>
                    {empTravelHistory.map((t: OnsiteTravel, idx: number) => (
                      <div key={idx} className="flex-between" style={{ padding: '8px', border: '1px solid var(--border-color)', borderRadius: '4px', backgroundColor: 'var(--bg-secondary)', fontSize: '12px' }}>
                        <span><strong>{t.country}</strong> &mdash; {t.purpose} ({t.startDate} to {t.endDate || 'N/A'})</span>
                        <button type="button" onClick={() => setEmpTravelHistory(empTravelHistory.filter((_, i) => i !== idx))} style={{ background: 'none', border: 'none', color: 'var(--danger)', cursor: 'pointer' }}>✕</button>
                      </div>
                    ))}
                  </div>
                </div>

              </div>

              {/* Employment History Log Manager */}
              <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '20px', marginBottom: '20px' }}>
                <h4 style={{ fontSize: '15px', color: 'var(--accent-gold)', marginBottom: '12px' }}>Employment job history</h4>
                <div style={{ display: 'flex', gap: '8px', marginBottom: '10px', flexWrap: 'wrap' }}>
                  <input type="text" placeholder="Past Company" className="form-control" style={{ flex: 1.5, height: '36px', fontSize: '12px', padding: '6px' }} value={newExpCompany} onChange={(e) => setNewExpCompany(e.target.value)} />
                  <input type="text" placeholder="Designation" className="form-control" style={{ flex: 1.5, height: '36px', fontSize: '12px', padding: '6px' }} value={newExpDesignation} onChange={(e) => setNewExpDesignation(e.target.value)} />
                  <input type="date" className="form-control" style={{ width: '115px', height: '36px', fontSize: '12px', padding: '6px' }} value={newExpStartDate} onChange={(e) => setNewExpStartDate(e.target.value)} />
                  <input type="date" className="form-control" style={{ width: '115px', height: '36px', fontSize: '12px', padding: '6px' }} value={newExpEndDate} onChange={(e) => setNewExpEndDate(e.target.value)} />
                  <input type="text" placeholder="Reason for leaving" className="form-control" style={{ flex: 2, height: '36px', fontSize: '12px', padding: '6px' }} value={newExpReason} onChange={(e) => setNewExpReason(e.target.value)} />
                  <button type="button" onClick={handleAddExperience} className="btn btn-gold-outline" style={{ height: '36px', padding: '6px 12px', fontSize: '12px' }}>+ Add Job</button>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', maxHeight: '150px', overflowY: 'auto' }}>
                  {empEmploymentHistory.map((h: EmploymentHistory, idx: number) => (
                    <div key={idx} className="flex-between" style={{ padding: '8px', border: '1px solid var(--border-color)', borderRadius: '4px', backgroundColor: 'var(--bg-secondary)', fontSize: '12px' }}>
                      <span><strong>{h.company}</strong> as <em>{h.designation}</em> ({h.startDate} to {h.endDate || 'Present'}) &mdash; Reason: {h.reasonForLeaving || 'N/A'}</span>
                      <button type="button" onClick={() => setEmpEmploymentHistory(empEmploymentHistory.filter((_, i) => i !== idx))} style={{ background: 'none', border: 'none', color: 'var(--danger)', cursor: 'pointer' }}>✕</button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Status and Form Submit Actions */}
              <div style={{ display: 'flex', gap: '15px', borderTop: '1px solid var(--border-color)', paddingTop: '20px', alignItems: 'center', justifyContent: 'space-between' }}>
                <div className="form-group" style={{ flexDirection: 'row', gap: '10px', alignItems: 'center', margin: 0 }}>
                  <label className="form-label" style={{ margin: 0 }}>Employee Profile Status</label>
                  <select className="form-control" style={{ padding: '4px 10px', fontSize: '12px', width: 'auto', height: '30px' }} value={empStatus} onChange={(e) => setEmpStatus(e.target.value as any)}>
                    <option value="ACTIVE">Active</option>
                    <option value="INACTIVE">Inactive</option>
                  </select>
                </div>

                <div style={{ display: 'flex', gap: '10px' }}>
                  <button 
                    type="button" 
                    onClick={() => {
                      setShowEmployeeFormModal(false);
                      resetEmployeeForm();
                    }}
                    className="btn btn-secondary"
                  >
                    Cancel
                  </button>
                  <button type="submit" className="btn btn-primary">
                    {isEditingEmployee ? 'Save Profile Changes' : 'Create Employee Profile'}
                  </button>
                </div>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* --- MODAL: CREATE SOFTWARE & GALLERY SUBSCRIPTION --- */}
      {showNewSubscriptionModal && (
        <div className="flex-center" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.85)', zIndex: 600, padding: '20px' }}>
          <div className="card" style={{ maxWidth: '450px', width: '100%' }}>
            <div className="flex-between" style={{ marginBottom: '20px' }}>
              <h2 style={{ fontSize: '22px', fontWeight: 300 }}>Register Subscription</h2>
              <button onClick={() => setShowNewSubscriptionModal(false)} style={{ background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer' }}>✕</button>
            </div>

            <form onSubmit={handleCreateSubscription}>
              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Subscription / Service Plan Name</label>
                <input
                  type="text"
                  className="form-control"
                  required
                  placeholder="e.g. Adobe Creative Cloud Suite"
                  value={newSubPlanName}
                  onChange={(e) => setNewSubPlanName(e.target.value)}
                />
              </div>

              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Client Account / Service Vendor Name</label>
                <input
                  type="text"
                  className="form-control"
                  required
                  placeholder="e.g. Adobe Inc. (Software) or Rohan Sharma (Client)"
                  value={newSubClientName}
                  onChange={(e) => setNewSubClientName(e.target.value)}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Pricing Rate (INR)</label>
                  <input
                    type="number"
                    className="form-control"
                    required
                    min={1}
                    value={newSubPrice}
                    onChange={(e) => setNewSubPrice(Number(e.target.value))}
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Billing Cycle</label>
                  <select
                    className="form-control"
                    value={newSubBillingCycle}
                    onChange={(e) => setNewSubBillingCycle(e.target.value as any)}
                  >
                    <option value="MONTHLY">Monthly Billing</option>
                    <option value="ANNUAL">Annual Billing</option>
                  </select>
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Billing Cycle Start Date</label>
                  <input
                    type="date"
                    className="form-control"
                    required
                    value={newSubStartDate}
                    onChange={(e) => setNewSubStartDate(e.target.value)}
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Subscription Status</label>
                  <select
                    className="form-control"
                    value={newSubStatus}
                    onChange={(e) => setNewSubStatus(e.target.value as any)}
                  >
                    <option value="ACTIVE">ACTIVE (Subscribed)</option>
                    <option value="PENDING">PENDING (Invoices Awaiting)</option>
                    <option value="EXPIRED">EXPIRED (Inactive)</option>
                  </select>
                </div>
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '15px' }}>
                Save Subscription
              </button>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL: CREATE INVOICE --- */}
      {showNewInvoiceModal && (
        <div className="flex-center" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.85)', zIndex: 600, padding: '20px' }}>
          <div className="card" style={{ maxWidth: '450px', width: '100%' }}>
            <div className="flex-between" style={{ marginBottom: '20px' }}>
              <h2 style={{ fontSize: '22px', fontWeight: 300 }}>Generate Invoice</h2>
              <button onClick={() => setShowNewInvoiceModal(false)} style={{ background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer' }}>✕</button>
            </div>

            <form onSubmit={handleCreateInvoice}>
              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Associate Project</label>
                <select
                  className="form-control"
                  required
                  value={newInvoiceProjectId}
                  onChange={(e) => setNewInvoiceProjectId(e.target.value)}
                >
                  <option value="">-- Select Active Project --</option>
                  {projects.map(p => (
                    <option key={p.projectId} value={p.projectId}>
                      {p.title} ({p.type})
                    </option>
                  ))}
                </select>
              </div>

              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Invoice Description</label>
                <input
                  type="text"
                  className="form-control"
                  required
                  placeholder="e.g. Milestone Shoot Payment"
                  value={newInvoiceDescription}
                  onChange={(e) => setNewInvoiceDescription(e.target.value)}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Invoice Amount (INR)</label>
                  <input
                    type="number"
                    className="form-control"
                    required
                    min={1}
                    value={newInvoiceAmount}
                    onChange={(e) => setNewInvoiceAmount(Number(e.target.value))}
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Payment Due Date</label>
                  <input
                    type="date"
                    className="form-control"
                    required
                    value={newInvoiceDueDate}
                    onChange={(e) => setNewInvoiceDueDate(e.target.value)}
                  />
                </div>
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '15px' }}>
                Generate Invoice
              </button>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL: CREATE LEAD --- */}
      {showNewLeadModal && (
        <div className="flex-center" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.85)', zIndex: 600, padding: '20px' }}>
          <div className="card" style={{ maxWidth: '450px', width: '100%' }}>
            <div className="flex-between" style={{ marginBottom: '20px' }}>
              <h2 style={{ fontSize: '22px', fontWeight: 300 }}>Register Photography Lead</h2>
              <button onClick={() => setShowNewLeadModal(false)} style={{ background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer' }}>✕</button>
            </div>

            <form onSubmit={handleCreateLead}>
              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Client Full Name</label>
                <input
                  type="text"
                  className="form-control"
                  required
                  placeholder="e.g. Priya Nair"
                  value={newLeadName}
                  onChange={(e) => setNewLeadName(e.target.value)}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Email Address</label>
                  <input
                    type="email"
                    className="form-control"
                    required
                    placeholder="client@gmail.com"
                    value={newLeadEmail}
                    onChange={(e) => setNewLeadEmail(e.target.value)}
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Contact Phone</label>
                  <input
                    type="text"
                    className="form-control"
                    required
                    placeholder="+91 9998887776"
                    value={newLeadPhone}
                    onChange={(e) => setNewLeadPhone(e.target.value)}
                  />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Event Type</label>
                  <input
                    type="text"
                    className="form-control"
                    required
                    placeholder="e.g. Pre-Wedding Shoot"
                    value={newLeadEventType}
                    onChange={(e) => setNewLeadEventType(e.target.value)}
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Target Event Date</label>
                  <input
                    type="date"
                    className="form-control"
                    required
                    value={newLeadEventDate}
                    onChange={(e) => setNewLeadEventDate(e.target.value)}
                  />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Estimated Budget (INR)</label>
                  <input
                    type="number"
                    className="form-control"
                    required
                    min={1}
                    value={newLeadBudget}
                    onChange={(e) => setNewLeadBudget(Number(e.target.value))}
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Funnel Target Status</label>
                  <select
                    className="form-control"
                    value={newLeadStatus}
                    onChange={(e) => setNewLeadStatus(e.target.value as any)}
                  >
                    <option value="LEAD">Qualified Sales Lead</option>
                    <option value="ENQUIRY">Inbound Raw Enquiry</option>
                  </select>
                </div>
              </div>

              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Brief Description & Notes</label>
                <textarea
                  className="form-control"
                  rows={3}
                  placeholder="Details, location preferences, reference styling..."
                  value={newLeadNotes}
                  onChange={(e) => setNewLeadNotes(e.target.value)}
                  style={{ height: '70px', resize: 'none' }}
                />
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '10px' }}>
                Register Lead
              </button>
            </form>
          </div>
        </div>
      )}
      {/* --- MODAL: EDIT GEAR ITEM --- */}
      {showEditGearModal && selectedGear && (
        <div className="flex-center" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.85)', zIndex: 600, padding: '20px' }}>
          <div className="card" style={{ maxWidth: '420px', width: '100%' }}>
            <div className="flex-between" style={{ marginBottom: '20px' }}>
              <h2 style={{ fontSize: '22px', fontWeight: 300 }}>Edit Equipment Gear</h2>
              <button onClick={() => { setShowEditGearModal(false); setSelectedGear(null); }} style={{ background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer' }}>✕</button>
            </div>

            <form onSubmit={handleEditGear}>
              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Equipment/Model Name</label>
                <input
                  type="text"
                  className="form-control"
                  required
                  value={editGearName}
                  onChange={(e) => setEditGearName(e.target.value)}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Gear Category</label>
                  <select
                    className="form-control"
                    value={editGearCategory}
                    onChange={(e) => setEditGearCategory(e.target.value as any)}
                  >
                    <option value="CAMERA">Camera Body</option>
                    <option value="LENS">Prime/Zoom Lens</option>
                    <option value="DRONE">Drone Kit</option>
                    <option value="LIGHTING">Studio Lighting</option>
                    <option value="ACCESSORY">Accessory/Grip</option>
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Serial Identifier</label>
                  <input
                    type="text"
                    className="form-control"
                    required
                    value={editGearSerial}
                    onChange={(e) => setEditGearSerial(e.target.value)}
                  />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Allocation Status</label>
                  <select
                    className="form-control"
                    value={editGearStatus}
                    onChange={(e) => setEditGearStatus(e.target.value as any)}
                  >
                    <option value="IN_STUDIO">Check In Studio</option>
                    <option value="ON_LOCATION">Check Out (Shoot)</option>
                    <option value="MAINTENANCE">Send to Repair</option>
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Assigned Crew</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Unassigned"
                    value={editGearAssignedTo}
                    onChange={(e) => setEditGearAssignedTo(e.target.value)}
                  />
                </div>
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '10px' }}>
                Save Equipment Changes
              </button>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL: EDIT SOFTWARE & GALLERY SUBSCRIPTION --- */}
      {showEditSubscriptionModal && selectedSubscription && (
        <div className="flex-center" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.85)', zIndex: 600, padding: '20px' }}>
          <div className="card" style={{ maxWidth: '450px', width: '100%' }}>
            <div className="flex-between" style={{ marginBottom: '20px' }}>
              <h2 style={{ fontSize: '22px', fontWeight: 300 }}>Edit Subscription</h2>
              <button onClick={() => { setShowEditSubscriptionModal(false); setSelectedSubscription(null); }} style={{ background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer' }}>✕</button>
            </div>

            <form onSubmit={handleEditSubscription}>
              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Subscription / Service Plan Name</label>
                <input
                  type="text"
                  className="form-control"
                  required
                  value={editSubPlanName}
                  onChange={(e) => setEditSubPlanName(e.target.value)}
                />
              </div>

              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Client Account / Service Vendor Name</label>
                <input
                  type="text"
                  className="form-control"
                  required
                  value={editSubClientName}
                  onChange={(e) => setEditSubClientName(e.target.value)}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Pricing Rate (INR)</label>
                  <input
                    type="number"
                    className="form-control"
                    required
                    min={1}
                    value={editSubPrice}
                    onChange={(e) => setEditSubPrice(Number(e.target.value))}
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Billing Cycle</label>
                  <select
                    className="form-control"
                    value={editSubBillingCycle}
                    onChange={(e) => setEditSubBillingCycle(e.target.value as any)}
                  >
                    <option value="MONTHLY">Monthly Billing</option>
                    <option value="ANNUAL">Annual Billing</option>
                  </select>
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Billing Cycle Start Date</label>
                  <input
                    type="date"
                    className="form-control"
                    required
                    value={editSubStartDate}
                    onChange={(e) => setEditSubStartDate(e.target.value)}
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Subscription Status</label>
                  <select
                    className="form-control"
                    value={editSubStatus}
                    onChange={(e) => setEditSubStatus(e.target.value as any)}
                  >
                    <option value="ACTIVE">ACTIVE (Subscribed)</option>
                    <option value="PENDING">PENDING (Invoices Awaiting)</option>
                    <option value="EXPIRED">EXPIRED (Inactive)</option>
                  </select>
                </div>
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '15px' }}>
                Save Subscription Changes
              </button>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL: EDIT LEAD & CONVERSION --- */}
      {showEditLeadModal && selectedLead && (
        <div className="flex-center" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.85)', zIndex: 600, padding: '20px' }}>
          <div className="card" style={{ maxWidth: '450px', width: '100%' }}>
            <div className="flex-between" style={{ marginBottom: '20px' }}>
              <h2 style={{ fontSize: '22px', fontWeight: 300 }}>Edit Lead/Conversion Record</h2>
              <button onClick={() => { setShowEditLeadModal(false); setSelectedLead(null); }} style={{ background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer' }}>✕</button>
            </div>

            <form onSubmit={handleEditLead}>
              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Client Name</label>
                <input
                  type="text"
                  className="form-control"
                  required
                  value={editLeadClientName}
                  onChange={(e) => setEditLeadClientName(e.target.value)}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Client Email</label>
                  <input
                    type="email"
                    className="form-control"
                    required
                    value={editLeadClientEmail}
                    onChange={(e) => setEditLeadClientEmail(e.target.value)}
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Client Phone</label>
                  <input
                    type="text"
                    className="form-control"
                    required
                    value={editLeadClientPhone}
                    onChange={(e) => setEditLeadClientPhone(e.target.value)}
                  />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Event Type</label>
                  <input
                    type="text"
                    className="form-control"
                    required
                    value={editLeadEventType}
                    onChange={(e) => setEditLeadEventType(e.target.value)}
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Target Shoot Date</label>
                  <input
                    type="date"
                    className="form-control"
                    required
                    value={editLeadEventDate}
                    onChange={(e) => setEditLeadEventDate(e.target.value)}
                  />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Estimated Budget (INR)</label>
                  <input
                    type="number"
                    className="form-control"
                    required
                    value={editLeadBudget}
                    onChange={(e) => setEditLeadBudget(Number(e.target.value))}
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Sales Stage</label>
                  <select
                    className="form-control"
                    value={editLeadStatus}
                    onChange={(e) => setEditLeadStatus(e.target.value as any)}
                  >
                    <option value="ENQUIRY">ENQUIRY (Inbound Captures)</option>
                    <option value="LEAD">LEAD (Qualified Pipelines)</option>
                    <option value="CONVERTED">CONVERTED (Won Shoot packages)</option>
                    <option value="LOST">LOST (Closed Opportunities)</option>
                  </select>
                </div>
              </div>

              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Notes & Budget specifications</label>
                <textarea
                  className="form-control"
                  style={{ height: '70px', resize: 'vertical' }}
                  value={editLeadNotes}
                  onChange={(e) => setEditLeadNotes(e.target.value)}
                />
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '10px' }}>
                Save Pipeline Changes
              </button>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL: CREATE NEW USER --- */}
      {showCreateUserModal && (
        <div className="flex-center" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.85)', zIndex: 600, padding: '20px' }}>
          <div className="card" style={{ maxWidth: '480px', width: '100%' }}>
            <div className="flex-between" style={{ marginBottom: '20px' }}>
              <h2 style={{ fontSize: '24px', fontWeight: 300 }}>
                {newUserType === 'TEAM' ? 'Add Creative Crew Member' : 'Add Client Account'}
              </h2>
              <button onClick={() => setShowCreateUserModal(false)} style={{ background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer', color: 'var(--text-muted)' }}>✕</button>
            </div>

            <form onSubmit={handleCreateUser}>
              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Full Name</label>
                <input
                  type="text"
                  className="form-control"
                  required
                  placeholder="e.g. Karan Soma"
                  value={newUserName}
                  onChange={(e) => setNewUserName(e.target.value)}
                />
              </div>

              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Email Address</label>
                <input
                  type="email"
                  className="form-control"
                  required
                  placeholder="e.g. karan@thestorybox.in"
                  value={newUserEmail}
                  onChange={(e) => setNewUserEmail(e.target.value)}
                />
              </div>

              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Contact Phone</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="e.g. +91 9999999999"
                  value={newUserPhone}
                  onChange={(e) => setNewUserPhone(e.target.value)}
                />
              </div>

              {newUserType === 'TEAM' && (
                <div className="form-group" style={{ marginBottom: '15px' }}>
                  <label className="form-label">System Role Access</label>
                  <select
                    className="form-control"
                    value={newUserRole}
                    onChange={(e) => setNewUserRole(e.target.value as any)}
                  >
                    <option value="ADMIN">ADMIN (Full Shoot Management)</option>
                    <option value="SUPER_ADMIN">SUPER_ADMIN (Billing, Assets & Users)</option>
                    <option value="READ_ONLY">READ_ONLY (Audit and Crew Viewer)</option>
                    <option value="HOA_STAFF">HOA_STAFF (Tracker & Inventory)</option>
                  </select>
                </div>
              )}

              <div className="form-group" style={{ marginBottom: '20px' }}>
                <label className="form-label">Account Password</label>
                <input
                  type="password"
                  className="form-control"
                  required
                  placeholder="At least 8 characters with numbers & symbols"
                  value={newUserPassword}
                  onChange={(e) => setNewUserPassword(e.target.value)}
                />
                <span className="text-muted" style={{ fontSize: '11px', marginTop: '4px' }}>
                  Set a secure preset credential that the user will use to log in immediately.
                </span>
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%' }}>
                Create Account & Sync Credentials
              </button>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL: CREATE NEW PROPOSAL --- */}
      {showNewProposalModal && (
        <div className="flex-center" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.85)', zIndex: 600, padding: '20px' }}>
          <div className="card" style={{ maxWidth: '600px', width: '100%', maxHeight: '90vh', overflowY: 'auto' }}>
            <div className="flex-between" style={{ marginBottom: '20px' }}>
              <h2 style={{ fontSize: '24px', fontWeight: 300 }}>Draft Custom Celebration Proposal</h2>
              <button onClick={() => setShowNewProposalModal(false)} style={{ background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer' }}>✕</button>
            </div>

            <form onSubmit={async (e) => {
              e.preventDefault();
              await apiService.createProposal(propClientName, propClientEmail, propClientPhone, propTitle, propDescription, propBudget, propDeliverables.split('\n'), propTerms);
              setShowNewProposalModal(false);
              loadData();
              alert("Proposal created successfully.");
            }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Client Name</label>
                  <input type="text" className="form-control" required value={propClientName} onChange={(e) => setPropClientName(e.target.value)} />
                </div>
                <div className="form-group">
                  <label className="form-label">Client Email</label>
                  <input type="email" className="form-control" required value={propClientEmail} onChange={(e) => setPropClientEmail(e.target.value)} />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Client Phone</label>
                  <input type="text" className="form-control" value={propClientPhone} onChange={(e) => setPropClientPhone(e.target.value)} />
                </div>
                <div className="form-group">
                  <label className="form-label">Quick Package Template</label>
                  <select 
                    className="form-control"
                    onChange={(e) => {
                      const val = e.target.value;
                      if (val === 'essence') {
                        setPropTitle("Essence Photography Package");
                        setPropBudget(360000);
                        setPropDescription("For couples who want refined coverage of the moments that matter most — chosen with care, captured without noise.");
                        setPropDeliverables("1 Lead Photographer\n1 Lead Cinematographer\nFull team (2 + 2) exclusively at your Wedding\n6–8 hours of coverage per event\n500 beautifully edited photographs + all raw images\n5-minute cinematic highlight film\n1-minute teaser film for social media\nDrone coverage on wedding day");
                      } else if (val === 'heritage') {
                        setPropTitle("Heritage Photography Package");
                        setPropBudget(540000);
                        setPropDescription("For couples who want every chapter captured—from the morning of haldi to the last dance of the reception, with our complete team and signature touches included.");
                        setPropDeliverables("1 Lead Photographer + 1 Candid Photographer\n1 Lead Cinematographer + 1 Traditional Videographer\nFull team (2 + 2) at Haldi, Sangeet, Wedding & Reception\n6–8 hours of coverage per event\n900 edited photographs + all raw images\n6-9 minute cinematic highlight film\n1-minute teaser for instagram\nDrone coverage across all major events\nOne premium album per family (2 albums total)");
                      } else if (val === 'legacy') {
                        setPropTitle("Legacy Signature Package");
                        setPropBudget(800000);
                        setPropDescription("The work on personally—for couples whose weddings deserve a body of work designed entirely around them.");
                        setPropDeliverables("Karan Soma personally leads photography across all key events\nFull creative team (3 + 3 minimum), scaled to your wedding\nCustom coverage hours — no per-event cap\n1500+ edited photographs + complete raw archive\n12-minute cinematic feature film\n90-second teaser + save-the-date reel + pre-wedding film\n2 premium hardcover albums + parents' books");
                      }
                    }}
                  >
                    <option value="">-- Select Package --</option>
                    <option value="essence">Essence Package (₹3.6L)</option>
                    <option value="heritage">Heritage Package (₹5.4L)</option>
                    <option value="legacy">Legacy Package (₹8.0L)</option>
                  </select>
                </div>
              </div>

              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Proposal Header Title</label>
                <input type="text" className="form-control" required value={propTitle} onChange={(e) => setPropTitle(e.target.value)} />
              </div>

              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Proposal Description & Opening</label>
                <textarea className="form-control" style={{ height: '60px', resize: 'vertical' }} value={propDescription} onChange={(e) => setPropDescription(e.target.value)} />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Budget Package Price (₹)</label>
                  <input type="number" disabled={user.role !== 'SUPER_ADMIN'} className="form-control" required value={propBudget} onChange={(e) => setPropBudget(Number(e.target.value))} />
                </div>
              </div>

              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">What You'll Receive (Inclusions - One item per line)</label>
                <textarea className="form-control" style={{ height: '100px', resize: 'vertical' }} required value={propDeliverables} onChange={(e) => setPropDeliverables(e.target.value)} />
              </div>

              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Terms & Conditions</label>
                <textarea className="form-control" style={{ height: '60px', resize: 'vertical' }} value={propTerms} onChange={(e) => setPropTerms(e.target.value)} />
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '10px' }}>
                Create Proposal & Save v1
              </button>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL: EDIT PROPOSAL / DRAFT NEW VERSION --- */}
      {showEditProposalModal && selectedProposal && (
        <div className="flex-center" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.85)', zIndex: 600, padding: '20px' }}>
          <div className="card" style={{ maxWidth: '600px', width: '100%', maxHeight: '90vh', overflowY: 'auto' }}>
            <div className="flex-between" style={{ marginBottom: '20px' }}>
              <h2 style={{ fontSize: '24px', fontWeight: 300 }}>Draft New Revision Version (v{selectedProposal.currentVersion + 1})</h2>
              <button onClick={() => setShowEditProposalModal(false)} style={{ background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer' }}>✕</button>
            </div>

            <form onSubmit={async (e) => {
              e.preventDefault();
              await apiService.updateProposal(selectedProposal.proposalId, {
                title: propTitle,
                description: propDescription,
                budget: propBudget,
                deliverables: propDeliverables.split('\n'),
                terms: propTerms
              });
              setShowEditProposalModal(false);
              loadData();
              alert(`Revision version v${selectedProposal.currentVersion + 1} saved successfully!`);
            }}>
              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Proposal Header Title</label>
                <input type="text" className="form-control" required value={propTitle} onChange={(e) => setPropTitle(e.target.value)} />
              </div>

              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Proposal Description & Opening</label>
                <textarea className="form-control" style={{ height: '60px', resize: 'vertical' }} value={propDescription} onChange={(e) => setPropDescription(e.target.value)} />
              </div>

              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Budget Package Price (₹)</label>
                <input type="number" disabled={user.role !== 'SUPER_ADMIN'} className="form-control" required value={propBudget} onChange={(e) => setPropBudget(Number(e.target.value))} />
              </div>

              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">What You'll Receive (Inclusions - One item per line)</label>
                <textarea className="form-control" style={{ height: '100px', resize: 'vertical' }} required value={propDeliverables} onChange={(e) => setPropDeliverables(e.target.value)} />
              </div>

              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Terms & Conditions</label>
                <textarea className="form-control" style={{ height: '60px', resize: 'vertical' }} value={propTerms} onChange={(e) => setPropTerms(e.target.value)} />
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '10px' }}>
                Save Version v{selectedProposal.currentVersion + 1}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL: CREATE NEW HOA VENDOR --- */}
      {showNewVendorModal && (
        <div className="flex-center" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.85)', zIndex: 600, padding: '20px' }}>
          <div className="card" style={{ maxWidth: '520px', width: '100%', maxHeight: '90vh', overflowY: 'auto' }}>
            <div className="flex-between" style={{ marginBottom: '20px' }}>
              <h2 style={{ fontSize: '22px', fontWeight: 300 }}>Add HOA Vendor</h2>
              <button onClick={() => setShowNewVendorModal(false)} style={{ background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer' }}>✕</button>
            </div>

            <form onSubmit={handleCreateVendor}>
              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Vendor Name</label>
                <input type="text" className="form-control" required placeholder="e.g. Guangdong Gems Ltd" value={newVendorName} onChange={(e) => setNewVendorName(e.target.value)} />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Category</label>
                  <select className="form-control" value={newVendorCategory} onChange={(e) => setNewVendorCategory(e.target.value)}>
                    <option value="Manufacturer">Manufacturer</option>
                    <option value="Artisan / Smith">Artisan / Smith</option>
                    <option value="Wholesaler">Wholesaler</option>
                    <option value="Importer">Importer</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Rating Score (1-5)</label>
                  <input type="number" min="1" max="5" className="form-control" value={newVendorScore} onChange={(e) => setNewVendorScore(Number(e.target.value))} />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Location</label>
                  <select className="form-control" value={newVendorLocation} onChange={(e) => setNewVendorLocation(e.target.value)}>
                    <option value="Chennai">Chennai</option>
                    <option value="China">China</option>
                    <option value="Other">Other...</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Shop Image</label>
                  <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                    <input 
                      type="file" 
                      accept="image/*" 
                      style={{ display: 'none' }} 
                      id="new-vendor-image-file" 
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          setIsVendorUploading(true);
                          try {
                            const key = await uploadFileToS3(file);
                            setNewVendorShopImage(key);
                            alert("Image uploaded successfully.");
                          } catch (err: any) {
                            alert(err.message || "Failed to upload file");
                          } finally {
                            setIsVendorUploading(false);
                          }
                        }
                      }}
                    />
                    <label 
                      htmlFor="new-vendor-image-file" 
                      className="btn btn-secondary" 
                      style={{ padding: '8px 12px', fontSize: '12px', cursor: 'pointer', margin: 0, whiteSpace: 'nowrap' }}
                    >
                      {isVendorUploading ? "Uploading..." : "📁 Upload Image"}
                    </label>
                    
                    {newVendorShopImage && (
                      <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                        <span style={{ fontSize: '11px', color: 'var(--success)' }}>✓ Uploaded</span>
                        <button 
                          type="button" 
                          onClick={() => setNewVendorShopImage('')} 
                          style={{ background: 'none', border: 'none', color: 'var(--danger)', cursor: 'pointer', fontSize: '12px' }}
                        >
                          Remove
                        </button>
                      </div>
                    )}
                  </div>
                  
                  <input 
                    type="text" 
                    className="form-control" 
                    style={{ marginTop: '8px', fontSize: '11px', padding: '4px 8px' }}
                    placeholder="Or paste external Image URL..." 
                    value={newVendorShopImage.startsWith('hoa/') ? 'S3 Uploaded File' : newVendorShopImage} 
                    onChange={(e) => {
                      if (!e.target.value.includes('S3 Uploaded File')) {
                        setNewVendorShopImage(e.target.value);
                      }
                    }} 
                  />
                </div>
              </div>

              {newVendorLocation === 'Other' && (
                <div className="form-group" style={{ marginBottom: '15px' }}>
                  <label className="form-label">Custom Location Name</label>
                  <input type="text" className="form-control" required placeholder="e.g. Mumbai, India" value={newVendorCustomLocation} onChange={(e) => setNewVendorCustomLocation(e.target.value)} />
                </div>
              )}

              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Supplied Items (Comma separated)</label>
                <input type="text" className="form-control" placeholder="e.g. Necklaces, Rings, Earrings" value={newVendorSuppliedItems} onChange={(e) => setNewVendorSuppliedItems(e.target.value)} />
              </div>

              <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '15px', marginTop: '15px' }}>
                <h4 style={{ fontSize: '14px', fontWeight: 500, marginBottom: '10px', color: 'var(--text-gold)' }}>Contact Person Details</h4>
                
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                  <div className="form-group">
                    <label className="form-label">Contact Name</label>
                    <input type="text" className="form-control" placeholder="e.g. Zhang Wei" value={newVendorContact} onChange={(e) => setNewVendorContact(e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Phone Number</label>
                    <input type="text" className="form-control" placeholder="e.g. +86 139..." value={newVendorPhone} onChange={(e) => setNewVendorPhone(e.target.value)} />
                  </div>
                </div>

                <div className="form-group" style={{ marginBottom: '15px' }}>
                  <label className="form-label">Email Address</label>
                  <input type="email" className="form-control" placeholder="e.g. contact@guangdonggems.com" value={newVendorEmail} onChange={(e) => setNewVendorEmail(e.target.value)} />
                </div>

                <div className="form-group" style={{ marginBottom: '15px' }}>
                  <label className="form-label">Shop/Office Address</label>
                  <textarea className="form-control" style={{ height: '50px' }} placeholder="Factory/Office address details" value={newVendorAddress} onChange={(e) => setNewVendorAddress(e.target.value)} />
                </div>
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '10px' }}>
                Save Vendor
              </button>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL: EDIT HOA VENDOR --- */}
      {showEditVendorModal && selectedVendor && (
        <div className="flex-center" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.85)', zIndex: 600, padding: '20px' }}>
          <div className="card" style={{ maxWidth: '520px', width: '100%', maxHeight: '90vh', overflowY: 'auto' }}>
            <div className="flex-between" style={{ marginBottom: '20px' }}>
              <h2 style={{ fontSize: '22px', fontWeight: 300 }}>Edit HOA Vendor</h2>
              <button onClick={() => setShowEditVendorModal(false)} style={{ background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer' }}>✕</button>
            </div>

            <form onSubmit={handleEditVendor}>
              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Vendor Name</label>
                <input type="text" className="form-control" required value={editVendorName} onChange={(e) => setEditVendorName(e.target.value)} />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Category</label>
                  <select className="form-control" value={editVendorCategory} onChange={(e) => setEditVendorCategory(e.target.value)}>
                    <option value="Manufacturer">Manufacturer</option>
                    <option value="Artisan / Smith">Artisan / Smith</option>
                    <option value="Wholesaler">Wholesaler</option>
                    <option value="Importer">Importer</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Rating Score (1-5)</label>
                  <input type="number" min="1" max="5" className="form-control" value={editVendorScore} onChange={(e) => setEditVendorScore(Number(e.target.value))} />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Location</label>
                  <select className="form-control" value={editVendorLocation} onChange={(e) => setEditVendorLocation(e.target.value)}>
                    <option value="Chennai">Chennai</option>
                    <option value="China">China</option>
                    <option value="Other">Other...</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Shop Image</label>
                  <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                    <input 
                      type="file" 
                      accept="image/*" 
                      style={{ display: 'none' }} 
                      id="edit-vendor-image-file" 
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          setIsEditVendorUploading(true);
                          try {
                            const key = await uploadFileToS3(file);
                            setEditVendorShopImage(key);
                            alert("Image uploaded successfully.");
                          } catch (err: any) {
                            alert(err.message || "Failed to upload file");
                          } finally {
                            setIsEditVendorUploading(false);
                          }
                        }
                      }}
                    />
                    <label 
                      htmlFor="edit-vendor-image-file" 
                      className="btn btn-secondary" 
                      style={{ padding: '8px 12px', fontSize: '12px', cursor: 'pointer', margin: 0, whiteSpace: 'nowrap' }}
                    >
                      {isEditVendorUploading ? "Uploading..." : "📁 Upload Image"}
                    </label>
                    
                    {editVendorShopImage && (
                      <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                        <span style={{ fontSize: '11px', color: 'var(--success)' }}>✓ Uploaded</span>
                        <button 
                          type="button" 
                          onClick={() => setEditVendorShopImage('')} 
                          style={{ background: 'none', border: 'none', color: 'var(--danger)', cursor: 'pointer', fontSize: '12px' }}
                        >
                          Remove
                        </button>
                      </div>
                    )}
                  </div>
                  
                  <input 
                    type="text" 
                    className="form-control" 
                    style={{ marginTop: '8px', fontSize: '11px', padding: '4px 8px' }}
                    placeholder="Or paste external Image URL..." 
                    value={editVendorShopImage.startsWith('hoa/') ? 'S3 Uploaded File' : editVendorShopImage} 
                    onChange={(e) => {
                      if (!e.target.value.includes('S3 Uploaded File')) {
                        setEditVendorShopImage(e.target.value);
                      }
                    }} 
                  />
                </div>
              </div>

              {editVendorLocation === 'Other' && (
                <div className="form-group" style={{ marginBottom: '15px' }}>
                  <label className="form-label">Custom Location Name</label>
                  <input type="text" className="form-control" required placeholder="e.g. Mumbai, India" value={editVendorCustomLocation} onChange={(e) => setEditVendorCustomLocation(e.target.value)} />
                </div>
              )}

              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Supplied Items (Comma separated)</label>
                <input type="text" className="form-control" placeholder="e.g. Necklaces, Rings, Earrings" value={editVendorSuppliedItems} onChange={(e) => setEditVendorSuppliedItems(e.target.value)} />
              </div>

              <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '15px', marginTop: '15px' }}>
                <h4 style={{ fontSize: '14px', fontWeight: 500, marginBottom: '10px', color: 'var(--text-gold)' }}>Contact Person Details</h4>
                
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                  <div className="form-group">
                    <label className="form-label">Contact Name</label>
                    <input type="text" className="form-control" value={editVendorContact} onChange={(e) => setEditVendorContact(e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Phone Number</label>
                    <input type="text" className="form-control" value={editVendorPhone} onChange={(e) => setEditVendorPhone(e.target.value)} />
                  </div>
                </div>

                <div className="form-group" style={{ marginBottom: '15px' }}>
                  <label className="form-label">Email Address</label>
                  <input type="email" className="form-control" value={editVendorEmail} onChange={(e) => setEditVendorEmail(e.target.value)} />
                </div>

                <div className="form-group" style={{ marginBottom: '15px' }}>
                  <label className="form-label">Shop/Office Address</label>
                  <textarea className="form-control" style={{ height: '50px' }} value={editVendorAddress} onChange={(e) => setEditVendorAddress(e.target.value)} />
                </div>
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '10px' }}>
                Update Vendor
              </button>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL: CREATE HOA INVENTORY ITEM --- */}
      {showNewHoaItemModal && (
        <div className="flex-center" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.85)', zIndex: 600, padding: '20px' }}>
          <div className="card" style={{ maxWidth: '440px', width: '100%' }}>
            <div className="flex-between" style={{ marginBottom: '20px' }}>
              <h2 style={{ fontSize: '22px', fontWeight: 300 }}>Add HOA Inventory Item</h2>
              <button onClick={() => setShowNewHoaItemModal(false)} style={{ background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer' }}>✕</button>
            </div>

            <form onSubmit={handleCreateHoaItem}>
              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Item Name</label>
                <input type="text" className="form-control" required placeholder="e.g. 22K Gold Filigree Necklace" value={newHoaItemName} onChange={(e) => setNewHoaItemName(e.target.value)} />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">SKU Code</label>
                  <input type="text" className="form-control" required placeholder="e.g. JWL-NECK-001" value={newHoaItemSku} onChange={(e) => setNewHoaItemSku(e.target.value)} />
                </div>
                <div className="form-group">
                  <label className="form-label">Category</label>
                  <select className="form-control" value={newHoaItemCategory} onChange={(e) => setNewHoaItemCategory(e.target.value)}>
                    <option value="Anklet">Anklet</option>
                    <option value="Anklets">Anklets</option>
                    <option value="Bracelet">Bracelet</option>
                    <option value="Bracelets">Bracelets</option>
                    <option value="Dual Layer Chains">Dual Layer Chains</option>
                    <option value="Dual Layer Necklace">Dual Layer Necklace</option>
                    <option value="Earrings">Earrings</option>
                    <option value="Kada Bangle">Kada Bangle</option>
                    <option value="Kada Bangles">Kada Bangles</option>
                    <option value="Long Chain">Long Chain</option>
                    <option value="Long Chains">Long Chains</option>
                    <option value="Neckalces">Neckalces</option>
                    <option value="Necklace">Necklace</option>
                    <option value="Necklace with Earrings">Necklace with Earrings</option>
                    <option value="Necklaces">Necklaces</option>
                    <option value="Rings">Rings</option>
                    <option value="Short Earrings">Short Earrings</option>
                    <option value="Small Earrings">Small Earrings</option>
                    <option value="Studs Earrings">Studs Earrings</option>
                    <option value="Trendy Necklace">Trendy Necklace</option>
                  </select>
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Stock Level</label>
                  <input type="number" className="form-control" value={newHoaItemStock} onChange={(e) => setNewHoaItemStock(Number(e.target.value))} />
                </div>
                <div className="form-group">
                  <label className="form-label">Reorder Limit</label>
                  <input type="number" className="form-control" value={newHoaItemReorder} onChange={(e) => setNewHoaItemReorder(Number(e.target.value))} />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Unit Price (₹)</label>
                  <input type="number" className="form-control" value={newHoaItemUnitPrice} onChange={(e) => setNewHoaItemUnitPrice(Number(e.target.value))} />
                </div>
                <div className="form-group">
                  <label className="form-label">Vendor Source</label>
                  <select className="form-control" value={newHoaItemVendorId} onChange={(e) => setNewHoaItemVendorId(e.target.value)}>
                    <option value="">Select Vendor</option>
                    {hoaVendors.map(v => (
                      <option key={v.vendorId} value={v.vendorId}>{v.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* S3 Inventory Item Image Upload */}
              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Product Image</label>
                <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                  <input 
                    type="file" 
                    accept="image/*" 
                    style={{ display: 'none' }} 
                    id="new-item-image-file" 
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        setIsInventoryUploading(true);
                        try {
                          const key = await uploadFileToS3(file);
                          setNewHoaItemImage(key);
                          alert("Image uploaded successfully.");
                        } catch (err: any) {
                          alert(err.message || "Failed to upload file");
                        } finally {
                          setIsInventoryUploading(false);
                        }
                      }
                    }}
                  />
                  <label 
                    htmlFor="new-item-image-file" 
                    className="btn btn-secondary" 
                    style={{ padding: '8px 12px', fontSize: '12px', cursor: 'pointer', margin: 0, whiteSpace: 'nowrap' }}
                  >
                    {isInventoryUploading ? "Uploading..." : "📁 Upload Image"}
                  </label>
                  
                  {newHoaItemImage && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                      <span style={{ fontSize: '11px', color: 'var(--success)' }}>✓ Uploaded</span>
                      <button 
                        type="button" 
                        onClick={() => setNewHoaItemImage('')} 
                        style={{ background: 'none', border: 'none', color: 'var(--danger)', cursor: 'pointer', fontSize: '12px' }}
                      >
                        Remove
                      </button>
                    </div>
                  )}
                </div>
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '10px' }}>
                Save Item
              </button>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL: EDIT HOA INVENTORY ITEM --- */}
      {showEditHoaItemModal && selectedHoaItem && (
        <div className="flex-center" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.85)', zIndex: 600, padding: '20px' }}>
          <div className="card" style={{ maxWidth: '440px', width: '100%' }}>
            <div className="flex-between" style={{ marginBottom: '20px' }}>
              <h2 style={{ fontSize: '22px', fontWeight: 300 }}>Edit HOA Inventory Item</h2>
              <button onClick={() => setShowEditHoaItemModal(false)} style={{ background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer' }}>✕</button>
            </div>

            <form onSubmit={handleEditHoaItem}>
              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Item Name</label>
                <input type="text" className="form-control" required value={editHoaItemName} onChange={(e) => setEditHoaItemName(e.target.value)} />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">SKU Code</label>
                  <input type="text" className="form-control" required value={editHoaItemSku} onChange={(e) => setEditHoaItemSku(e.target.value)} />
                </div>
                <div className="form-group">
                  <label className="form-label">Category</label>
                  <select className="form-control" value={editHoaItemCategory} onChange={(e) => setEditHoaItemCategory(e.target.value)}>
                    <option value="Anklet">Anklet</option>
                    <option value="Anklets">Anklets</option>
                    <option value="Bracelet">Bracelet</option>
                    <option value="Bracelets">Bracelets</option>
                    <option value="Dual Layer Chains">Dual Layer Chains</option>
                    <option value="Dual Layer Necklace">Dual Layer Necklace</option>
                    <option value="Earrings">Earrings</option>
                    <option value="Kada Bangle">Kada Bangle</option>
                    <option value="Kada Bangles">Kada Bangles</option>
                    <option value="Long Chain">Long Chain</option>
                    <option value="Long Chains">Long Chains</option>
                    <option value="Neckalces">Neckalces</option>
                    <option value="Necklace">Necklace</option>
                    <option value="Necklace with Earrings">Necklace with Earrings</option>
                    <option value="Necklaces">Necklaces</option>
                    <option value="Rings">Rings</option>
                    <option value="Short Earrings">Short Earrings</option>
                    <option value="Small Earrings">Small Earrings</option>
                    <option value="Studs Earrings">Studs Earrings</option>
                    <option value="Trendy Necklace">Trendy Necklace</option>
                  </select>
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Stock Level</label>
                  <input type="number" className="form-control" value={editHoaItemStock} onChange={(e) => setEditHoaItemStock(Number(e.target.value))} />
                </div>
                <div className="form-group">
                  <label className="form-label">Reorder Limit</label>
                  <input type="number" className="form-control" value={editHoaItemReorder} onChange={(e) => setEditHoaItemReorder(Number(e.target.value))} />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Unit Price (₹)</label>
                  <input type="number" className="form-control" value={editHoaItemUnitPrice} onChange={(e) => setEditHoaItemUnitPrice(Number(e.target.value))} />
                </div>
                <div className="form-group">
                  <label className="form-label">Vendor Source</label>
                  <select className="form-control" value={editHoaItemVendorId} onChange={(e) => setEditHoaItemVendorId(e.target.value)}>
                    <option value="">Select Vendor</option>
                    {hoaVendors.map(v => (
                      <option key={v.vendorId} value={v.vendorId}>{v.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* S3 Inventory Item Image Upload */}
              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">Product Image</label>
                <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                  <input 
                    type="file" 
                    accept="image/*" 
                    style={{ display: 'none' }} 
                    id="edit-item-image-file" 
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        setIsEditInventoryUploading(true);
                        try {
                          const key = await uploadFileToS3(file);
                          setEditHoaItemImage(key);
                          alert("Image uploaded successfully.");
                        } catch (err: any) {
                          alert(err.message || "Failed to upload file");
                        } finally {
                          setIsEditInventoryUploading(false);
                        }
                      }
                    }}
                  />
                  <label 
                    htmlFor="edit-item-image-file" 
                    className="btn btn-secondary" 
                    style={{ padding: '8px 12px', fontSize: '12px', cursor: 'pointer', margin: 0, whiteSpace: 'nowrap' }}
                  >
                    {isEditInventoryUploading ? "Uploading..." : "📁 Upload Image"}
                  </label>
                  
                  {editHoaItemImage && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                      <span style={{ fontSize: '11px', color: 'var(--success)' }}>✓ Uploaded</span>
                      {editHoaItemImage.startsWith('http') && (
                        <a href={editHoaItemImage} target="_blank" rel="noopener noreferrer" style={{ fontSize: '12px', textDecoration: 'none' }} className="text-gold">View</a>
                      )}
                      <button 
                        type="button" 
                        onClick={() => setEditHoaItemImage('')} 
                        style={{ background: 'none', border: 'none', color: 'var(--danger)', cursor: 'pointer', fontSize: '12px' }}
                      >
                        Remove
                      </button>
                    </div>
                  )}
                </div>
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '10px' }}>
                Update Item
              </button>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL: CREATE HOA PURCHASE ORDER --- */}
      {showNewPoModal && (
        <div className="flex-center" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.85)', zIndex: 600, padding: '20px' }}>
          <div className="card" style={{ maxWidth: '560px', width: '100%', maxHeight: '90vh', overflowY: 'auto' }}>
            <div className="flex-between" style={{ marginBottom: '20px' }}>
              <h2 style={{ fontSize: '22px', fontWeight: 300 }}>Create HOA Purchase Order</h2>
              <button onClick={() => setShowNewPoModal(false)} style={{ background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer' }}>✕</button>
            </div>

            <form onSubmit={handleCreatePo}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Select Vendor</label>
                  <select className="form-control" required value={newPoVendorId} onChange={(e) => setNewPoVendorId(e.target.value)}>
                    <option value="">Choose Jewelry Vendor</option>
                    {hoaVendors.map(v => (
                      <option key={v.vendorId} value={v.vendorId}>{v.name}</option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Expected Delivery Date</label>
                  <input type="date" className="form-control" value={newPoDeliveryDate} onChange={(e) => setNewPoDeliveryDate(e.target.value)} />
                </div>
              </div>

              {/* S3 PO Receipt/Invoice Image Upload */}
              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">PO Receipt/Invoice Image</label>
                <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                  <input 
                    type="file" 
                    accept="image/*" 
                    style={{ display: 'none' }} 
                    id="new-po-image-file" 
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        setIsPoUploading(true);
                        try {
                          const key = await uploadFileToS3(file);
                          setNewPoImage(key);
                          alert("Receipt image uploaded successfully.");
                        } catch (err: any) {
                          alert(err.message || "Failed to upload file");
                        } finally {
                          setIsPoUploading(false);
                        }
                      }
                    }}
                  />
                  <label 
                    htmlFor="new-po-image-file" 
                    className="btn btn-secondary" 
                    style={{ padding: '8px 12px', fontSize: '12px', cursor: 'pointer', margin: 0, whiteSpace: 'nowrap' }}
                  >
                    {isPoUploading ? "Uploading..." : "📁 Upload Receipt"}
                  </label>
                  
                  {newPoImage && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                      <span style={{ fontSize: '11px', color: 'var(--success)' }}>✓ Uploaded</span>
                      <button 
                        type="button" 
                        onClick={() => setNewPoImage('')} 
                        style={{ background: 'none', border: 'none', color: 'var(--danger)', cursor: 'pointer', fontSize: '12px' }}
                      >
                        Remove
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Add items to PO */}
              <div style={{ padding: '15px', border: '1px solid var(--border-color)', borderRadius: '6px', marginBottom: '20px', backgroundColor: 'var(--bg-secondary)' }}>
                <h4 style={{ fontSize: '14px', fontWeight: 500, marginBottom: '10px' }} className="text-gold">Add Item Row</h4>
                <div className="form-group" style={{ marginBottom: '10px' }}>
                  <label className="form-label" style={{ fontSize: '9px' }}>Item Selection</label>
                  <select 
                    className="form-control" 
                    value={newPoItemSku} 
                    onChange={(e) => {
                      const skuVal = e.target.value;
                      setNewPoItemSku(skuVal);
                      const matched = hoaInventory.find(i => i.sku === skuVal);
                      if (matched) {
                        setNewPoItemName(matched.name);
                        setNewPoItemUnitPrice(matched.unitPrice);
                      }
                    }}
                  >
                    <option value="">Select Item from Inventory (Optional helper)</option>
                    {hoaInventory.map(item => (
                      <option key={item.itemId} value={item.sku}>{item.name} ({item.sku})</option>
                    ))}
                  </select>
                </div>
                <div className="form-group" style={{ marginBottom: '10px' }}>
                  <label className="form-label" style={{ fontSize: '9px' }}>Manual Item Name (if not in inventory)</label>
                  <input type="text" className="form-control" placeholder="Item Name" value={newPoItemName} onChange={(e) => setNewPoItemName(e.target.value)} />
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '10px' }}>
                  <div className="form-group" style={{ marginBottom: 0 }}>
                    <label className="form-label" style={{ fontSize: '9px' }}>Quantity</label>
                    <input type="number" min="1" className="form-control" value={newPoItemQuantity} onChange={(e) => setNewPoItemQuantity(Number(e.target.value))} />
                  </div>
                  <div className="form-group" style={{ marginBottom: 0 }}>
                    <label className="form-label" style={{ fontSize: '9px' }}>Unit Cost Price (₹)</label>
                    <input type="number" min="0" className="form-control" value={newPoItemUnitPrice} onChange={(e) => setNewPoItemUnitPrice(Number(e.target.value))} />
                  </div>
                </div>
                <button type="button" onClick={handleAddPoItem} className="btn btn-secondary" style={{ width: '100%', padding: '6px', fontSize: '12px' }}>
                  + Add Item to Order
                </button>
              </div>

              {/* PO Items list summary */}
              <div style={{ marginBottom: '20px' }}>
                <h4 style={{ fontSize: '14px', fontWeight: 500, marginBottom: '8px' }}>Purchase Order Items List</h4>
                {newPoItems.length === 0 ? (
                  <p className="text-muted" style={{ fontSize: '12px' }}>No items added yet.</p>
                ) : (
                  <div style={{ maxHeight: '150px', overflowY: 'auto' }}>
                    {newPoItems.map((item, idx) => (
                      <div key={idx} className="flex-between" style={{ padding: '8px 10px', borderBottom: '1px solid var(--border-color)', fontSize: '13px' }}>
                        <div>
                          <strong>{item.name}</strong> {item.sku && <span style={{ fontSize: '10px', fontFamily: 'monospace' }}>({item.sku})</span>}
                          <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>{item.quantity} units × ₹{item.unitPrice.toLocaleString()}</div>
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
                          <span style={{ fontWeight: 500 }}>₹{item.total.toLocaleString()}</span>
                          <button type="button" onClick={() => setNewPoItems(newPoItems.filter((_, i) => i !== idx))} style={{ background: 'none', border: 'none', color: 'var(--danger)', cursor: 'pointer' }}>✕</button>
                        </div>
                      </div>
                    ))}
                    <div className="flex-between" style={{ padding: '10px', fontWeight: 600, borderTop: '2px solid var(--border-color)', fontSize: '14px', marginTop: '10px' }}>
                      <span>Total Amount:</span>
                      <span className="text-gold">₹{newPoItems.reduce((sum, item) => sum + item.total, 0).toLocaleString()}</span>
                    </div>
                  </div>
                )}
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%' }}>
                Create Purchase Order & Send
              </button>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL: EDIT HOA PURCHASE ORDER --- */}
      {showEditPoModal && selectedPo && (
        <div className="flex-center" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.85)', zIndex: 600, padding: '20px' }}>
          <div className="card" style={{ maxWidth: '560px', width: '100%', maxHeight: '90vh', overflowY: 'auto' }}>
            <div className="flex-between" style={{ marginBottom: '20px' }}>
              <h2 style={{ fontSize: '22px', fontWeight: 300 }}>Edit HOA Purchase Order</h2>
              <button onClick={() => { setShowEditPoModal(false); setSelectedPo(null); }} style={{ background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer' }}>✕</button>
            </div>

            <form onSubmit={handleEditPo}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Select Vendor</label>
                  <select className="form-control" required value={editPoVendorId} onChange={(e) => setEditPoVendorId(e.target.value)}>
                    <option value="">Choose Jewelry Vendor</option>
                    {hoaVendors.map(v => (
                      <option key={v.vendorId} value={v.vendorId}>{v.name}</option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Expected Delivery Date</label>
                  <input type="date" className="form-control" value={editPoDeliveryDate} onChange={(e) => setEditPoDeliveryDate(e.target.value)} />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                <div className="form-group">
                  <label className="form-label">Fulfillment Status</label>
                  <select className="form-control" value={editPoStatus} onChange={(e) => setEditPoStatus(e.target.value as any)}>
                    <option value="DRAFT">DRAFT</option>
                    <option value="SENT">SENT</option>
                    <option value="DELIVERED">DELIVERED</option>
                    <option value="CANCELLED">CANCELLED</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Payment Status</label>
                  <select className="form-control" value={editPoPaymentStatus} onChange={(e) => setEditPoPaymentStatus(e.target.value as any)}>
                    <option value="UNPAID">UNPAID</option>
                    <option value="PARTIALLY_PAID">PARTIALLY_PAID</option>
                    <option value="PAID">PAID</option>
                  </select>
                </div>
              </div>

              {/* Edit/Upload Receipt Image */}
              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label className="form-label">PO Receipt/Invoice Image</label>
                <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                  <input 
                    type="file" 
                    accept="image/*" 
                    style={{ display: 'none' }} 
                    id="edit-po-image-file" 
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        setIsEditPoUploading(true);
                        try {
                          const key = await uploadFileToS3(file);
                          setEditPoImage(key);
                          alert("Receipt image uploaded successfully.");
                        } catch (err: any) {
                          alert(err.message || "Failed to upload file");
                        } finally {
                          setIsEditPoUploading(false);
                        }
                      }
                    }}
                  />
                  <label 
                    htmlFor="edit-po-image-file" 
                    className="btn btn-secondary" 
                    style={{ padding: '8px 12px', fontSize: '12px', cursor: 'pointer', margin: 0, whiteSpace: 'nowrap' }}
                  >
                    {isEditPoUploading ? "Uploading..." : "📁 Upload Receipt"}
                  </label>
                  
                  {editPoImage && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                      <span style={{ fontSize: '11px', color: 'var(--success)' }}>✓ Uploaded</span>
                      {editPoImage.startsWith('http') && (
                        <a href={editPoImage} target="_blank" rel="noopener noreferrer" style={{ fontSize: '12px', textDecoration: 'none' }} className="text-gold">View</a>
                      )}
                      <button 
                        type="button" 
                        onClick={() => setEditPoImage('')} 
                        style={{ background: 'none', border: 'none', color: 'var(--danger)', cursor: 'pointer', fontSize: '12px' }}
                      >
                        Remove
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Add items to PO */}
              <div style={{ padding: '15px', border: '1px solid var(--border-color)', borderRadius: '6px', marginBottom: '20px', backgroundColor: 'var(--bg-secondary)' }}>
                <h4 style={{ fontSize: '14px', fontWeight: 500, marginBottom: '10px' }} className="text-gold">Add Item Row</h4>
                <div className="form-group" style={{ marginBottom: '10px' }}>
                  <label className="form-label" style={{ fontSize: '9px' }}>Item Selection</label>
                  <select 
                    className="form-control" 
                    value={editPoItemSku} 
                    onChange={(e) => {
                      const skuVal = e.target.value;
                      setEditPoItemSku(skuVal);
                      const matched = hoaInventory.find(i => i.sku === skuVal);
                      if (matched) {
                        setEditPoItemName(matched.name);
                        setEditPoItemUnitPrice(matched.unitPrice);
                      }
                    }}
                  >
                    <option value="">Select Item from Inventory (Optional helper)</option>
                    {hoaInventory.map(item => (
                      <option key={item.itemId} value={item.sku}>{item.name} ({item.sku})</option>
                    ))}
                  </select>
                </div>
                <div className="form-group" style={{ marginBottom: '10px' }}>
                  <label className="form-label" style={{ fontSize: '9px' }}>Manual Item Name (if not in inventory)</label>
                  <input type="text" className="form-control" placeholder="Item Name" value={editPoItemName} onChange={(e) => setEditPoItemName(e.target.value)} />
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '10px' }}>
                  <div className="form-group" style={{ marginBottom: 0 }}>
                    <label className="form-label" style={{ fontSize: '9px' }}>Quantity</label>
                    <input type="number" min="1" className="form-control" value={editPoItemQuantity} onChange={(e) => setEditPoItemQuantity(Number(e.target.value))} />
                  </div>
                  <div className="form-group" style={{ marginBottom: 0 }}>
                    <label className="form-label" style={{ fontSize: '9px' }}>Unit Cost Price (₹)</label>
                    <input type="number" min="0" className="form-control" value={editPoItemUnitPrice} onChange={(e) => setEditPoItemUnitPrice(Number(e.target.value))} />
                  </div>
                </div>
                <button type="button" onClick={handleAddEditPoItem} className="btn btn-secondary" style={{ width: '100%', padding: '6px', fontSize: '12px' }}>
                  + Add Item to Order
                </button>
              </div>

              {/* PO Items list summary */}
              <div style={{ marginBottom: '20px' }}>
                <h4 style={{ fontSize: '14px', fontWeight: 500, marginBottom: '8px' }}>Purchase Order Items List</h4>
                {editPoItems.length === 0 ? (
                  <p className="text-muted" style={{ fontSize: '12px' }}>No items added yet.</p>
                ) : (
                  <div style={{ maxHeight: '150px', overflowY: 'auto' }}>
                    {editPoItems.map((item, idx) => (
                      <div key={idx} className="flex-between" style={{ padding: '8px 10px', borderBottom: '1px solid var(--border-color)', fontSize: '13px' }}>
                        <div>
                          <strong>{item.name}</strong> {item.sku && <span style={{ fontSize: '10px', fontFamily: 'monospace' }}>({item.sku})</span>}
                          <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>{item.quantity} units × ₹{item.unitPrice.toLocaleString()}</div>
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
                          <span style={{ fontWeight: 500 }}>₹{item.total.toLocaleString()}</span>
                          <button type="button" onClick={() => handleRemoveEditPoItem(idx)} style={{ background: 'none', border: 'none', color: 'var(--danger)', cursor: 'pointer' }}>✕</button>
                        </div>
                      </div>
                    ))}
                    <div className="flex-between" style={{ padding: '10px', fontWeight: 600, borderTop: '2px solid var(--border-color)', fontSize: '14px', marginTop: '10px' }}>
                      <span>Total Amount:</span>
                      <span className="text-gold">₹{editPoItems.reduce((sum, item) => sum + item.total, 0).toLocaleString()}</span>
                    </div>
                  </div>
                )}
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%' }}>
                Update Purchase Order
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
