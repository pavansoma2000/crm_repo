// Storybox CRM Frontend API Integration Service
// Supports Dual Mode: Live AWS endpoints if provided, otherwise robust LocalStorage mock backend.

const API_STAGE_URL = import.meta.env.VITE_API_GATEWAY_URL || "";
const COGNITO_CLIENT_ID = import.meta.env.VITE_COGNITO_CLIENT_ID || "";

// Centralized Fetch Interceptor for Auth Expiration (401 Unauthorized)
const originalFetch = window.fetch;
window.fetch = async (...args) => {
  const response = await originalFetch(...args);
  if (response.status === 401) {
    const urlString = typeof args[0] === 'string' ? args[0] : (args[0] as Request).url;
    if (!urlString.includes('InitiateAuth') && localStorage.getItem('storybox_token')) {
      localStorage.removeItem('storybox_token');
      localStorage.removeItem('storybox_session_user');
      alert("Session expired. Please log in again.");
      window.location.reload();
    }
  }
  return response;
};

export interface UserPermissions {
  canProof: boolean;
  canPay: boolean;
  canViewDetails: boolean;
}

export interface User {
  userId: string;
  name: string;
  email: string;
  phone: string;
  role: 'SUPER_ADMIN' | 'ADMIN' | 'READ_ONLY' | 'CLIENT' | 'HOA_STAFF';
  status: 'ACTIVE' | 'INACTIVE';
  permissions?: UserPermissions;
}

export interface Booking {
  bookingId: string;
  projectId: string;
  location: string;
  startTime: string;
  endTime: string;
  photographers: string[];
  notes?: string;
}

export interface GalleryImage {
  key: string;
  url: string;
  selected: boolean;
  comment: string;
}

export interface Gallery {
  galleryId: string;
  projectId: string;
  name: string;
  status: 'PROOFING' | 'DELIVERED';
  images: GalleryImage[];
  createdAt: string;
}

export interface Invoice {
  invoiceId: string;
  projectId: string;
  clientId: string;
  projectTitle: string;
  amount: number;
  description: string;
  status: 'PENDING' | 'PAID' | 'OVERDUE';
  dueDate: string;
  createdAt: string;
  paidAt?: string;
}

export interface Project {
  projectId: string;
  clientId: string;
  title: string;
  type: string;
  date: string;
  totalAmount: number;
  status: 'PLANNING' | 'IN_PROGRESS' | 'PROOFING' | 'COMPLETED';
  notes?: string;
  createdAt: string;
}

export interface Lead {
  leadId: string;
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  eventType: string;
  eventDate: string;
  budget: number;
  status: 'ENQUIRY' | 'LEAD' | 'CONVERTED' | 'LOST';
  source: string;
  notes?: string;
  createdAt: string;
}

export interface InventoryItem {
  itemId: string;
  name: string;
  category: 'CAMERA' | 'LENS' | 'DRONE' | 'LIGHTING' | 'ACCESSORY';
  serialNumber: string;
  status: 'IN_STUDIO' | 'ON_LOCATION' | 'MAINTENANCE';
  assignedTo?: string;
}

export interface HoaVendor {
  vendorId: string;
  name: string;
  contactPerson: string;
  email: string;
  phone: string;
  address: string;
  category: string;
  status: 'ACTIVE' | 'INACTIVE';
  performanceScore: number;
  shopImage?: string;
  location: string;
  suppliedItems?: string[];
}

export interface HoaInventoryItem {
  itemId: string;
  name: string;
  sku: string;
  category: string;
  stockLevel: number;
  reorderPoint: number;
  unitPrice: number;
  vendorId: string;
  status: 'IN_STOCK' | 'LOW_STOCK' | 'OUT_OF_STOCK';
  itemImage?: string;
  lastUpdated: string;
}

export interface HoaPOItem {
  name: string;
  sku?: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

export interface HoaPurchaseOrder {
  poId: string;
  vendorId: string;
  vendorName: string;
  orderDate: string;
  deliveryDate: string;
  items: HoaPOItem[];
  totalAmount: number;
  status: 'DRAFT' | 'SENT' | 'DELIVERED' | 'CANCELLED';
  paymentStatus: 'UNPAID' | 'PARTIALLY_PAID' | 'PAID';
  poImage?: string;
}

export interface Subscription {
  subscriptionId: string;
  clientName: string;
  planName: 'BASIC PROOFING' | 'PREMIUM GALLERY' | 'ENTERPRISE RETOUCHING';
  price: number;
  billingCycle: 'ANNUAL' | 'MONTHLY';
  startDate: string;
  status: 'ACTIVE' | 'EXPIRED' | 'PENDING';
}

export interface ProposalVersion {
  version: number;
  title: string;
  description: string;
  budget: number;
  deliverables: string[];
  terms: string;
  createdAt: string;
}

export interface Proposal {
  proposalId: string;
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  status: 'DRAFT' | 'SENT' | 'ACCEPTED' | 'REJECTED';
  currentVersion: number;
  versions: ProposalVersion[];
  createdAt: string;
}

export interface BankDetails {
  bankName: string;
  accountName: string;
  accountNumber: string;
  ifscCode: string;
  branch: string;
}

export interface HealthInsurance {
  policyNumber: string;
  provider: string;
  sumInsured: number;
  tpaName: string;
  expiryDate: string;
}

export interface EmploymentHistory {
  company: string;
  designation: string;
  startDate: string;
  endDate: string;
  reasonForLeaving: string;
}

export interface OnsiteTravel {
  country: string;
  purpose: string;
  startDate: string;
  endDate: string;
  status: 'PENDING' | 'APPROVED' | 'COMPLETED' | 'CANCELLED';
}

export interface EmergencyContact {
  name: string;
  relationship: string;
  phone: string;
}

export interface Employee {
  employeeId: string;
  name: string;
  email: string;
  phone: string;
  designation: string;
  department: string;
  dateOfJoining: string;
  bloodGroup: string;
  personalEmail: string;
  address: string;
  
  // Financials
  ctc: number;
  monthlySalary: number;
  bankDetails: BankDetails;
  
  // IDs
  panCard: string;
  aadharCard: string;
  
  // Health & Travel & History
  healthInsurance: HealthInsurance;
  employmentHistory: EmploymentHistory[];
  travelHistory: OnsiteTravel[];
  emergencyContacts: EmergencyContact[];
  status: 'ACTIVE' | 'INACTIVE';
}

// Initial Mock Seed Data


















// LocalStorage Helper functions




const formatE164Phone = (phone: string) => {
  if (!phone) return '+919999999999';
  const clean = phone.replace(/\D/g, '');
  // Default to Indian prefix if 10 digits and not starting with +
  if (clean.length === 10 && !phone.startsWith('+')) {
    return `+91${clean}`;
  }
  return `+${clean}`;
};

export const apiService = {
  // --- AUTH SERVICES ---
  currentUser: (): User | null => {
    
    const userStr = localStorage.getItem("storybox_session_user");
    return userStr ? JSON.parse(userStr) : null;
 // Defaults to Admin login
  },

  login: async (email: string, password?: string): Promise<User> => {
    // If live Cognito config is present, try authenticating with AWS Cognito USER_PASSWORD_AUTH
    
      const response = await fetch(`https://cognito-idp.ap-south-2.amazonaws.com/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-amz-json-1.1',
          'X-Amz-Target': 'AWSCognitoIdentityProviderService.InitiateAuth'
        },
        body: JSON.stringify({
          AuthFlow: 'USER_PASSWORD_AUTH',
          ClientId: COGNITO_CLIENT_ID,
          AuthParameters: {
            USERNAME: email,
            PASSWORD: password
          }
        })
      });
      
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || "Cognito authentication failed");
      }
      
      const idToken = data.AuthenticationResult.IdToken;
      localStorage.setItem('storybox_token', idToken);
      
      // Decode JWT token claims (sub, name, email, custom:role)
      const payloadBase64 = idToken.split('.')[1];
      const payloadJson = JSON.parse(atob(payloadBase64.replace(/-/g, '+').replace(/_/g, '/')));
      
      const loggedUser: User = {
        userId: payloadJson.sub,
        name: payloadJson.name || payloadJson.email.split('@')[0],
        email: payloadJson.email,
        phone: payloadJson.phone_number || '+91 9999999999',
        role: (payloadJson['custom:role'] || 'CLIENT') as any,
        status: 'ACTIVE'
      };
      
      localStorage.setItem('storybox_session_user', JSON.stringify(loggedUser));
      return loggedUser;
  },

  logout: () => {
    localStorage.removeItem("storybox_session_user");
    localStorage.removeItem("storybox_token");
  },

  // --- PROJECT SERVICES ---
  getProjects: async (): Promise<Project[]> => {
    const user = apiService.currentUser();
    if (!user) return [];

    
      const response = await fetch(`${API_STAGE_URL}/projects`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('storybox_token')}` }
      });
      return await response.json();
    
  },

  createProject: async (title: string, type: string, date: string, totalAmount: number, clientId: string, notes: string): Promise<Project> => {
    
      const response = await fetch(`${API_STAGE_URL}/projects`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
        },
        body: JSON.stringify({ title, type, date, totalAmount, clientId, notes })
      });
      return await response.json();
    
  },

  getProjectDetails: async (projectId: string): Promise<{ metadata: Project, bookings: Booking[], galleries: Gallery[], invoices: Invoice[] }> => {
    
      const response = await fetch(`${API_STAGE_URL}/projects/${projectId}`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('storybox_token')}` }
      });
      return await response.json();
    
  },

  updateProjectStatus: async (projectId: string, status: 'PLANNING' | 'IN_PROGRESS' | 'PROOFING' | 'COMPLETED'): Promise<Project> => {
    
      const response = await fetch(`${API_STAGE_URL}/projects/${projectId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
        },
        body: JSON.stringify({ status })
      });
      return await response.json();
    
  },

  // --- BOOKING SERVICES ---
  addBooking: async (projectId: string, location: string, startTime: string, endTime: string, photographers: string[], notes: string): Promise<Booking> => {
    
      const response = await fetch(`${API_STAGE_URL}/projects/${projectId}/bookings`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
        },
        body: JSON.stringify({ location, startTime, endTime, photographers, notes })
      });
      return await response.json();
    
  },

  // --- INVOICE & BILLING SERVICES ---
  getInvoices: async (): Promise<Invoice[]> => {
    const user = apiService.currentUser();
    if (!user) return [];

    
      const response = await fetch(`${API_STAGE_URL}/invoices`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('storybox_token')}` }
      });
      return await response.json();
    
  },

  payInvoice: async (projectId: string, invoiceId: string): Promise<Invoice> => {
    
      const response = await fetch(`${API_STAGE_URL}/projects/${projectId}/invoices/${invoiceId}/pay`, {
        method: 'PUT',
        headers: { 'Authorization': `Bearer ${localStorage.getItem('storybox_token')}` }
      });
      return await response.json();
    
  },

  createInvoice: async (projectId: string, amount: number, description: string, dueDate: string): Promise<Invoice> => {
    
      const response = await fetch(`${API_STAGE_URL}/projects/${projectId}/invoices`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
        },
        body: JSON.stringify({ amount, description, dueDate })
      });
      return await response.json();
    
  },

  // --- GALLERY SERVICES ---
  createGallery: async (projectId: string, name: string): Promise<Gallery> => {
    
      const response = await fetch(`${API_STAGE_URL}/projects/${projectId}/galleries`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
        },
        body: JSON.stringify({ name })
      });
      return await response.json();
    
  },

  uploadImageToGallery: async (_projectId: string, galleryId: string, url: string): Promise<Gallery> => {
      const response = await fetch(`${API_STAGE_URL}/projects/${_projectId}/galleries/${galleryId}/upload`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
        },
        body: JSON.stringify({ url })
      });
      return await response.json();
  },

  submitClientSelections: async (projectId: string, galleryId: string, selections: { [key: string]: { selected: boolean, comment: string } }): Promise<Gallery> => {
    
      const response = await fetch(`${API_STAGE_URL}/projects/${projectId}/galleries/${galleryId}/select`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
        },
        body: JSON.stringify({ selections })
      });
      return await response.json();
    
  },

  // --- CRM METRICS STATS ---
  getDashboardStats: async () => {
    
      const response = await fetch(`${API_STAGE_URL}/stats`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('storybox_token')}` }
      });
      return await response.json();
    
  },

  // Get list of clients for dropdowns
  getClientsList: async (): Promise<User[]> => {
    
      const response = await fetch(`${API_STAGE_URL}/users?roleGroup=clients`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('storybox_token')}` }
      });
      return await response.json();
    
  },

  getTeam: async (): Promise<User[]> => {
    
      const response = await fetch(`${API_STAGE_URL}/users?roleGroup=team`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('storybox_token')}` }
      });
      return await response.json();
    
  },

  getClients: async (): Promise<User[]> => {
    
      const response = await fetch(`${API_STAGE_URL}/users?roleGroup=clients`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('storybox_token')}` }
      });
      return await response.json();
    
  },

  getLeads: async (): Promise<Lead[]> => {
    
      const response = await fetch(`${API_STAGE_URL}/leads`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('storybox_token')}` }
      });
      return await response.json();
    
  },

  createLead: async (clientName: string, clientEmail: string, clientPhone: string, eventType: string, eventDate: string, budget: number, notes: string): Promise<Lead> => {
    
      const response = await fetch(`${API_STAGE_URL}/leads`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
        },
        body: JSON.stringify({ clientName, clientEmail, clientPhone, eventType, eventDate, budget, notes })
      });
      return await response.json();
    
  },

  updateLeadStatus: async (leadId: string, status: 'ENQUIRY' | 'LEAD' | 'CONVERTED' | 'LOST'): Promise<Lead> => {
    
      const response = await fetch(`${API_STAGE_URL}/leads/${leadId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
        },
        body: JSON.stringify({ status })
      });
      const updated = await response.json();
      
      if (status === 'CONVERTED') {
        try {
          const clients = await apiService.getClients();
          let exists = clients.find((c: User) => c.email === updated.clientEmail);
          if (!exists) {
            exists = await apiService.createUser({
              name: updated.clientName,
              email: updated.clientEmail,
              phone: updated.clientPhone,
              role: 'CLIENT',
              status: 'ACTIVE'
            });
          }
          await apiService.createProject(
            `${updated.clientName} ${updated.eventType}`,
            updated.eventType,
            updated.eventDate,
            updated.budget,
            exists.userId,
            updated.notes || 'Converted from lead pipeline.'
          );
        } catch (err) {
          console.error("Error auto converting lead: ", err);
        }
      }
      return updated;
    
  },

  getInventory: async (): Promise<InventoryItem[]> => {
    
      const response = await fetch(`${API_STAGE_URL}/inventory`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('storybox_token')}` }
      });
      return await response.json();
    
  },

  createInventoryItem: async (name: string, category: 'CAMERA' | 'LENS' | 'DRONE' | 'LIGHTING' | 'ACCESSORY', serialNumber: string): Promise<InventoryItem> => {
    
      const response = await fetch(`${API_STAGE_URL}/inventory`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
        },
        body: JSON.stringify({ name, category, serialNumber })
      });
      return await response.json();
    
  },

  deleteInventoryItem: async (itemId: string): Promise<boolean> => {
    
      await fetch(`${API_STAGE_URL}/inventory/${itemId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${localStorage.getItem('storybox_token')}` }
      });
      return true;
    
  },

  updateInventoryStatus: async (itemId: string, status: 'IN_STUDIO' | 'ON_LOCATION' | 'MAINTENANCE', assignedTo: string): Promise<InventoryItem> => {
    
      const response = await fetch(`${API_STAGE_URL}/inventory/${itemId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
        },
        body: JSON.stringify({ status, assignedTo })
      });
      return await response.json();
    
  },

  getSubscriptions: async (): Promise<Subscription[]> => {
    
      const response = await fetch(`${API_STAGE_URL}/subscriptions`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('storybox_token')}` }
      });
      return await response.json();
    
  },

  createSubscription: async (clientName: string, planName: string, price: number, billingCycle: 'ANNUAL' | 'MONTHLY', startDate: string, status: 'ACTIVE' | 'EXPIRED' | 'PENDING'): Promise<Subscription> => {
    
      const response = await fetch(`${API_STAGE_URL}/subscriptions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
        },
        body: JSON.stringify({ clientName, planName, price, billingCycle, startDate, status })
      });
      return await response.json();
    
  },

  deleteSubscription: async (subscriptionId: string): Promise<boolean> => {
    
      await fetch(`${API_STAGE_URL}/subscriptions/${subscriptionId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${localStorage.getItem('storybox_token')}` }
      });
      return true;
    
  },

  deleteProject: async (projectId: string): Promise<boolean> => {
    
      await fetch(`${API_STAGE_URL}/projects/${projectId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${localStorage.getItem('storybox_token')}` }
      });
      return true;
    
  },

  updateInventoryItem: async (itemId: string, data: { name: string; category: 'CAMERA' | 'LENS' | 'DRONE' | 'LIGHTING' | 'ACCESSORY'; serialNumber: string; status: 'IN_STUDIO' | 'ON_LOCATION' | 'MAINTENANCE'; assignedTo?: string }): Promise<InventoryItem> => {
    
      const response = await fetch(`${API_STAGE_URL}/inventory/${itemId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
        },
        body: JSON.stringify(data)
      });
      return await response.json();
    
  },

  updateSubscription: async (subscriptionId: string, data: { clientName: string; planName: string; price: number; billingCycle: 'ANNUAL' | 'MONTHLY'; startDate: string; status: 'ACTIVE' | 'EXPIRED' | 'PENDING' }): Promise<Subscription> => {
    
      const response = await fetch(`${API_STAGE_URL}/subscriptions/${subscriptionId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
        },
        body: JSON.stringify(data)
      });
      return await response.json();
    
  },

  updateLead: async (leadId: string, data: { clientName: string; clientEmail: string; clientPhone: string; eventType: string; eventDate: string; budget: number; notes?: string; status: 'ENQUIRY' | 'LEAD' | 'CONVERTED' | 'LOST' }): Promise<Lead> => {
    
      const response = await fetch(`${API_STAGE_URL}/leads/${leadId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
        },
        body: JSON.stringify(data)
      });
      return await response.json();
    
  },

  createUser: async (data: { name: string; email: string; phone: string; role: 'SUPER_ADMIN' | 'ADMIN' | 'READ_ONLY' | 'CLIENT' | 'HOA_STAFF'; status: 'ACTIVE' | 'INACTIVE'; password?: string; permissions?: UserPermissions }): Promise<User> => {
    const formattedData = {
      ...data,
      phone: formatE164Phone(data.phone)
    };
    
      const response = await fetch(`${API_STAGE_URL}/users`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
        },
        body: JSON.stringify(formattedData)
      });
      return await response.json();
    
  },

  updateUser: async (userId: string, data: { name: string; email: string; phone: string; role: 'SUPER_ADMIN' | 'ADMIN' | 'READ_ONLY' | 'CLIENT' | 'HOA_STAFF'; status: 'ACTIVE' | 'INACTIVE'; permissions?: UserPermissions }): Promise<User> => {
    
      const response = await fetch(`${API_STAGE_URL}/users/${userId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
        },
        body: JSON.stringify(data)
      });
      return await response.json();
    
  },

  deleteUser: async (userId: string): Promise<void> => {
    const response = await fetch(`${API_STAGE_URL}/users/${userId}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${localStorage.getItem('storybox_token')}` }
    });
    if (!response.ok) throw new Error("Failed to delete user");
  },

  updateUserPermissions: async (userId: string, permissions: UserPermissions): Promise<User> => {
    
      const response = await fetch(`${API_STAGE_URL}/users/${userId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
        },
        body: JSON.stringify({ permissions })
      });
      return await response.json();
    
  },

  updateUserRole: async (userId: string, role: 'SUPER_ADMIN' | 'ADMIN' | 'READ_ONLY' | 'CLIENT'): Promise<User> => {
    
      const response = await fetch(`${API_STAGE_URL}/users/${userId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
        },
        body: JSON.stringify({ role })
      });
      return await response.json();
    
  },

  updateUserStatus: async (userId: string, status: 'ACTIVE' | 'INACTIVE'): Promise<User> => {
    
      const response = await fetch(`${API_STAGE_URL}/users/${userId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
        },
        body: JSON.stringify({ status })
      });
      return await response.json();
    
  },

  // --- PROPOSALS SERVICES ---
  getProposals: async (): Promise<Proposal[]> => {
    
      const response = await fetch(`${API_STAGE_URL}/proposals`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('storybox_token')}` }
      });
      return await response.json();
    
  },

  createProposal: async (clientName: string, clientEmail: string, clientPhone: string, title: string, description: string, budget: number, deliverables: string[], terms: string): Promise<Proposal> => {
    
      const response = await fetch(`${API_STAGE_URL}/proposals`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
        },
        body: JSON.stringify({ clientName, clientEmail, clientPhone, title, description, budget, deliverables, terms })
      });
      return await response.json();
    
  },

  updateProposal: async (proposalId: string, data: { title: string; description: string; budget: number; deliverables: string[]; terms: string; status?: 'DRAFT' | 'SENT' | 'ACCEPTED' | 'REJECTED'; statusOnly?: boolean }): Promise<Proposal> => {
    
      const response = await fetch(`${API_STAGE_URL}/proposals/${proposalId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
        },
        body: JSON.stringify(data)
      });
      return await response.json();
    
  },

  deleteProposal: async (proposalId: string): Promise<boolean> => {
    
      await fetch(`${API_STAGE_URL}/proposals/${proposalId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${localStorage.getItem('storybox_token')}` }
      });
      return true;
    
  },

  forgotPassword: async (email: string): Promise<void> => {
    
      const response = await fetch(`https://cognito-idp.ap-south-2.amazonaws.com/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-amz-json-1.1',
          'X-Amz-Target': 'AWSCognitoIdentityProviderService.ForgotPassword'
        },
        body: JSON.stringify({
          ClientId: COGNITO_CLIENT_ID,
          Username: email
        })
      });
      
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || "Failed to request password reset code");
      }
    
  },

  confirmForgotPassword: async (email: string, code: string, password: string): Promise<void> => {
    
      const response = await fetch(`https://cognito-idp.ap-south-2.amazonaws.com/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-amz-json-1.1',
          'X-Amz-Target': 'AWSCognitoIdentityProviderService.ConfirmForgotPassword'
        },
        body: JSON.stringify({
          ClientId: COGNITO_CLIENT_ID,
          Username: email,
          ConfirmationCode: code,
          Password: password
        })
      });
      
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || "Failed to confirm password reset");
      }
    
  },

  signUp: async (name: string, email: string, phone: string, role: 'SUPER_ADMIN' | 'ADMIN' | 'READ_ONLY' | 'CLIENT', password?: string): Promise<void> => {
    const formattedPhone = formatE164Phone(phone);
    
      const response = await fetch(`https://cognito-idp.ap-south-2.amazonaws.com/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-amz-json-1.1',
          'X-Amz-Target': 'AWSCognitoIdentityProviderService.SignUp'
        },
        body: JSON.stringify({
          ClientId: COGNITO_CLIENT_ID,
          Username: email,
          Password: password,
          UserAttributes: [
            { Name: 'email', Value: email },
            { Name: 'name', Value: name },
            { Name: 'phone_number', Value: formattedPhone },
            { Name: 'custom:role', Value: role }
          ]
        })
      });
      
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || "Cognito registration failed");
      }
    
  },

  confirmSignUp: async (email: string, code: string): Promise<void> => {
    
      const response = await fetch(`https://cognito-idp.ap-south-2.amazonaws.com/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-amz-json-1.1',
          'X-Amz-Target': 'AWSCognitoIdentityProviderService.ConfirmSignUp'
        },
        body: JSON.stringify({
          ClientId: COGNITO_CLIENT_ID,
          Username: email,
          ConfirmationCode: code
        })
      });
      
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || "Failed to confirm account verification");
      }
    
  },

  getEmployees: async (): Promise<Employee[]> => {
    const response = await fetch(`${API_STAGE_URL}/employees`, {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('storybox_token')}` }
    });
    return await response.json();
  },

  createEmployee: async (data: Partial<Employee>): Promise<Employee> => {
    const response = await fetch(`${API_STAGE_URL}/employees`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
      },
      body: JSON.stringify(data)
    });
    return await response.json();
  },

  updateEmployee: async (employeeId: string, data: Partial<Employee>): Promise<Employee> => {
    const response = await fetch(`${API_STAGE_URL}/employees/${employeeId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
      },
      body: JSON.stringify(data)
    });
    return await response.json();
  },

  deleteEmployee: async (employeeId: string): Promise<void> => {
    const response = await fetch(`${API_STAGE_URL}/employees/${employeeId}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${localStorage.getItem('storybox_token')}` }
    });
    if (!response.ok) throw new Error("Failed to delete employee");
  },

  // --- HOA VENDOR SERVICES ---
  getHoaVendors: async (): Promise<HoaVendor[]> => {
    const response = await fetch(`${API_STAGE_URL}/hoa/vendors`, {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('storybox_token')}` }
    });
    if (!response.ok) throw new Error("Failed to fetch vendors");
    return await response.json();
  },

  createHoaVendor: async (data: Partial<HoaVendor>): Promise<HoaVendor> => {
    const response = await fetch(`${API_STAGE_URL}/hoa/vendors`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
      },
      body: JSON.stringify(data)
    });
    if (!response.ok) throw new Error("Failed to create vendor");
    return await response.json();
  },

  updateHoaVendor: async (vendorId: string, data: Partial<HoaVendor>): Promise<HoaVendor> => {
    const response = await fetch(`${API_STAGE_URL}/hoa/vendors/${vendorId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
      },
      body: JSON.stringify(data)
    });
    if (!response.ok) throw new Error("Failed to update vendor");
    return await response.json();
  },

  deleteHoaVendor: async (vendorId: string): Promise<void> => {
    const response = await fetch(`${API_STAGE_URL}/hoa/vendors/${vendorId}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${localStorage.getItem('storybox_token')}` }
    });
    if (!response.ok) throw new Error("Failed to delete vendor");
  },

  getHoaUploadUrl: async (fileName: string, contentType: string): Promise<{ uploadUrl: string; objectKey: string }> => {
    const response = await fetch(`${API_STAGE_URL}/hoa/upload-url`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
      },
      body: JSON.stringify({ fileName, contentType })
    });
    if (!response.ok) throw new Error("Failed to get upload URL");
    return await response.json();
  },

  // --- HOA INVENTORY SERVICES ---
  getHoaInventory: async (): Promise<HoaInventoryItem[]> => {
    const response = await fetch(`${API_STAGE_URL}/hoa/inventory`, {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('storybox_token')}` }
    });
    if (!response.ok) throw new Error("Failed to fetch inventory");
    return await response.json();
  },

  createHoaInventoryItem: async (data: Partial<HoaInventoryItem>): Promise<HoaInventoryItem> => {
    const response = await fetch(`${API_STAGE_URL}/hoa/inventory`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
      },
      body: JSON.stringify(data)
    });
    if (!response.ok) throw new Error("Failed to create inventory item");
    return await response.json();
  },

  updateHoaInventoryItem: async (itemId: string, data: Partial<HoaInventoryItem>): Promise<HoaInventoryItem> => {
    const response = await fetch(`${API_STAGE_URL}/hoa/inventory/${itemId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
      },
      body: JSON.stringify(data)
    });
    if (!response.ok) throw new Error("Failed to update inventory item");
    return await response.json();
  },

  deleteHoaInventoryItem: async (itemId: string): Promise<void> => {
    const response = await fetch(`${API_STAGE_URL}/hoa/inventory/${itemId}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${localStorage.getItem('storybox_token')}` }
    });
    if (!response.ok) throw new Error("Failed to delete inventory item");
  },

  // --- HOA PURCHASE ORDER SERVICES ---
  getHoaPurchaseOrders: async (): Promise<HoaPurchaseOrder[]> => {
    const response = await fetch(`${API_STAGE_URL}/hoa/purchase-orders`, {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('storybox_token')}` }
    });
    if (!response.ok) throw new Error("Failed to fetch purchase orders");
    return await response.json();
  },

  createHoaPurchaseOrder: async (data: Partial<HoaPurchaseOrder>): Promise<HoaPurchaseOrder> => {
    const response = await fetch(`${API_STAGE_URL}/hoa/purchase-orders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
      },
      body: JSON.stringify(data)
    });
    if (!response.ok) throw new Error("Failed to create purchase order");
    return await response.json();
  },

  updateHoaPurchaseOrder: async (poId: string, data: Partial<HoaPurchaseOrder>): Promise<HoaPurchaseOrder> => {
    const response = await fetch(`${API_STAGE_URL}/hoa/purchase-orders/${poId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('storybox_token')}`
      },
      body: JSON.stringify(data)
    });
    if (!response.ok) throw new Error("Failed to update purchase order");
    return await response.json();
  },

  deleteHoaPurchaseOrder: async (poId: string): Promise<void> => {
    const response = await fetch(`${API_STAGE_URL}/hoa/purchase-orders/${poId}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${localStorage.getItem('storybox_token')}` }
    });
    if (!response.ok) throw new Error("Failed to delete purchase order");
  }
};
