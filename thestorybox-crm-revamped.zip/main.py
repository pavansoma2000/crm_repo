import json
from src.projects.handler import (
    create_project, list_projects, get_project_details, update_project,
    add_booking, create_gallery, get_gallery_photos, client_proof_photos,
    generate_bulk_upload_urls, add_images_to_gallery, delete_project
)
from src.payments.handler import create_invoice, list_invoices, pay_invoice
from src.utils.db import table, query_by_pk, query_by_gsi1
from boto3.dynamodb.conditions import Key

from src.users.handler import list_users, create_user, update_user, delete_user
from src.leads.handler import list_leads, create_lead, update_lead, delete_lead
from src.inventory.handler import list_inventory, create_inventory, update_inventory, delete_inventory
from src.subscriptions.handler import list_subscriptions, create_subscription, update_subscription, delete_subscription
from src.proposals.handler import list_proposals, create_proposal, update_proposal, delete_proposal

import decimal

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, decimal.Decimal):
            if obj % 1 == 0:
                return int(obj)
            return float(obj)
        return super(DecimalEncoder, self).default(obj)

def make_response(status_code: int, body: dict):
    """Build a standardized HTTP response with broad CORS headers."""
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
            'Access-Control-Allow-Methods': 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT'
        },
        'body': json.dumps(body, cls=DecimalEncoder)
    }

def handler(event, context):
    """
    Main Lambda entrypoint parsing API Gateway requests and routing
    them to their respective sub-handlers.
    """
    path = event.get('path', '')
    http_method = event.get('httpMethod', '')
    path_parameters = event.get('pathParameters') or {}
    query_parameters = event.get('queryStringParameters') or {}
    
    # Handle preflight OPTIONS
    if http_method == 'OPTIONS':
        return make_response(200, {'message': 'CORS OK'})
        
    print(f"API Router received: {http_method} {path} | Params: {path_parameters}")
    
    # Parse Auth claims from Cognito
    request_context = event.get('requestContext') or {}
    authorizer = request_context.get('authorizer') or {}
    claims = authorizer.get('claims') or {}
    
    # For local/testing purposes without Cognito Authorizer, mock some defaults
    user_id = claims.get('sub') or claims.get('cognito:username') or 'mock-admin-id'
    email = claims.get('email') or 'admin@thestorybox.in'
    role = claims.get('custom:role') or 'ADMIN'  # Default to ADMIN for local testing
    
    print(f"Auth Claims: User={user_id} | Role={role} | Email={email}")
    
    # Parse request body if available
    body = {}
    event_body = event.get('body')
    if event_body:
        try:
            body = json.loads(event_body)
        except Exception:
            return make_response(400, {'error': 'Invalid JSON format in body'})
            
    try:
        # --- PROJECTS ROUTING ---
        if path == '/projects' and http_method == 'GET':
            res = list_projects(user_id, role)
            return make_response(res['statusCode'], res['body'])
            
        elif path == '/projects' and http_method == 'POST':
            if role.upper() not in ['ADMIN', 'SUPER_ADMIN']:
                return make_response(403, {'error': 'Admin role required'})
            res = create_project(body, user_id)
            return make_response(res['statusCode'], res['body'])
            
        elif path.startswith('/projects/') and http_method == 'GET':
            proj_id = path_parameters.get('projectId') or path.split('/')[2]
            res = get_project_details(proj_id, user_id, role)
            return make_response(res['statusCode'], res['body'])
            
        elif path.startswith('/projects/') and http_method == 'PUT':
            if role.upper() not in ['ADMIN', 'SUPER_ADMIN']:
                return make_response(403, {'error': 'Admin role required'})
            proj_id = path_parameters.get('projectId') or path.split('/')[2]
            res = update_project(proj_id, body)
        elif path.startswith('/projects/') and http_method == 'DELETE':
            if role.upper() not in ['ADMIN', 'SUPER_ADMIN']:
                return make_response(403, {'error': 'Admin role required'})
            proj_id = path_parameters.get('projectId') or path.split('/')[2]
            res = delete_project(proj_id)
            return make_response(res['statusCode'], res['body'])
            
        # --- BOOKINGS ROUTING ---
        elif path.startswith('/projects/') and path.endswith('/bookings') and http_method == 'POST':
            if role.upper() not in ['ADMIN', 'SUPER_ADMIN']:
                return make_response(403, {'error': 'Admin role required'})
            proj_id = path_parameters.get('projectId') or path.split('/')[2]
            res = add_booking(proj_id, body)
            return make_response(res['statusCode'], res['body'])
            
        # --- GALLERIES ROUTING ---
        elif path.startswith('/projects/') and path.endswith('/galleries') and http_method == 'POST':
            if role.upper() not in ['ADMIN', 'SUPER_ADMIN']:
                return make_response(403, {'error': 'Admin role required'})
            proj_id = path_parameters.get('projectId') or path.split('/')[2]
            res = create_gallery(proj_id, body)
            return make_response(res['statusCode'], res['body'])
            
        elif path.startswith('/projects/') and '/galleries/' in path and path.endswith('/select') and http_method == 'POST':
            parts = path.split('/')
            proj_id = path_parameters.get('projectId') or parts[2]
            gallery_id = path_parameters.get('galleryId') or parts[4]
            # Client proofing
            res = client_proof_photos(proj_id, gallery_id, body, user_id)
            return make_response(res['statusCode'], res['body'])
            
        elif path.startswith('/projects/') and '/galleries/' in path and path.endswith('/upload-urls') and http_method == 'POST':
            if role.upper() not in ['ADMIN', 'SUPER_ADMIN']:
                return make_response(403, {'error': 'Admin role required'})
            parts = path.split('/')
            proj_id = path_parameters.get('projectId') or parts[2]
            gallery_id = path_parameters.get('galleryId') or parts[4]
            res = generate_bulk_upload_urls(proj_id, gallery_id, body)
            return make_response(res['statusCode'], res['body'])
 
        elif path.startswith('/projects/') and '/galleries/' in path and path.endswith('/add-images') and http_method == 'POST':
            if role.upper() not in ['ADMIN', 'SUPER_ADMIN']:
                return make_response(403, {'error': 'Admin role required'})
            parts = path.split('/')
            proj_id = path_parameters.get('projectId') or parts[2]
            gallery_id = path_parameters.get('galleryId') or parts[4]
            res = add_images_to_gallery(proj_id, gallery_id, body)
            return make_response(res['statusCode'], res['body'])
 
        elif path.startswith('/projects/') and '/galleries/' in path and http_method == 'GET':
            parts = path.split('/')
            proj_id = path_parameters.get('projectId') or parts[2]
            gallery_id = path_parameters.get('galleryId') or parts[4]
            res = get_gallery_photos(proj_id, gallery_id, user_id, role)
            return make_response(res['statusCode'], res['body'])
            
        # --- INVOICES ROUTING ---
        elif path == '/invoices' and http_method == 'GET':
            res = list_invoices(user_id, role)
            return make_response(res['statusCode'], res['body'])
            
        elif path.startswith('/projects/') and path.endswith('/invoices') and http_method == 'POST':
            if role.upper() not in ['ADMIN', 'SUPER_ADMIN']:
                return make_response(403, {'error': 'Admin role required'})
            proj_id = path_parameters.get('projectId') or path.split('/')[2]
            res = create_invoice(proj_id, body)
            return make_response(res['statusCode'], res['body'])
            
        elif path.startswith('/projects/') and '/invoices/' in path and path.endswith('/pay') and http_method == 'PUT':
            parts = path.split('/')
            proj_id = path_parameters.get('projectId') or parts[2]
            invoice_id = path_parameters.get('invoiceId') or parts[4]
            res = pay_invoice(proj_id, invoice_id)
            return make_response(res['statusCode'], res['body'])
            
        # --- STATS ROUTING ---
        elif path == '/stats' and http_method == 'GET':
            if role.upper() not in ['ADMIN', 'SUPER_ADMIN']:
                return make_response(403, {'error': 'Admin role required'})
                
            # Aggregate stats for Dashboard: total projects, total billing, active clients, scheduled events
            try:
                # Retrieve all rows
                scan_res = table.scan()
                items = scan_res.get('Items', [])
                
                total_projects = 0
                total_invoices_value = 0.0
                collected_revenue = 0.0
                active_clients = set()
                upcoming_shoots = 0
                
                for item in items:
                    sk = item.get('SK', '')
                    pk = item.get('PK', '')
                    
                    if pk.startswith('PROJECT#') and sk == 'METADATA':
                        total_projects += 1
                        if item.get('clientId'):
                            active_clients.add(item.get('clientId'))
                            
                    elif pk.startswith('PROJECT#') and sk.startswith('INVOICE#'):
                        amt = float(item.get('amount', 0.0))
                        total_invoices_value += amt
                        if item.get('status') == 'PAID':
                            collected_revenue += amt
                            
                    elif pk.startswith('PROJECT#') and sk.startswith('BOOKING#'):
                        start_time = item.get('startTime')
                        if start_time:
                            # Parse check if in future
                            try:
                                import datetime
                                dt = datetime.datetime.fromisoformat(start_time.replace('Z', '+00:00'))
                                if dt.replace(tzinfo=None) > datetime.datetime.utcnow():
                                    upcoming_shoots += 1
                            except ValueError:
                                upcoming_shoots += 1
                                
                return make_response(200, {
                    'totalProjects': total_projects,
                    'activeClients': len(active_clients),
                    'totalRevenue': total_invoices_value,
                    'collectedRevenue': collected_revenue,
                    'upcomingShoots': upcoming_shoots
                })
            except Exception as e:
                return make_response(500, {'error': str(e)})
                
        # --- USERS ROUTING ---
        elif path == '/users' and http_method == 'GET':
            if role.upper() not in ['ADMIN', 'SUPER_ADMIN', 'READ_ONLY']:
                return make_response(403, {'error': 'Crew access required'})
            role_group = query_parameters.get('roleGroup', 'clients')
            res = list_users(role_group)
            return make_response(res['statusCode'], res['body'])
            
        elif path == '/users' and http_method == 'POST':
            if role.upper() not in ['ADMIN', 'SUPER_ADMIN']:
                return make_response(403, {'error': 'Admin role required'})
            res = create_user(body)
            return make_response(res['statusCode'], res['body'])
            
        elif path.startswith('/users/') and http_method == 'PUT':
            if role.upper() not in ['ADMIN', 'SUPER_ADMIN']:
                return make_response(403, {'error': 'Admin role required'})
            user_id_param = path_parameters.get('userId') or path.split('/')[2]
            res = update_user(user_id_param, body)
            return make_response(res['statusCode'], res['body'])

        elif path.startswith('/users/') and http_method == 'DELETE':
            if role.upper() not in ['SUPER_ADMIN']:
                return make_response(403, {'error': 'Super Admin role required'})
            user_id_param = path_parameters.get('userId') or path.split('/')[2]
            res = delete_user(user_id_param)
            return make_response(res['statusCode'], res['body'])
            
        # --- LEADS ROUTING ---
        elif path == '/leads' and http_method == 'GET':
            if role.upper() not in ['ADMIN', 'SUPER_ADMIN', 'READ_ONLY']:
                return make_response(403, {'error': 'Crew access required'})
            res = list_leads()
            return make_response(res['statusCode'], res['body'])
            
        elif path == '/leads' and http_method == 'POST':
            if role.upper() not in ['ADMIN', 'SUPER_ADMIN']:
                return make_response(403, {'error': 'Admin role required'})
            res = create_lead(body)
            return make_response(res['statusCode'], res['body'])
            
        elif path.startswith('/leads/') and http_method == 'PUT':
            if role.upper() not in ['ADMIN', 'SUPER_ADMIN']:
                return make_response(403, {'error': 'Admin role required'})
            lead_id_param = path_parameters.get('leadId') or path.split('/')[2]
            res = update_lead(lead_id_param, body)
            return make_response(res['statusCode'], res['body'])
            
        elif path.startswith('/leads/') and http_method == 'DELETE':
            if role.upper() not in ['ADMIN', 'SUPER_ADMIN']:
                return make_response(403, {'error': 'Admin role required'})
            lead_id_param = path_parameters.get('leadId') or path.split('/')[2]
            res = delete_lead(lead_id_param)
            return make_response(res['statusCode'], res['body'])
            
        # --- INVENTORY ROUTING ---
        elif path == '/inventory' and http_method == 'GET':
            if role.upper() not in ['ADMIN', 'SUPER_ADMIN', 'READ_ONLY']:
                return make_response(403, {'error': 'Crew access required'})
            res = list_inventory()
            return make_response(res['statusCode'], res['body'])
            
        elif path == '/inventory' and http_method == 'POST':
            if role.upper() not in ['ADMIN', 'SUPER_ADMIN']:
                return make_response(403, {'error': 'Admin role required'})
            res = create_inventory(body)
            return make_response(res['statusCode'], res['body'])
            
        elif path.startswith('/inventory/') and http_method == 'PUT':
            if role.upper() not in ['ADMIN', 'SUPER_ADMIN']:
                return make_response(403, {'error': 'Admin role required'})
            item_id_param = path_parameters.get('itemId') or path.split('/')[2]
            res = update_inventory(item_id_param, body)
            return make_response(res['statusCode'], res['body'])
            
        elif path.startswith('/inventory/') and http_method == 'DELETE':
            if role.upper() not in ['ADMIN', 'SUPER_ADMIN']:
                return make_response(403, {'error': 'Admin role required'})
            item_id_param = path_parameters.get('itemId') or path.split('/')[2]
            res = delete_inventory(item_id_param)
            return make_response(res['statusCode'], res['body'])
            
        # --- SUBSCRIPTIONS ROUTING ---
        elif path == '/subscriptions' and http_method == 'GET':
            if role.upper() not in ['ADMIN', 'SUPER_ADMIN', 'READ_ONLY']:
                return make_response(403, {'error': 'Crew access required'})
            res = list_subscriptions()
            return make_response(res['statusCode'], res['body'])
            
        elif path == '/subscriptions' and http_method == 'POST':
            if role.upper() not in ['ADMIN', 'SUPER_ADMIN']:
                return make_response(403, {'error': 'Admin role required'})
            res = create_subscription(body)
            return make_response(res['statusCode'], res['body'])
            
        elif path.startswith('/subscriptions/') and http_method == 'PUT':
            if role.upper() not in ['ADMIN', 'SUPER_ADMIN']:
                return make_response(403, {'error': 'Admin role required'})
            sub_id_param = path_parameters.get('subscriptionId') or path.split('/')[2]
            res = update_subscription(sub_id_param, body)
            return make_response(res['statusCode'], res['body'])
            
        elif path.startswith('/subscriptions/') and http_method == 'DELETE':
            if role.upper() not in ['ADMIN', 'SUPER_ADMIN']:
                return make_response(403, {'error': 'Admin role required'})
            sub_id_param = path_parameters.get('subscriptionId') or path.split('/')[2]
            res = delete_subscription(sub_id_param)
            return make_response(res['statusCode'], res['body'])
            
        # --- PROPOSALS ROUTING ---
        elif path == '/proposals' and http_method == 'GET':
            if role.upper() in ['ADMIN', 'SUPER_ADMIN', 'READ_ONLY']:
                res = list_proposals()
                return make_response(res['statusCode'], res['body'])
            else:
                try:
                    proposals = query_by_gsi1(f"CLIENT#{email}")
                    proposals_map = {}
                    for item in proposals:
                        pk = item.get('PK')
                        sk = item.get('SK')
                        prop_id = pk.split('#')[1]
                        
                        if prop_id not in proposals_map:
                            proposals_map[prop_id] = {
                                'proposalId': prop_id,
                                'clientName': item.get('clientName', 'Anonymous'),
                                'clientEmail': item.get('clientEmail', ''),
                                'clientPhone': item.get('clientPhone', ''),
                                'status': item.get('status', 'DRAFT'),
                                'currentVersion': int(item.get('currentVersion', 1)),
                                'createdAt': item.get('createdAt', ''),
                                'versions': []
                            }
                            
                        all_v = query_by_pk(f"PROPOSAL#{prop_id}")
                        for v_item in all_v:
                            v_sk = v_item.get('SK', '')
                            if v_sk.startswith('VERSION#'):
                                try:
                                    v_num = int(v_sk.split('#')[1])
                                except ValueError:
                                    continue
                                proposals_map[prop_id]['versions'].append({
                                    'version': v_num,
                                    'title': v_item.get('title', ''),
                                    'description': v_item.get('description', ''),
                                    'budget': float(v_item.get('budget', 0.0)),
                                    'deliverables': v_item.get('deliverables', []),
                                    'terms': v_item.get('terms', ''),
                                    'createdAt': v_item.get('createdAt', '')
                                })
                                
                    for prop_id, prop in proposals_map.items():
                        prop['versions'].sort(key=lambda x: x['version'])
                        
                    return make_response(200, list(proposals_map.values()))
                except Exception as e:
                    return make_response(500, {'error': str(e)})
                    
        elif path == '/proposals' and http_method == 'POST':
            if role.upper() not in ['ADMIN', 'SUPER_ADMIN']:
                return make_response(403, {'error': 'Admin role required'})
            res = create_proposal(body)
            return make_response(res['statusCode'], res['body'])
            
        elif path.startswith('/proposals/') and http_method == 'PUT':
            if role.upper() not in ['ADMIN', 'SUPER_ADMIN']:
                return make_response(403, {'error': 'Admin role required'})
            prop_id_param = path_parameters.get('proposalId') or path.split('/')[2]
            res = update_proposal(prop_id_param, body)
            return make_response(res['statusCode'], res['body'])
            
        elif path.startswith('/proposals/') and http_method == 'DELETE':
            if role.upper() not in ['ADMIN', 'SUPER_ADMIN']:
                return make_response(403, {'error': 'Admin role required'})
            prop_id_param = path_parameters.get('proposalId') or path.split('/')[2]
            res = delete_proposal(prop_id_param)
            return make_response(res['statusCode'], res['body'])
            
        # --- FALLBACK ---
        return make_response(404, {'error': f"Route {http_method} {path} not found"})
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return make_response(500, {'error': f"Internal server error: {str(e)}"})
